# Earth2Space: Master Development Prompt (v7, 3D Moon + 3D Earth, Space Apps Challenge 2026)

## 1. Project Objective

Build Earth2Space, an interactive web application for the NASA Space Apps Challenge 2026 challenge "Identify Earth Locations that Analog the Permanent Moon Base Locations and Mars". It finds, compares, and visualizes Earth locations that can serve as scientific and operational analogs for future permanent Moon base locations. Mars is planned for a later release (see Coming soon below). Earth and the Moon are both shown as interactive 3D bodies: the Earth as a 3D globe, and the Moon as a 3D body in space. It should be usable by both experts and the general public.

Core flow:
Select a location on the Moon → analyze its conditions → discover the 10 best Earth analogs → compare the Moon and Earth conditions side by side → understand the similarities and differences → evaluate scientific and economic potential.

Prioritize scientific credibility, real data, transparency about data quality, usability, and an exceptional interactive experience.

## 2. Scope of This Release

In scope:
- Home / Dashboard
- Moon 3D Explorer (the Moon in space)
- Earth Analog Finder
- Earth 3D Globe with analog markers
- Earth Location Profiles
- Scientific Comparison: Moon vs. Earth, with condition filters and gradient comparisons
- Advanced condition filters
- Google Drive data pipeline
- Credits page listing the creators
- Data Sources and Methodology

Phase 2 scope:
- AI Scientific Explanation Engine
- Economic Feasibility assumptions calculator

Coming soon:
- Mars Explorer. The navigation entry stays visible and opens a "Coming soon" page describing the planned Mars module. It shows no Mars data and performs no Mars analog matching.

The architecture must allow Mars to be added later without rewriting the Moon or Earth modules (section 16).

## 3. Phased Delivery

Phase 1 (first build):
- Google Drive inventory and validation
- Moon 3D Explorer: the Moon in space, with rotate, zoom, and point selection
- Earth Analog Finder with a curated seed catalog and transparent scoring
- Earth 3D Globe with the top 10 analog markers and linked selection to the Moon
- Scientific Comparison (Moon vs. Earth) for the conditions the user selects, with gradient views (section 9)
- Condition filters that choose which parameters are compared (section 10)
- Earth Location Profiles
- Data Sources and Methodology page
- Mars Explorer "Coming soon" page

Phase 2:
- Live re-ranking when weights or filters change
- AI Scientific Explanation Engine
- Economic Feasibility assumptions calculator
- Expanded Drive datasets and additional Earth catalog sites
- Optional Google Photorealistic 3D view on Earth profile pages

Phase 3:
- Mars module (separate scope, to be specified later)

## 4. Google Drive Data Integration

Source: the authorized Google Drive account. Treat it as the central source of project information.

Current root: folder "Hackathon NASA Spaces Apps Challenge". Contents:

- Summaries
  - Google Doc "Challenge: Create an App or Website" (the challenge brief)
- Data (topic folders)
  - Conditions relevant to landing: contains Lunar_Earth_Comparison (folders Earth, Moon, Results)
  - Dust: contains Dust, with Moon_Data and NASA_Earth_Data
  - extreme: contains download_data.py, earth_data, moon_data, Moon_Earth_Comparison
  - Radiation: Earth and Moon folders with Earth_Radiation_Coordinates.xlsx and Moon_Radiation_Coordinates.xlsx
  - roughness: Earth and Moon folders with terrain CSVs at 0.25° and 0.5° resolution, plus README_moon_terrain.txt
  - Temperature, illumination: Earth and Moon folders with local-time profile and location CSVs, plus READMEs
  - topographic: contains "topographic features" with an Earth_Moon_Topography script
- vision and guidelines
  - Colorforwebsite.png (the color palette)
  - "Gradient and extras" (gradient and font rules)
  - NASA_Space_Apps_Logos_2026.zip and Space_Apps_Patterns.zip

Requirements:
- Inventory files recursively. Record file ID, name, MIME type, size, modified time, and folder path.
- Categorize each item: Earth, Moon, geological, environmental, topographical, scientific, or financial.
- Read the README files in each folder before using their data. They define units, coordinate systems, and known limits.
- Validate every dataset before use. Assign a status: validated, needs review, or unusable. Do not assume a file contains usable structured data.
- Identify duplicates (same name, size, or checksum), missing information, and any folders not yet expanded.
- Preserve the Drive file ID and a link to each source so every value can be traced back.

Large-file handling:
- Several CSVs are very large (for example, the Earth terrain CSV at 0.25° is about 266 MB). Never load raw CSVs in the browser.
- Preprocess them in a backend job into the catalog and into compact per-region summaries.
- Keep the original IMG/LBL grids for high-resolution work. Summary CSVs cannot rebuild a 3D landscape.
- Convert the Moon elevation and Earth elevation grids into textures or displacement maps sized for browsers (see sections 5 and 8).

Known data limits to display in the app:
- Moon terrain statistics are regional bins, not landing-safety certification and not rover-scale obstacles.
- LOLA roughness is not a measurement of individual rocks or wheel-scale obstacles.
- Moon and Earth use different coordinate systems and elevation reference surfaces.
- Diviner temperatures are historical averages of bolometric brightness temperature, not dated in-situ readings. Local solar time is not Earth clock time.
- Temperature comparisons must match measurement type, time of day, and solar conditions. Latitude-only temperature files cannot be used for longitude-specific comparisons.
- If access to Drive is not yet configured, design the integration and list the required permissions and setup steps.

## 5. Moon 3D Explorer

- The Moon is shown as a 3D sphere in space, with a starfield and the Earth visible as a reference body.
- Users rotate, zoom, and click the Moon directly. A click on the surface converts to selenographic latitude and longitude and selects that location.
- Show the selected point's coordinates on screen at all times, in decimal degrees with hemisphere letters (for example 12.34° N, 45.67° E), updated on every click and easy to copy.
- Surface appearance: a lunar texture from an authoritative source (verify licensing), with shading from LOLA elevation.
- Layers, switched on and off: elevation (true scale by default; exaggerated mode optional), craters, slopes, roughness, surface composition, illumination, temperature, and potential water-ice indicators. Label each layer as measured or modelled, with its source.
- Illumination: the sun direction follows the stated observation basis, so sunlit and shadowed terrain are visible.
- Selecting a point opens a panel with values, units, source, observation basis, resolution, and known gaps. Missing values show as "No data available". Never fill them.
- Use selenographic, planetocentric latitude and east-positive longitude, and state the convention on the page.
- Lower texture resolution on mobile, with a 2D fallback table for devices that cannot render WebGL.

Dataset references (from the Drive READMEs; verify before publishing):
- LRO LOLA GDR (elevation, slope, roughness): doi 10.17189/1520642
- LRO LOLA South Pole DEM
- LRO Diviner derived products (temperature)
- Planetary Data System (pds.nasa.gov) for archive access

## 6. Earth Analog Finder

Input: a selected lunar location or region.
Output: the 10 best-ranked Earth analog locations, each with a similarity score, a criterion breakdown, a data coverage percentage, and an analogy strength label (strong, moderate, or weak).

### Similarity criteria (default weights, user-adjustable)
- Geology and mineralogy
- Surface materials and soil composition
- Terrain and topography
- Elevation, slope, roughness, and craters
- Temperature and environmental extremes
- Water, ice, and permafrost
- Dust, wind, erosion, and atmospheric processes
- Biology, extremophiles, and habitability
- Caves, lava tubes, and subsurface environments
- Suitability for robotic operations, human exploration, landing, mobility, and construction

Earth data for these criteria in the Drive: ASTER GDEM V003 and MODIS MOD11A1 V061 (as named in the folder README), terrain CSVs, and local-time temperature profiles.

### Scoring method (versioned, reproducible)
1. For each variable, define its unit, direction (higher or lower is more similar), and normalization across the catalog (min-max or percentile; state which one).
2. Per-variable similarity = 1 minus the normalized distance between the lunar value and the Earth value.
3. Per-criterion score = mean of its available variables.
4. Overall score = weighted mean of available criteria. When data is missing, renormalize the weights over the criteria with data, and show the coverage percentage beside the score.
5. Locations below a coverage threshold (proposed: 60%) are labelled "limited comparison" and excluded from the default top 10. Users can include them.
6. Every variable carries a measured or estimated flag. Show the share of estimated inputs for each location.
7. The same inputs always produce the same ranking. Store the scoring method version with each result.

### Finding similar tendencies (not identical values)
Earth sites will never match the Moon value for value. The finder ranks sites by how similar their overall tendencies are, using these steps:

1. Scale each variable against the whole catalog with percentile scaling (5th to 95th percentile, clipped to 0 to 1), so a single extreme value cannot dominate the score. Store the percentile bounds with the method version.
2. Compare each variable with a similarity of 1 minus the scaled distance. Use the same rule for every numeric variable, and state the direction (higher or lower is more similar) for each.
3. Compare time-profile variables (the daily temperature and illumination curves by local time) in two parts:
   - Shape: the Pearson correlation of the two curves after each has its mean removed, mapped to 0 to 1. This detects the same day-night pattern.
   - Level: the difference in the curves' means, scaled as in step 1.
   Both parts count, with weights set in the criteria table.
4. Compute each criterion score as the weighted mean of its available variables. Compute the overall score as the weighted mean of the criteria, skipping missing variables and rescaling the remaining weights. Show the coverage percentage beside every score (section 6, rules 4 and 5).
5. Add a tendency label for each variable: "same band" when the Earth value falls in the same quartile of the catalog as the lunar value, and "opposite band" when it falls in the far opposite quartile. The label is shown next to the number, so a reader sees the pattern at a glance.
6. Test stability: rank the sites under three weight profiles (balanced, science-led, and operations-led). Mark a site "robust" when it stays in the top 10 under all three, and "sensitive to weights" when it drops out under any of them.
7. Report the result as a ranked list with its agreements, disagreements, and stability flag. Never describe a site as a match or an identical analog.

Clustering (for example grouping sites into analog families) is a Phase 2 option. Phase 1 uses only the ranking above.

### Transparency requirements
- Show the formula in plain language, each criterion's contribution, and the top three agreements and top three disagreements.
- A location can rank highly in one criterion and poorly in another. Show this openly.
- Do not present weak or incomplete comparisons as scientific fact.

## 7. Earth Analog Catalog (Data Model)

Each site record includes:
- site_id, name, country, latitude, longitude, region
- elevation_m (with reference surface), terrain_type, rock_type, mineralogy, surface_materials
- mean_annual_temp_c, temperature_range_c, annual_precip_mm, aridity_index
- median_slope_deg, roughness_m, relief notes
- water, ice, or permafrost status
- dust, wind, and erosion indicators
- biology and extremophile notes
- lava tube or cave presence
- temperature profile by local time (day, night, noon, midnight) with valid-bin coverage
- access notes (remoteness, permits, logistics)
- data_quality (completeness score)
- sources: list of source ID, name, URL, and date

Each numeric variable stores: value, unit, measured or estimated flag, source ID, observation basis (date or historical average), and grid resolution.

Seed catalog (Phase 1, 20 to 30 sites). Values must be sourced and verified, never invented:
- Atacama Desert (Chile)
- Icelandic lava fields (Iceland)
- Hawaiian lava tubes (USA)
- Craters of the Moon National Monument (Idaho, USA)
- Eifel volcanic fields (Germany)
- Mars Desert Research Station area (Utah, USA)
- Death Valley (USA)
- Antarctic Dry Valleys (Antarctica)
- Devon Island impact structure (Canada)
- Namib Desert (Namibia)
- Rio Tinto (Spain)

Data precedence: validated Drive datasets first, then authoritative public datasets, then published literature. Each value shows its origin.

## 8. Earth 3D Globe

- The Earth is shown as a 3D globe. Users rotate, zoom, and click. Recommended engine: Three.js, the same scene engine as the Moon, so both bodies share controls and styling.
- Earth surface: an open, clearly licensed texture, with elevation from the Earth terrain data (verify source and resolution).
- Markers for the top 10 analogs. Clicking a marker rotates the globe to that site and opens its rank, score, coverage, and analogy strength.
- Show the latitude and longitude of every marker, the selected Earth analog, and the selected Moon point in decimal degrees with hemisphere letters, on the globe overlay and on each marker card.
- Linked selection: the selected lunar point and the selected Earth analog are connected on the scene, so the Moon and Earth views update together.
- Compare up to four analogs, each with a distinct marker.
- Region and condition filters control which markers show.
- Optional later: Google Photorealistic 3D Tiles, or a Google Maps street-level view on Earth profile pages. These need the Google Maps connection and are subject to its usage limits. They are not the globe engine.
- Place names, addresses, and any Google data come from the backend and are never typed from memory.
- Google Maps server calls stay behind authenticated app endpoints, with capped batch sizes and cached results.

## 9. Scientific Comparison: Moon vs. Earth (Phase 1)

This is the core comparison view. It opens when the user selects a point on the 3D Moon and an Earth analog (or the top 10) on the 3D globe. Selecting on either body updates the comparison.

### What it shows
For the conditions the user selects in the filters (section 10):
- A parameter table: parameter, lunar value (unit, source, observation basis), Earth analog value (unit, source, observation basis), difference, similarity band, and measured or estimated flag.
- A gradient comparison for each selected parameter (see below).
- A "similar parameters" list: parameters where the Moon and Earth values fall in the same similarity band, ranked by strength.
- A "different parameters" list with the reason for each difference.
- The coordinates of the lunar point and of each Earth analog, shown in the table header, in the same format as the 3D views.
- Scientific relevance and the limits of the analogy in plain language.

### Gradient comparison
For each selected parameter, draw a horizontal gradient bar:
- The bar spans the full range of that parameter across the catalog.
- Mark the lunar value with a labelled marker.
- Mark each selected Earth analog value with its name and value.
- Shade the overlap where the lunar and Earth ranges match, and label it "similar range".
- Use a sequential blue gradient for values: Blue Yonder → Neon Blue → Electric Blue → Deep Blue. Use Neon Yellow only for the highlight of the overlap, as an accent.
- Never rely on color alone. Each marker and band also has a text label and a pattern or outline.

Use the gradient view for: temperature (day, night, noon, midnight), elevation, slope, roughness, illumination, and radiation where data exists.

### Rules
- Compare temperature only when measurement type, local solar time, and solar conditions match. Otherwise show "not comparable" with the reason.
- Missing values show as "No data available". Never plot a missing value as zero.
- Every value shows its source and observation basis.
- Show the comparison as both a table and a gradient, so both experts and the public can read it.

## 10. Condition Filters (Phase 1 selection, Phase 2 live ranking)

Scientific conditions the user can select:
- Geological similarity
- Mineral composition
- Terrain and elevation
- Slope and roughness
- Temperature (day, night, noon, midnight)
- Water and ice
- Dust and atmospheric conditions
- Radiation
- Biology and habitability
- Caves and subsurface environments
- Robotic exploration suitability
- Human exploration suitability

Additional filters: country and continent, accessibility for research, availability of scientific data, data quality and completeness, estimated research costs, operational complexity.

Behavior:
- Selecting conditions sets which parameters the comparison (section 9) shows.
- Phase 2: changing a filter or weight re-ranks the Earth analogs immediately and shows which positions changed.

## 11. Earth Location Profiles

Sections:
- General information: name, country, coordinates, geographical region, elevation, terrain description.
- Visual information: real photographs, satellite imagery, geological maps, elevation visualizations, and AI-generated illustrations.
- Scientific analysis: geology, mineralogy and surface materials, temperature and climate, water and ice, dust and erosion, biology, subsurface structures, exploration suitability.
- Moon comparison: the same gradient view as section 9, limited to that site.
- Limitations and uncertainties, and potential applications for future missions.

Image rules:
- Label every image as a real photograph, a scientific visualization, or an AI-generated illustration.
- Label every AI-generated image: "Illustrative, AI-generated. Not scientific evidence."
- Store each image's source, credit, license, and date.
- Show only images whose license permits display.

## 12. AI Scientific Explanation Engine (Phase 2)

For each Earth analog, answer:
1. Why is this location comparable to the selected lunar region?
2. Which scientific characteristics are similar?
3. Which characteristics are different?
4. What can scientists learn from studying this location?
5. What technologies could be tested there?
6. How could this location help prepare for future lunar missions?
7. What are the scientific limitations of this analogy?

Rules:
- Use only validated catalog data and cited sources.
- Tie every claim to a source ID.
- Show a confidence indicator (high, medium, or low) with its reason.
- Never invent measurements, citations, or conclusions. If data is missing, say so.
- Label AI-written text as AI-generated.

## 13. Economic Feasibility (Phase 2)

An assumptions calculator, not a business plan.
- Cost categories: research and development, infrastructure, transportation and logistics, equipment and robotics, personnel, maintenance, data acquisition, environmental compliance and permits.
- Revenue and funding categories: research partnerships, university collaborations, scientific grants, government contracts, educational products, commercial research services, data and analysis services.
- All inputs are editable. Defaults are labelled "placeholder assumption".
- Outputs: estimated initial investment, recurring operating costs, funding sources, low, base, and high scenarios, and break-even only when the user's inputs allow it.
- Every output is labelled "Estimate based on user assumptions". Never state guaranteed revenue or profitability.
- Include financial risks and uncertainties.

## 14. Data Sources and Methodology

- List every source: agency or institution, dataset name, version, URL, and access date.
- For each important result: original source, dataset, observation basis, coordinates, units, data quality, processing method, and uncertainty.
- Show where data is unavailable. Never fabricate values.
- Document the scoring method and its version.
- Note the Google Drive folder as the internal source for each file used, by file ID.

## 15. Design and Experience

Brand guidelines (from the "vision and guidelines" folder in Drive):

Color palette:
- Blue Yonder #2E96F5
- Neon Blue #0960E1
- Electric Blue #0042A6 (PMS 2146 C)
- Deep Blue #07173F (PMS 295 C)
- Rocket Red #E43700
- Martian Red #8E1100
- Neon Yellow #EAFE07 (PMS Neon 387)
- White #FFFFFF

Color rules:
- Use blue as the main palette.
- Use Neon Yellow as an accent for text, buttons, and symbols only. Never as a background.
- Body text only on Deep Blue, Electric Blue, or White.
- Do not use Rocket Red as a background color.
- Contrast ratio for text and key UI combinations must meet or exceed 4.5:1. Check with the WebAIM Contrast Checker.

Gradient rule:
- Background gradient is linear, at 45°, from Electric Blue at the top-left to Deep Blue at the bottom-right.
- The transition must be gentle across the whole field, with no visible band or abrupt change.

Typography:
- Headings: Fira Sans Black and Fira Sans Bold.
- Body copy: Overpass Regular, Overpass Bold, and Overpass Italic.
- Both families are open-source and available on Google Fonts.

Logos:
- Use the NASA Space Apps logos only as the guidelines allow. Check the logo pack before use.

Experience:
- Dark, space-inspired interface with high-quality planetary imagery.
- A top header on every page reads "SPACE APPS CHALLENGE 2026", with the challenge name "Identify Earth Locations that Analog the Permanent Moon Base Locations and Mars" beneath it. Use white or Neon Yellow on Deep Blue so the text meets the 4.5:1 contrast rule.
- A footer on every page and a Credits page name the creators: Alisson Dayhana Garcia Rios, Yinuo Tong, Diana Krasniqi, Laura Isabel Silvestri, and Yu Zhu.
- Interactive scientific maps and clean data visualizations.
- Responsive desktop and mobile layouts.
- Plain-language summaries first, detail on demand.
- Keyboard navigation, text alternatives for images and charts, and color that is never the only signal.
- 3D controls: drag to rotate, scroll or pinch to zoom, click to select. Every 3D selection also has a keyboard path and a list equivalent.
- A reduced-motion option that disables automatic rotation and fly-to animations.
- A 2D fallback table for devices that cannot render WebGL.

Main navigation:
- Home / Dashboard
- Moon 3D Explorer
- Mars Explorer (Coming soon)
- Earth Analog Finder
- Earth 3D Globe
- Earth Location Profiles
- Scientific Comparison
- Economic Feasibility
- Data Sources and Methodology

## 16. Technical Architecture

Build as modular components so datasets, planets, criteria, and tools can be added later:
- Data layer: catalog storage, Google Drive pipeline, preprocessing of large CSVs, validation and status tracking.
- Scoring module: pure, versioned functions with no UI code. Planet-agnostic, so a Mars module can reuse it.
- 3D scene module: planet-agnostic Three.js scene that renders any body as a textured sphere with layers and markers. The Moon and the Earth are two instances. Mars can be added later as another instance.
- Comparison module: builds the parameter table and gradient data from the selected conditions.
- Profile module: renders any Earth site from its catalog record.
- AI module (Phase 2): explanation generation constrained to catalog data and sources.
- Economics module (Phase 2): independent calculator.

Storage and security:
- Store the catalog, sources, and validation status in the app database.
- Keep API keys and credentials in project secrets, never in code.
- Google Maps calls, if used for optional views, stay behind authenticated app endpoints, with capped batch sizes and cached results.
- Access control: [OPEN DECISION: internal team only, or public website with user accounts].

Data handling:
- If live data is unavailable, use sample data clearly labelled "Sample data for interface demonstration only".
- Never use fabricated datasets to simulate scientific accuracy.

## 17. Acceptance Criteria for Phase 1

- A user can select a point on the 3D Moon and receive 10 ranked Earth analogs, or fewer with a stated reason.
- Each score shows its criterion breakdown, coverage percentage, and measured or estimated split.
- The Earth 3D globe shows the top 10 markers. Clicking one rotates the globe to it and opens its ranking.
- The Moon 3D Explorer shows the Moon in space. Clicking a point selects that location and updates the Earth analogs.
- The 3D views work on desktop and mobile, with a 2D fallback and a reduced-motion option.
- The Scientific Comparison shows, for the selected conditions, a parameter table and a gradient for each parameter, with similar ranges highlighted.
- Temperature comparisons appear only when measurement type and local solar time match.
- Each Earth profile and comparison value shows its source.
- The Mars Explorer page shows "Coming soon" and no Mars data.
- Every 3D selection, marker, and comparison shows its coordinates in decimal degrees.
- Every page header shows "SPACE APPS CHALLENGE 2026" and the challenge name, and the footer and Credits page list all five creators.
- The Google Drive inventory lists every file with its validation status.
- The interface follows the brand palette, the 45° gradient rule, and the 4.5:1 contrast rule.
- No value is shown without a source, and no missing value is filled in.

## 18. Open Decisions

1. Access model: internal team only, or public website with accounts?
2. Which Drive files pass validation (confirmed after the inventory)?
3. Earth terrain resolution to ship: 0.5° or 0.25°?
4. Image licensing: public-domain and CC-licensed images only, or paid sources too?
5. Final weights and normalization method, confirmed with the scientific team.
6. Whether the custom domain will need its own Google Maps key (only if optional Google views are added).
7. Earth globe engine: a custom Three.js globe (recommended, same engine as the Moon), or Google Photorealistic 3D Tiles (real photographic terrain, subject to Google usage limits and key setup).
8. Moon texture and elevation resolution for web delivery, and whether exaggerated elevation should be available by default (proposed: off).
