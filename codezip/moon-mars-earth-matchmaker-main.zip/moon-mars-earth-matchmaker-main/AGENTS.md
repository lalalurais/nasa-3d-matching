<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules
- The explorer (`src/components/Explorer.tsx`, route `/`, `?world=moon|mars`) is driven by `src/lib/bodies.ts`; each world is a body entry with its own texture, grid (`public/data/<id>-grid.json`), criteria and presets, never a separate page, so the workflow stays shared. `/mars` only redirects.
- Scoring lives in `src/lib/scoring.ts` as pure, versioned functions; criteria and which ones are rankable live in `src/lib/criteria.ts`. Keeps the method testable and auditable.
- Same quantity, unit and footprint on both worlds → shared 5th–95th percentile scale; different quantities → `VarMeta.scoreMode: "percentile"` (each world's own percentile); a criterion with no data for a world has `scored: []` and an `excludedReason`. Raw numbers of different quantities are never compared.
- Planet-side units, sources and notes come from `planetSide(body, key)` in `src/lib/data.ts`; UI must not read `moonUnit`/`moonSrc` directly, so Mars labels stay correct.
- Region size matches Earth's ~55 km 0.5° cell: Moon 2° bins, Mars 1° bins. Keeps footprints comparable.
- App data is prebuilt from the team Google Drive by `scripts/preprocess_drive.py`, `scripts/add_relief.py`, `scripts/preprocess_mars.py`, `scripts/add_moon_illum.py` (Moon sunlight from the Drive SPICE kernels) and `scripts/extract_costs.py` into `public/data/` and `src/data/`; never load raw Drive files in the browser (they are hundreds of MB).
- Geochemistry & mineralogy is scored by rock class (`src/lib/lithology.ts`, `scoreMode: "category"` with a match table), never raw chemistry; planet classes are rasterised from published geologic maps by `scripts/add_illum_litho.py`. Solar illumination is a separate criterion. Keeps the two concerns independent and auditable.
- Reverse search (`reverseSearch` in `src/lib/analogs.ts`) and landing recommendations (`src/lib/landing.ts`) reuse the same calibration and pure scoring as the forward search; the explorer switches between them with the selection `mode`. One method, three directions.
- Gravity is applied only where physics scales with it (weight, mass offload, cohesionless bearing capacity) via `terramechanics()` in `src/lib/landing.ts`; soil data is never multiplied by a gravity ratio.
- The consultation report (`/report`) is rebuilt entirely from its URL search params (world, lat, lon, site, criteria), so a report link can be shared and reopened without accounts or storage.
- Feedback form (`/feedback`) saves each message as a text file in the team Drive "Website feedback" folder via `src/lib/feedback.functions.ts` (server-side Drive connector); no database, per team choice.
