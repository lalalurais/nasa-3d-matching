<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Visitors find the Earth places that best stand in for a chosen lunar region.

## Metric

Earth analog comparisons opened for a selected Moon region each week
