import { createFileRoute } from "@tanstack/react-router";
import { PageTitle } from "@/components/Layout";
import { ComparisonTable, CriteriaChips } from "@/components/Shared";
import { useAnalogs, useSelection } from "@/lib/selection";

function Page() {
  const s = useSelection(); const a = useAnalogs();
  const top = a.loading ? [] : (a.ranking?.ranked.slice(0, 3).map((r) => r.item.id) ?? []);
  const ids = s.compare.length ? s.compare : s.siteId ? [s.siteId] : top;
  return (
    <div>
      <PageTitle title="Scientific Comparison" intro="Compare the selected Moon or Mars region with up to four Earth places. Add places from the Explorer result panel; otherwise the top three are shown." />
      <CriteriaChips />
      <ComparisonTable siteIds={ids} />
    </div>
  );
}
export const Route = createFileRoute("/compare")({
  ssr: false,
  head: () => ({ meta: [{ title: "Scientific Comparison · Space2Earth" }, { name: "description", content: "Moon or Mars region vs Earth analog places, value by value with sources." }, { property: "og:title", content: "Scientific Comparison · Space2Earth" }, { property: "og:description", content: "Moon or Mars region vs Earth analog places, value by value with sources." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Page,
});
