import { createFileRoute, redirect } from "@tanstack/react-router";

/** Moon uses the shared explorer; this path opens it with Moon on the left globe. */
export const Route = createFileRoute("/moon")({
  beforeLoad: () => { throw redirect({ to: "/", search: { world: "moon" } }); },
  head: () => ({ meta: [{ title: "Moon Explorer · Space2Earth" }, { name: "description", content: "Pick a Moon region and find the closest Earth analog places." }, { property: "og:title", content: "Moon Explorer · Space2Earth" }, { property: "og:description", content: "Pick a Moon region and find the closest Earth analog places." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
});
