import { createFileRoute } from "@tanstack/react-router";
import { PageTitle, CREATORS } from "@/components/Layout";
function Page(){ return <div><PageTitle title="Credits" intro="Space2Earth was created for the NASA Space Apps Challenge 2026 by:" /><ul className="space-y-2 text-lg">{CREATORS.map(c=><li key={c} className="rounded border bg-card p-3 font-bold">{c}</li>)}</ul><p className="mt-6 text-sm text-muted-foreground">Imagery: NASA SVS CGI Moon Kit (LROC color), NASA Visible Earth Blue Marble, Mars colour map by Solar System Scope (CC BY 4.0, based on NASA data) with NASA MGS MOLA heights. Logos: NASA Space Apps 2026 pack.</p></div> }
export const Route = createFileRoute("/credits")({
  ssr: false,
  head: () => ({ meta: [{ title: "Credits · Space2Earth" }, { name: "description", content: "The team behind Space2Earth." }, { property: "og:title", content: "Credits · Space2Earth" }, { property: "og:description", content: "The team behind Space2Earth." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Page,
});
