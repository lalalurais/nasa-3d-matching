import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Printer, Link2, ArrowLeft } from "lucide-react";
import lucerne from "@/assets/nasa-space-apps-lucerne.png.asset.json";
import { ValuesTable } from "@/components/Explorer";
import { earthGridQuery, fmtValue, gridQuery, moonCell, planetSide, SITES, SOURCES, sourceUrl, VAR_BY_KEY, type BodyId, type EarthGrid, type MoonGrid, type SourceKey, type VarKey } from "@/lib/data";
import { bodyById } from "@/lib/bodies";
import { selectedCriteria, scoredKeys, toScoreCriteria } from "@/lib/criteria";
import { computeBounds, distanceKm, prepare, resolveEarthSite } from "@/lib/analogs";
import { METHOD_VERSION, score } from "@/lib/scoring";
import { LANDING_FACTORS, landingScorer, terramechanics, GRAVITY } from "@/lib/landing";
import { COSTS, logisticsFor, NASA_CENTERS, simulate, transportCost } from "@/lib/costs";
import { fmtCoord } from "@/lib/geo";

type Search = { world?: BodyId; lat?: number; lon?: number; site?: string; c?: string };

export const Route = createFileRoute("/report")({
  ssr: false,
  validateSearch: (s: Record<string, unknown>): Search => {
    const num = (v: unknown) => (typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : undefined);
    const out: Search = {};
    if (s["world"] === "moon" || s["world"] === "mars") out.world = s["world"];
    const lat = num(s["lat"]), lon = num(s["lon"]);
    if (lat !== undefined) out.lat = lat;
    if (lon !== undefined) out.lon = lon;
    if (typeof s["site"] === "string") out.site = s["site"];
    if (typeof s["c"] === "string") out.c = s["c"];
    return out;
  },
  head: () => ({ meta: [
    { title: "Consultation Report · Space2Earth" },
    { name: "description", content: "Mission analog consultation report: Moon or Mars region vs an Earth test place, with scores, sources, landing, gravity and cost notes." },
    { property: "og:title", content: "Consultation Report · Space2Earth" },
    { property: "og:description", content: "Mission analog consultation report: Moon or Mars region vs an Earth test place, with scores, sources, landing, gravity and cost notes." },
    { property: "og:type", content: "article" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: Page,
});

const pct = (x: number | null | undefined) => (x == null ? "—" : `${Math.round(x * 100)}`);
const usd = (v: number) => v.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
const field = "w-24 rounded border bg-deep-blue px-2 py-1 print:border-0 print:bg-transparent";

function Page() {
  const q = Route.useSearch();
  const world: BodyId = q.world ?? "moon";
  const g = useQuery(gridQuery(world));
  const e = useQuery(earthGridQuery);
  if (q.lat == null || q.lon == null || !q.site) {
    return (
      <div className="mx-auto max-w-2xl rounded-lg border bg-card p-6">
        <h1 className="text-3xl">Consultation report</h1>
        <p className="mt-2">A report is made for one Moon or Mars region and one Earth place. In the Explorer, select a pair and press <b>Consultation report for this pair</b>.</p>
        <Link to="/" search={{ world }} className="mt-4 inline-block rounded bg-primary px-4 py-2 font-bold text-primary-foreground">Open the Explorer</Link>
      </div>
    );
  }
  if (g.error || e.error) return <p role="alert">The data failed to load. Please reload the page.</p>;
  if (!g.data || !e.data) return <p className="text-muted-foreground">Preparing the report…</p>;
  return <Report world={world} lat={q.lat} lon={q.lon} siteId={q.site} crit={(q.c ?? "terrain").split(",").filter(Boolean)} grid={g.data} earth={e.data} />;
}

function Report({ world, lat, lon, siteId, crit, grid, earth }: { world: BodyId; lat: number; lon: number; siteId: string; crit: string[]; grid: MoonGrid; earth: EarthGrid }) {
  const body = bodyById(world);
  const calib = useMemo(() => computeBounds(grid, scoredKeys(body.criteria) as VarKey[], SITES, body.id, earth), [grid, earth, body]);
  const sel = selectedCriteria(body.criteria, crit);
  const keys = scoredKeys(sel.rankable) as VarKey[];
  const cell = moonCell(grid, lat, lon);
  const site = resolveEarthSite(siteId, earth);
  const [mass, setMass] = useState(100);
  const [frag, setFrag] = useState(1.5);
  const [iter, setIter] = useState(1);
  const [rate, setRate] = useState("");
  const [copied, setCopied] = useState(false);
  const today = useMemo(() => new Date(), []);
  if (!site) return <p role="alert" className="rounded border p-3">This Earth place is not in the catalog or the Earth land grid.</p>;

  const result = score(prepare(cell.values, site, keys, calib), toScoreCriteria(sel.rankable));
  const land = landingScorer(grid, body.id)(cell.index);
  const tm = terramechanics(body.id, mass);
  const sim = simulate(mass, frag, iter);
  const center = NASA_CENTERS.map((c) => ({ c, km: distanceKm(c, site) })).sort((a, b) => a.km - b.km)[0]!;
  const rateNum = rate.trim() === "" ? null : Number(rate);
  const tc = transportCost(center.c, site, mass, frag, iter, rateNum);
  const lg = site.discovery ? null : logisticsFor(site.id);
  const u = grid.unit?.[cell.index]; const unit = u != null && u >= 0 ? grid.unitNames?.[u] : null;
  const ref = `S2E-${world.toUpperCase()}-${today.toISOString().slice(0, 10).replace(/-/g, "")}-${Math.abs(Math.round(cell.cellLat * 10))}${cell.cellLat < 0 ? "S" : "N"}${Math.round(cell.cellLon * 10)}E-${site.discovery ? site.id.replace("new-", "C") : site.id.toUpperCase()}`;
  const allKeys = [...keys, ...sel.all.flatMap((c) => c.context)] as VarKey[];
  const srcs = Array.from(new Set(allKeys.flatMap((k) => [planetSide(world, k).src, VAR_BY_KEY[k].earthSrc]).filter((x): x is SourceKey => !!x)));
  const worldName = world === "moon" ? "the Moon" : "Mars";

  return (
    <article className="mx-auto max-w-4xl space-y-6 print:max-w-none print:space-y-4" aria-labelledby="rep-h">
      <div className="flex flex-wrap gap-2 print:hidden">
        <Link to="/" search={{ world }} className="inline-flex items-center gap-1 rounded border px-3 py-1 text-sm"><ArrowLeft className="h-4 w-4" aria-hidden /> Back to the Explorer</Link>
        <button type="button" onClick={() => window.print()} className="inline-flex items-center gap-1 rounded bg-primary px-3 py-1 text-sm font-bold text-primary-foreground"><Printer className="h-4 w-4" aria-hidden /> Print / save as PDF</button>
        <button type="button" onClick={async () => { try { await navigator.clipboard.writeText(window.location.href); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch { window.prompt("Copy this report link", window.location.href); } }} className="inline-flex items-center gap-1 rounded border px-3 py-1 text-sm"><Link2 className="h-4 w-4" aria-hidden /> {copied ? "Link copied!" : "Copy report link"}</button>
      </div>

      <header className="flex items-start gap-4 border-b pb-4">
        <img src={lucerne.url} alt="NASA Space Apps Lucerne logo" className="h-16 w-16 rounded-full" />
        <div className="min-w-0 flex-1">
          <p className="font-display text-xs font-black tracking-[0.2em] text-highlight">SPACE2EARTH · CONSULTATION REPORT</p>
          <h1 id="rep-h" className="text-2xl md:text-3xl">{body.name} region {fmtCoord(cell.cellLat, cell.cellLon)} vs {site.discovery ? `Earth place ${fmtCoord(site.lat, site.lon)}` : site.name}</h1>
          <p className="mt-1 text-sm">Reference <b>{ref}</b> · {today.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })} · method v{METHOD_VERSION}</p>
        </div>
        <div className="text-right"><p className="font-display text-4xl font-black text-highlight">{pct(result.overall)}</p><p className="text-xs">{result.strength} analogy · coverage {pct(result.coverage)}%</p></div>
      </header>

      <Section n={1} title="Summary">
        <dl className="grid gap-x-6 gap-y-1 text-sm sm:grid-cols-[auto_1fr]">
          <dt className="font-bold">{body.name} region</dt><dd>{fmtCoord(cell.cellLat, cell.cellLon)} · {cell.step}° data bin{unit ? ` · ${unit}` : ""}</dd>
          <dt className="font-bold">Earth place</dt><dd>{site.discovery ? `${fmtCoord(site.lat, site.lon)} · 0.5° land cell, not in the analog catalog` : `${site.name}, ${site.country} · ${fmtCoord(site.lat, site.lon)}`}</dd>
          <dt className="font-bold">Criteria ranked</dt><dd>{sel.rankable.map((c) => c.label).join(", ") || "None"}</dd>
          {sel.viewOnly.length > 0 && <><dt className="font-bold">Not ranked</dt><dd>{sel.viewOnly.map((c) => c.label).join(", ")}</dd></>}
          <dt className="font-bold">Result</dt><dd>{result.overall == null ? "No score: no comparable data for these criteria." : `${pct(result.overall)} / 100 — ${result.strength} analogy${result.limited ? " (limited coverage: read with care)" : ""}`}</dd>
        </dl>
        <p className="mt-2 text-xs text-muted-foreground">Scores show similar tendencies over ~55–60 km regions, never identical places.</p>
      </Section>

      <Section n={2} title="Score by criterion">
        <ul className="space-y-2 text-sm">
          {sel.rankable.map((c) => (
            <li key={c.key}>
              <div className="flex justify-between"><b>{c.label}</b><span>{pct(result.criteria[c.key])}</span></div>
              <div className="h-2 rounded bg-muted print:border"><div className="h-2 rounded bg-highlight" style={{ width: `${(result.criteria[c.key] ?? 0) * 100}%` }} /></div>
              <p className="text-xs text-muted-foreground">{c.method}</p>
            </li>
          ))}
          {sel.viewOnly.map((c) => <li key={c.key} className="text-xs"><b>{c.label}:</b> not ranked. {c.excludedReason}</li>)}
        </ul>
      </Section>

      <Section n={3} title="Side-by-side measurements and sources">
        <ValuesTable keys={allKeys} moon={cell} site={site} body={world} />
      </Section>

      <Section n={4} title={`Landing suitability of the ${body.name} region`}>
        {!land ? <p className="text-sm">Not enough data here for a landing index (slope and relief are required).</p> : (
          <>
            <p className="text-sm">Landing index <b>{pct(land.lsi)} / 100</b> — mean of the factors below, each the region's rank within {worldName} (100 = best).</p>
            <ul className="mt-2 grid gap-1 text-sm sm:grid-cols-2">
              {LANDING_FACTORS[world].map((f) => <li key={f.key}><b>{f.label}:</b> {land.factors[f.key] == null ? "No data available" : pct(land.factors[f.key])} <span className="text-xs text-muted-foreground">({fmtValue(f.key, cell.values[f.key], world)})</span></li>)}
            </ul>
            <p className="mt-1 text-xs text-muted-foreground">Screening aid at regional scale, not landing-safety certification.</p>
          </>
        )}
      </Section>

      <Section n={5} title="Gravity and terramechanics test advice">
        <p className="text-sm">Gravity on {worldName} is {GRAVITY[world]} m/s², {tm.ratio.toFixed(3)}× Earth's {GRAVITY.earth} m/s². Field tests on Earth must correct for this:</p>
        <label className="mt-2 flex items-center gap-2 text-sm">Rover or lander mass (kg)<input type="number" min={0} value={mass} onChange={(ev) => setMass(Math.max(0, +ev.target.value || 0))} className={field} /></label>
        <dl className="mt-2 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-[auto_1fr]">
          <dt className="font-bold">Weight on {worldName}</dt><dd>{tm.planetWeightN.toFixed(0)} N</dd>
          <dt className="font-bold">Weight on Earth</dt><dd>{tm.earthWeightN.toFixed(0)} N</dd>
          <dt className="font-bold">Offload needed in Earth tests</dt><dd>{tm.offloadN.toFixed(0)} N (a tether or counterweight carries this, so the wheels feel {worldName}'s load)</dd>
          <dt className="font-bold">Equivalent test mass</dt><dd>{tm.testMassKg.toFixed(1)} kg</dd>
          <dt className="font-bold">Soil bearing capacity</dt><dd>The same loose soil carries about {tm.bearingFactor.toFixed(1)}× more load on Earth (it scales with unit weight γ = ρ·g), so wheel sinkage looks better on Earth than it will be on {worldName}.</dd>
        </dl>
        <p className="mt-2 text-xs text-muted-foreground">Do not scale: friction angle, angle of repose, grain density and cohesion — these are soil properties, not gravity effects. Raw soil data is therefore never multiplied by {tm.ratio.toFixed(2)}.</p>
      </Section>

      <Section n={6} title="Economic feasibility and logistics">
        <div className="flex flex-wrap gap-4 text-sm print:hidden">
          <label className="flex items-center gap-2">Fragility<input type="number" step={0.1} min={1} max={3} value={frag} onChange={(ev) => setFrag(Math.min(3, Math.max(1, +ev.target.value || 1)))} className={field} /></label>
          <label className="flex items-center gap-2">Test iterations<input type="number" min={1} value={iter} onChange={(ev) => setIter(Math.max(1, Math.round(+ev.target.value || 1)))} className={field} /></label>
          <label className="flex items-center gap-2">Shipping rate ($/kg/1,000 km)<input inputMode="decimal" value={rate} onChange={(ev) => setRate(ev.target.value)} placeholder="Enter a rate" className={field} /></label>
        </div>
        <p className="hidden text-sm print:block">Mass {mass} kg · fragility {frag}× · {iter} iteration(s){rateNum != null ? ` · shipping ${rate} $/kg/1,000 km` : ""}</p>
        <table className="mt-2 w-full text-sm">
          <thead><tr className="text-left text-xs text-muted-foreground"><th className="py-1">Where</th><th>All iterations</th><th>Saved by testing on Earth</th></tr></thead>
          <tbody>
            <tr className="border-t"><td className="py-1 font-bold">Earth analog site</td><td>{usd(sim.earth.total)}</td><td>—</td></tr>
            <tr className="border-t"><td className="py-1 font-bold">{body.name} surface</td><td>{usd(sim[world].total)}</td><td className="font-bold">{usd(sim[world].savings)} ({(sim[world].reduction * 100).toFixed(2)}%)</td></tr>
          </tbody>
        </table>
        <p className="mt-2 text-sm">Nearest NASA center: <b>{center.c.name}</b>, {Math.round(tc.km).toLocaleString("en-US")} km straight-line. Transport: {tc.total == null ? "enter a shipping rate (the team spreadsheet has none yet)" : `${usd(tc.total)} for all iterations`}.</p>
        {lg && <p className="mt-1 text-sm"><b>Logistics:</b> {lg.logistics} <b>Cost parallels:</b> {lg.parallels}</p>}
        {!site.discovery && <p className="mt-1 text-sm"><b>Access:</b> {site.access}</p>}
        <p className="mt-1 text-xs text-muted-foreground">Simulated benchmark rates from {COSTS.source}, not quotes.</p>
      </Section>

      <Section n={7} title="Next steps for the consultation">
        <ol className="list-decimal space-y-1 pl-5 text-sm">
          <li>Confirm the match on the ground: {site.discovery ? "this place is a data candidate only; check land use, access and geology on site." : `field check at ${site.name}${site.use ? ` (known uses: ${site.use})` : ""}.`}</li>
          <li>Plan tests around the strongest criteria above and treat the weakest as a known gap.</li>
          <li>Apply the gravity corrections in section 5 to rover, lander and soil tests.</li>
          <li>Get a freight quote for the shipping rate and update section 6.</li>
          <li>Return this report to the Space2Earth team with the reference <b>{ref}</b> (share the link or the saved PDF).</li>
        </ol>
      </Section>

      <Section n={8} title="Sources and limits">
        <ul className="list-disc space-y-0.5 pl-5 text-xs">
          {srcs.map((k) => <li key={k}><a className="underline" href={sourceUrl(k)} target="_blank" rel="noopener noreferrer">{SOURCES[k].dataset}</a> — {SOURCES[k].basis}</li>)}
        </ul>
        <p className="mt-2 text-xs text-muted-foreground">Missing values are shown as “No data available”, never filled. Different quantities are compared only by each world's own percentile. Earth temperatures are modelled; Moon and Mars values are orbital measurements or maps.</p>
      </Section>
    </article>
  );
}

function Section({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section className="break-inside-avoid rounded-lg border bg-card p-4 print:border-0 print:p-0">
      <h2 className="mb-2 text-xl">{n}. {title}</h2>
      {children}
    </section>
  );
}
