import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageTitle } from "@/components/Layout";
import { centerById, COSTS, NASA_CENTERS, rateOf, simulate, transportCost } from "@/lib/costs";
import { SITES } from "@/lib/data";

const usd = (v: number) => v.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

function Page() {
  const [mass, setMass] = useState(100);
  const [frag, setFrag] = useState(1.5);
  const [iter, setIter] = useState(1);
  const [scen, setScen] = useState("");
  const r = simulate(mass, frag, iter);
  const [center, setCenter] = useState<string>("ksc");
  const [siteId, setSiteId] = useState<string>(SITES[0]!.id);
  const [rate, setRate] = useState("");
  const site = SITES.find((x) => x.id === siteId) ?? SITES[0]!;
  const rateNum = rate.trim() === "" ? null : Number(rate);
  const tc = transportCost(centerById(center), site, mass, frag, iter, rateNum);
  const pick = (id: string) => {
    setScen(id);
    const sc = COSTS.scenarios.find((x) => x.id === id);
    if (sc) { setMass(sc.massKg); setFrag(sc.multiplier); }
  };
  const field = "w-full rounded border bg-deep-blue px-2 py-1";
  return (
    <div className="space-y-6">
      <PageTitle title="Economic Feasibility" intro="How much testing on Earth first can save compared with testing on the Moon or Mars. Rates and scenarios come from the team's cost simulator spreadsheet." />
      <div className="grid gap-6 md:grid-cols-3 [&>*]:min-w-0">
        <div className="space-y-3 rounded-lg border bg-card p-4">
          <h2 className="text-lg">Experiment</h2>
          <label className="block text-sm">Start from a scenario
            <select value={scen} onChange={(e) => pick(e.target.value)} className={field}>
              <option value="">Custom</option>
              {COSTS.scenarios.map((s) => <option key={s.id} value={s.id}>{s.id} · {s.experiment} ({s.massKg} kg, {s.target})</option>)}
            </select>
          </label>
          <label className="block text-sm">Payload mass (kg)<input type="number" min={0} value={mass} onChange={(e) => { setScen(""); setMass(Math.max(0, +e.target.value || 0)); }} className={field} /></label>
          <label className="block text-sm">Fragility multiplier: {frag.toFixed(1)}×
            <input type="range" min={1} max={3} step={0.1} value={frag} onChange={(e) => { setScen(""); setFrag(+e.target.value); }} className="w-full accent-[var(--neon-yellow)]" />
            <span className="text-xs text-muted-foreground">1.0× rugged · 1.5× delicate optics · 2.5× bio / quantum lab</span>
          </label>
          <label className="block text-sm">R&amp;D test iterations<input type="number" min={1} value={iter} onChange={(e) => setIter(Math.max(1, Math.round(+e.target.value || 1)))} className={field} /></label>
        </div>
        <div className="space-y-3 rounded-lg border bg-card p-4 md:col-span-2">
          <h2 className="text-lg">Cost per destination</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-xs text-muted-foreground"><th className="py-1">Where</th><th>Rate</th><th>One test</th><th>All iterations</th><th>Saved by testing on Earth</th></tr></thead>
              <tbody>
                <tr className="border-t"><td className="py-2 font-bold">Earth analog site</td><td>{usd(rateOf("earth").ratePerKg)}/kg + {usd(rateOf("earth").fixed)}</td><td>{usd(r.earth.single)}</td><td>{usd(r.earth.total)}</td><td>—</td></tr>
                {(["moon", "mars"] as const).map((d) => (
                  <tr key={d} className="border-t"><td className="py-2 font-bold">{d === "moon" ? "Moon surface" : "Mars surface"}</td><td>{usd(rateOf(d).ratePerKg)}/kg + {usd(rateOf(d).fixed)}</td><td>{usd(r[d].single)}</td><td>{usd(r[d].total)}</td><td className="font-bold text-highlight">{usd(r[d].savings)} ({(r[d].reduction * 100).toFixed(2)}%)</td></tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground">Formula from the spreadsheet: mass × rate × fragility + fixed operations, times the number of iterations. Simulated benchmark rates, not quotes. Source: {COSTS.source}.</p>
        </div>
      </div>
      <section className="rounded-lg border bg-card p-4">
        <h2 className="mb-1 text-lg">Transport from NASA to the test site</h2>
        <p className="mb-3 text-xs text-muted-foreground">The team spreadsheet has no shipping price yet, so enter your own rate (for example from a freight quote). Distance is the straight-line distance; real routes are longer.</p>
        <div className="grid gap-3 md:grid-cols-3">
          <label className="block text-sm">Ships from<select value={center} onChange={(e) => setCenter(e.target.value)} className={field}>{NASA_CENTERS.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
          <label className="block text-sm">Earth test site<select value={siteId} onChange={(e) => setSiteId(e.target.value)} className={field}>{SITES.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label>
          <label className="block text-sm">Shipping rate ($ per kg per 1,000 km)<input inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="Enter a rate" className={field} /></label>
        </div>
        <dl className="mt-3 grid grid-cols-3 gap-3 text-sm">
          <div><dt className="text-xs text-muted-foreground">Distance</dt><dd className="font-bold">{Math.round(tc.km).toLocaleString("en-US")} km</dd></div>
          <div><dt className="text-xs text-muted-foreground">Transport per test</dt><dd className="font-bold">{tc.perTest == null ? "No rate entered" : usd(tc.perTest)}</dd></div>
          <div><dt className="text-xs text-muted-foreground">Earth total incl. transport</dt><dd className="font-bold text-highlight">{tc.total == null ? "No rate entered" : usd(r.earth.total + tc.total)}</dd></div>
        </dl>
        <p className="mt-2 text-xs text-muted-foreground">Transport = mass × fragility × rate × distance ÷ 1,000, times the iterations.</p>
      </section>
      <section className="rounded-lg border bg-card p-4">
        <h2 className="mb-2 text-lg">Analog site logistics</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-left text-xs text-muted-foreground"><th className="py-1">Site</th><th>Best match</th><th>Key parallels</th><th>Logistics</th></tr></thead>
            <tbody>{COSTS.sites.map((s) => (
              <tr key={s.name} className="border-t align-top"><td className="py-2 font-bold">{s.siteId ? <Link to="/sites/$id" params={{ id: s.siteId }} className="underline">{s.name}</Link> : s.name}<span className="block text-xs font-normal">{s.region}</span></td><td>{s.match}</td><td>{s.parallels}</td><td>{s.logistics}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
export const Route = createFileRoute("/economics")({
  ssr: false,
  head: () => ({ meta: [{ title: "Economic Feasibility · Space2Earth" }, { name: "description", content: "Cost simulator: savings from testing on Earth analog sites before Moon or Mars missions." }, { property: "og:title", content: "Economic Feasibility · Space2Earth" }, { property: "og:description", content: "Cost simulator: savings from testing on Earth analog sites before Moon or Mars missions." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Page,
});
