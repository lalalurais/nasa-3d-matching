import { createFileRoute } from "@tanstack/react-router";
import { PageTitle } from "@/components/Layout";
import { ComparisonTable, CriteriaChips } from "@/components/Shared";
import { googleMapsUrl } from "@/lib/data";
import { SITES } from "@/lib/data";
import { fmtCoord } from "@/lib/geo";
import { logisticsFor } from "@/lib/costs";
function Page(){ const { id } = Route.useParams(); const s=SITES.find(x=>x.id===id); const lg=logisticsFor(id);
if(!s) return <p>Site not found.</p>;
return (<div><PageTitle title={s.name} intro={`${s.country}, ${s.continent} · ${fmtCoord(s.lat,s.lon)}`} />
<div className="mb-6 grid gap-3 md:grid-cols-2 rounded-lg border bg-card p-4 text-sm">{[...(lg?[["Logistics & transport",lg.logistics],["Cost-model parallels",lg.parallels]]:[]),["Terrain",s.terrain],["Geology & materials",s.geology],["Water & ice",s.water],["Biology",s.biology],["Caves / lava tubes",s.caves?"Present":"None documented"],["Access",s.access],["Mission applications",s.use],["Literature source",s.ref]].map(([k,v])=><p key={k}><b>{k}:</b> {v}</p>)}
<p className="md:col-span-2 text-xs text-muted-foreground">Images: no licensed photographs added yet. Limits: Earth terrain from a 0.5° grid cell; temperatures are modelled reanalysis averages, not lunar-equivalent measurements.</p></div>
<p className="mb-6"><a className="underline font-bold text-highlight" href={googleMapsUrl(s.lat,s.lon)} target="_blank" rel="noopener noreferrer">Open in Google Maps</a></p><h2 className="mb-3 text-xl">Comparison with the selected Moon or Mars region</h2><CriteriaChips /><ComparisonTable siteIds={[s.id]} /></div>) }
export const Route = createFileRoute("/sites/$id")({
  ssr: false,
  head: () => ({ meta: [{ title: "Earth location profile · Space2Earth" }, { name: "description", content: "Earth analog site profile with Moon comparison." }, { property: "og:title", content: "Earth location profile · Space2Earth" }, { property: "og:description", content: "Earth analog site profile with Moon comparison." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Page,
});
