import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { PageTitle } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { sendFeedback, FEEDBACK_TYPES } from "@/lib/feedback.functions";

const T = "Feedback & Contact · Space2Earth", D = "Send feedback or request a scientific consultation from the Space2Earth team.";
export const Route = createFileRoute("/feedback")({
  head: () => ({ meta: [{ title: T }, { name: "description", content: D }, { property: "og:title", content: T }, { property: "og:description", content: D }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Page,
});

const field = "w-full rounded border bg-background px-3 py-2 text-sm";
function Page() {
  const send = useServerFn(sendFeedback);
  const [f, setF] = useState({ type: FEEDBACK_TYPES[0] as string, name: "", email: "", affiliation: "", message: "", website: "" });
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [err, setErr] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setState("sending"); setErr("");
    try { await send({ data: f }); setState("done"); }
    catch (x) { setState("error"); setErr(x instanceof Error && !x.message.startsWith("[") ? x.message : "Please check the fields and try again."); }
  }
  if (state === "done") return <div><PageTitle title="Thank you!" intro="Your message reached the Space2Earth team." /><Button onClick={() => { setF({ ...f, message: "" }); setState("idle"); }}>Send another message</Button></div>;
  return (
    <div className="max-w-xl">
      <PageTitle title="Feedback & Contact" intro="Tell us what you think, or ask for a consultation about a test site." />
      <form onSubmit={submit} className="space-y-4">
        <label className="block text-sm font-semibold">Topic<select className={field} value={f.type} onChange={set("type")}>{FEEDBACK_TYPES.map(t => <option key={t}>{t}</option>)}</select></label>
        <label className="block text-sm font-semibold">Name<input required maxLength={100} className={field} value={f.name} onChange={set("name")} /></label>
        <label className="block text-sm font-semibold">Email<input required type="email" maxLength={255} className={field} value={f.email} onChange={set("email")} /></label>
        <label className="block text-sm font-semibold">Organisation (optional)<input maxLength={150} className={field} value={f.affiliation} onChange={set("affiliation")} /></label>
        <label className="block text-sm font-semibold">Message<textarea required maxLength={3000} rows={6} className={field} value={f.message} onChange={set("message")} /></label>
        <input tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" value={f.website} onChange={set("website")} />
        {state === "error" && <p className="text-sm text-destructive">{err}</p>}
        <Button type="submit" disabled={state === "sending"}>{state === "sending" ? "Sending…" : "Send"}</Button>
      </form>
    </div>
  );
}
