import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { PageTitle } from "@/components/Layout";
import { SITES } from "@/lib/data";
import { fmtCoord } from "@/lib/geo";
function Page(){ return (<div><PageTitle title="Earth Location Profiles" intro="25 seed sites. Numeric values are sampled from the team's Drive datasets; descriptions summarise the cited literature." />
<ul className="grid gap-3 md:grid-cols-3">{SITES.map(s=><li key={s.id}><Link to="/sites/$id" params={{id:s.id}} className="block rounded-lg border bg-card p-4 hover:ring-2 hover:ring-highlight"><p className="font-bold">{s.name}</p><p className="text-xs text-muted-foreground">{s.country} · {fmtCoord(s.lat,s.lon)}</p><p className="mt-1 text-sm">{s.terrain}</p></Link></li>)}</ul></div>) }
export const Route = createFileRoute("/sites/")({
  ssr: false,
  head: () => ({ meta: [{ title: "Earth Location Profiles · Space2Earth" }, { name: "description", content: "All Earth analog sites in the Space2Earth catalog." }, { property: "og:title", content: "Earth Location Profiles · Space2Earth" }, { property: "og:description", content: "All Earth analog sites in the Space2Earth catalog." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Page,
});
