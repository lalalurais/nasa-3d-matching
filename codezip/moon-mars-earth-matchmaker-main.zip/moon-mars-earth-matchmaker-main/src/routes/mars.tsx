import { createFileRoute, redirect } from "@tanstack/react-router";

/** Mars uses the shared explorer; this path opens it with Mars on the left globe. */
export const Route = createFileRoute("/mars")({
  beforeLoad: () => { throw redirect({ to: "/", search: { world: "mars" } }); },
  head: () => ({ meta: [{ title: "Mars Explorer · Space2Earth" }, { name: "description", content: "Pick a Mars region and find the closest Earth analog places." }, { property: "og:title", content: "Mars Explorer · Space2Earth" }, { property: "og:description", content: "Pick a Mars region and find the closest Earth analog places." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
});
