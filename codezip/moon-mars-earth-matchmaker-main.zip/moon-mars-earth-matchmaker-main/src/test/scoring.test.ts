import { describe, expect, it } from "vitest";
import { makeBounds, rank, score, COVERAGE_THRESHOLD, MAX_RESULTS, type Prepared, type ScoreCriterion } from "@/lib/scoring";
import { MARS_CRITERIA, MOON_CRITERIA, isRankable, selectedCriteria } from "@/lib/criteria";
import { BODIES, MARS } from "@/lib/bodies";
import { binSizeKm, planetSide, VAR_BY_KEY, type MoonGrid, type Site } from "@/lib/data";
import { LANDING_FACTORS } from "@/lib/landing";
import { computeBounds } from "@/lib/analogs";

const b = makeBounds(Array.from({ length: 101 }, (_, i) => i)); // p5 = 5, p95 = 95
const terrain: ScoreCriterion = { key: "terrain", vars: [{ key: "relief", w: 1 }, { key: "range", w: 1 }] };
const P = (relief: number | null, range: number | null, moon = 50): Prepared => ({
  relief: { moon, earth: relief, bounds: b }, range: { moon, earth: range, bounds: b },
});

describe("ranking rules", () => {
  it("scores identical values as 100% similar", () => {
    expect(score(P(50, 50), [terrain]).overall).toBe(1);
  });
  it("rescales over available measurements and reports coverage", () => {
    const r = score(P(50, null), [terrain]);
    expect(r.overall).toBe(1);
    expect(r.coverage).toBe(0.5);
  });
  it("leaves out places below 60% coverage and lists them", () => {
    expect(COVERAGE_THRESHOLD).toBe(0.6);
    const items = [{ id: "a", p: P(50, 50) }, { id: "b", p: P(50, null) }];
    const out = rank(items, (x) => x.p, [terrain]);
    expect(out.ranked.map((r) => r.item.id)).toEqual(["a"]);
    expect(out.excluded.map((e) => e.item.id)).toEqual(["b"]);
  });
  it("shows at most 10 results", () => {
    expect(MAX_RESULTS).toBe(10);
    const items = Array.from({ length: 25 }, (_, i) => ({ id: `s${i}`, p: P(i * 4, i * 4) }));
    expect(rank(items, (x) => x.p, [terrain]).ranked).toHaveLength(10);
  });
  it("combines several selected criteria into one ranking", () => {
    const c2: ScoreCriterion = { key: "other", vars: [{ key: "x", w: 1 }] };
    const p: Prepared = { ...P(50, 50), x: { moon: 50, earth: 95, bounds: b } };
    const r = score(p, [terrain, c2]);
    expect(r.overall).toBeCloseTo((1 + (1 - 45 / 90)) / 2);
  });
  it("returns no ranking when no rankable criterion is selected", () => {
    expect(rank([{ id: "a", p: P(50, 50) }], (x) => x.p, []).ranked).toHaveLength(0);
  });
});

describe("Moon criteria", () => {
  it("ranks illumination and geochemistry as separate criteria", () => {
    expect(MOON_CRITERIA.filter(isRankable).map((c) => c.key)).toEqual(["terrain", "geography", "roughness", "temperature", "radiation", "ice", "illumination", "geochemistry"]);
    const ill = MOON_CRITERIA.find((c) => c.key === "illumination")!, geo = MOON_CRITERIA.find((c) => c.key === "geochemistry")!;
    expect(ill.scored.map((v) => v.key)).toEqual(["illum"]);
    expect(geo.scored.map((v) => v.key)).toEqual(["litho"]);
  });
  it("matches Moon and Earth sunlight by each world's own percentile, not raw W/m²", () => {
    expect(VAR_BY_KEY.illum.scoreMode).toBe("percentile");
    expect(planetSide("moon", "illum").src).toBe("moonIllum");
  });
  it("uses sunlight as a Moon landing factor", () => {
    expect(LANDING_FACTORS.moon.find((f) => f.key === "illum")?.better).toBe("high");
  });
});

describe("Mars criteria", () => {
  it("ranks every criterion, with illumination and geochemistry as separate criteria", () => {
    expect(MARS_CRITERIA.filter(isRankable).map((c) => c.key)).toEqual(["terrain", "geography", "roughness", "temperature", "radiation", "ice", "illumination", "geochemistry"]);
    const ill = MARS_CRITERIA.find((c) => c.key === "illumination")!, geo = MARS_CRITERIA.find((c) => c.key === "geochemistry")!;
    expect(ill.scored.map((v) => v.key)).toEqual(["illum"]);
    expect(geo.scored.map((v) => v.key)).toEqual(["litho"]);
  });
  it("uses Mars regions of about 59 km, close to Earth's ~55 km cells", () => {
    const km = binSizeKm(1, 0, MARS.radiusKm);
    expect(km.ns).toBeGreaterThan(55);
    expect(km.ns).toBeLessThan(62);
  });
  it("matches Mars and Earth radiation by each world's own percentile, not raw units", () => {
    const grid = { step: 1, nlat: 1, nlon: 4, vars: { rad: [0.8, 1.0, 1.2, 1.4] }, radEstimated: [] } as unknown as MoonGrid;
    const site = { id: "x", values: { rad: 0.1 } } as unknown as Site;
    const calib = computeBounds(grid, ["rad"], [site], "mars");
    // Highest Mars value sits at the top of the Mars scale, whatever its unit.
    expect(calib.pos("rad", "moon", 1.4)).toBe(1);
    expect(calib.pos("rad", "moon", 0.8)).toBe(0);
  });
});

describe("Explorer worlds", () => {
  it("offers Moon and Mars, both switched on", () => {
    expect(BODIES.map((b) => [b.id, b.available])).toEqual([["moon", true], ["mars", true]]);
  });
});

import { transportCost, NASA_CENTERS } from "@/lib/costs";
describe("transport cost", () => {
  it("has no cost until a shipping rate is entered", () => {
    expect(transportCost(NASA_CENTERS[0], { lat: 0, lon: 0 }, 100, 1, 1, null).total).toBeNull();
  });
  it("is mass × fragility × rate × km/1000 × iterations", () => {
    const t = transportCost({ lat: 0, lon: 0 }, { lat: 0, lon: 0 }, 100, 2, 3, 5);
    expect(t.km).toBe(0);
    expect(t.total).toBe(0);
    const u = transportCost({ lat: 0, lon: 0 }, { lat: 0, lon: 9 }, 10, 1, 2, 4);
    expect(u.total).toBeCloseTo(u.km / 1000 * 10 * 4 * 2, 6);
  });
});

import { LITHO_MATCH, EARTH_LITHO } from "@/lib/lithology";
import { reverseSearch } from "@/lib/analogs";
import { recommendLanding, terramechanics, gravityRatio } from "@/lib/landing";
describe("rock-type matching", () => {
  it("scores same class 100, related 50, different 0", () => {
    const p: Prepared = { litho: { moon: 1, earth: 0, bounds: b, table: LITHO_MATCH.moon } }; // mare basalt vs Earth basalt
    const c: ScoreCriterion = { key: "geochemistry", vars: [{ key: "litho", w: 1 }] };
    expect(score(p, [c]).overall).toBe(1);
    expect(score({ litho: { ...p["litho"]!, moon: 0, earth: 2 } }, [c]).overall).toBe(0.5); // highlands vs impact breccia
    expect(score({ litho: { ...p["litho"]!, moon: 1, earth: 3 } }, [c]).overall).toBe(0); // mare vs evaporites
  });
  it("classes Mistastin as anorthosite and Holuhraun as basalt", () => {
    expect(EARTH_LITHO["mistastin"]).toBe(1);
    expect(EARTH_LITHO["holuhraun"]).toBe(0);
  });
});
describe("reverse search", () => {
  it("returns the planet bin that best matches an Earth place", () => {
    const grid = { step: 90, nlat: 2, nlon: 4, vars: { relief: [10, 50, 90, 200, 10, 10, 10, 10], range: [10, 50, 90, 200, 10, 10, 10, 10] }, radEstimated: [] } as unknown as MoonGrid;
    const calib = computeBounds(grid, ["relief", "range"], [{ id: "x", values: { relief: 90, range: 90 } } as unknown as Site], "moon");
    const out = reverseSearch({ grid, earth: { relief: 90, range: 90 }, keys: ["relief", "range"], criteria: [terrain], calib, n: 1 });
    expect(out[0]!.item.index).toBe(2);
    expect(out[0]!.result.overall).toBe(1);
  });
});
describe("landing recommendations", () => {
  it("prefers the flattest, lowest-relief bin", () => {
    const grid = { step: 90, nlat: 2, nlon: 4, vars: { slope: [9, 1, 5, 7, 8, 6, 4, 3], relief: [9, 1, 5, 7, 8, 6, 4, 3], ice: [5, 5, 5, 5, 5, 5, 5, 5], rad: [5, 5, 5, 5, 5, 5, 5, 5] }, radEstimated: [] } as unknown as MoonGrid;
    expect(recommendLanding(grid, "moon", { n: 1 })[0]!.index).toBe(1);
  });
});
describe("gravity terramechanics", () => {
  it("uses Moon 0.166× and Mars 0.38× Earth gravity", () => {
    expect(gravityRatio("moon")).toBeCloseTo(0.166, 2);
    expect(gravityRatio("mars")).toBeCloseTo(0.38, 2);
  });
  it("offloads a 100 kg rover to its Moon weight", () => {
    const t = terramechanics("moon", 100);
    expect(t.planetWeightN).toBeCloseTo(162.5, 1);
    expect(t.offloadN).toBeCloseTo(980.7 - 162.5, 1);
  });
});
