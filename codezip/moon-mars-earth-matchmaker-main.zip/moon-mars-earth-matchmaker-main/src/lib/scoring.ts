/**
 * Space2Earth scoring method — pure, versioned, planet-agnostic. No UI imports.
 * Similar tendencies, not identical values: each variable is scaled to the pooled
 * 5th–95th percentile (clipped 0–1); similarity = 1 − |scaled distance|.
 * Criterion score = weighted mean of its available variables; overall = mean of the
 * selected criteria with data (weights rescaled). Only shared, comparable measurements
 * may be passed in as scored variables.
 */
export const METHOD_VERSION = "4.1.0";
export const COVERAGE_THRESHOLD = 0.6;
export const MAX_RESULTS = 10;

export type Num = number | null | undefined;
export interface Bounds { p5: number; p95: number; q: [number, number, number] }
export interface ScoreCriterion { key: string; vars: { key: string; w: number }[] }
/** `table` = categorical match: similarity = table[planet class][Earth class] (rock types). */
export type Prepared = Record<string, { moon: Num; earth: Num; bounds: Bounds; table?: number[][] | undefined }>;

export function percentile(sorted: number[], p: number) {
  if (!sorted.length) return NaN;
  const idx = (sorted.length - 1) * p;
  const lo = Math.floor(idx), hi = Math.ceil(idx);
  return sorted[lo]! + (sorted[hi]! - sorted[lo]!) * (idx - lo);
}
export function makeBounds(values: Num[]): Bounds {
  const s = values.filter((v): v is number => typeof v === "number" && !Number.isNaN(v)).sort((a, b) => a - b);
  return { p5: percentile(s, 0.05), p95: percentile(s, 0.95), q: [percentile(s, 0.25), percentile(s, 0.5), percentile(s, 0.75)] };
}
export function scale(v: number, b: Bounds) {
  const span = b.p95 - b.p5 || 1;
  return Math.min(1, Math.max(0, (v - b.p5) / span));
}
const has = (v: Num): v is number => typeof v === "number" && !Number.isNaN(v);
export function similarity(a: Num, b: Num, bounds: Bounds, table?: number[][]) {
  if (!has(a) || !has(b)) return null;
  if (table) return a < 0 || b < 0 ? null : table[a]?.[b] ?? null;
  return 1 - Math.abs(scale(a, bounds) - scale(b, bounds));
}
export function quartile(v: number, b: Bounds) {
  return v < b.q[0] ? 0 : v < b.q[1] ? 1 : v < b.q[2] ? 2 : 3;
}
export type Band = "same band" | "adjacent band" | "opposite band";
export function tendency(a: Num, b: Num, bounds: Bounds, table?: number[][]): Band | null {
  if (!has(a) || !has(b)) return null;
  if (table) { const s = similarity(a, b, bounds, table); return s == null ? null : s >= 1 ? "same band" : s > 0 ? "adjacent band" : "opposite band"; }
  const d = Math.abs(quartile(a, bounds) - quartile(b, bounds));
  return d === 0 ? "same band" : d >= 2 ? "opposite band" : "adjacent band";
}

export interface VarResult { key: string; criterion: string; sim: number | null; band: Band | null }
export interface Result {
  overall: number | null; coverage: number;
  criteria: Record<string, number | null>; vars: VarResult[];
  limited: boolean; strength: "strong" | "moderate" | "weak"; version: string;
}

export function score(p: Prepared, criteria: ScoreCriterion[], weights: Record<string, number> = {}): Result {
  const vars: VarResult[] = [];
  const crit: Record<string, number | null> = {};
  let totalW = 0, availW = 0, o = 0, ow = 0;
  for (const c of criteria) {
    const cw = weights[c.key] ?? 1;
    let s = 0, w = 0;
    for (const { key, w: vw } of c.vars) {
      const x = p[key];
      const sim = x ? similarity(x.moon, x.earth, x.bounds, x.table) : null;
      vars.push({ key, criterion: c.key, sim, band: x ? tendency(x.moon, x.earth, x.bounds, x.table) : null });
      totalW += vw * cw;
      if (sim !== null) { s += sim * vw; w += vw; availW += vw * cw; }
    }
    crit[c.key] = w ? s / w : null;
    if (w && cw > 0) { o += (s / w) * cw; ow += cw; }
  }
  const overall = ow ? o / ow : null;
  const coverage = totalW ? availW / totalW : 0;
  return {
    overall, coverage, criteria: crit, vars,
    limited: coverage < COVERAGE_THRESHOLD,
    strength: overall === null ? "weak" : overall >= 0.7 ? "strong" : overall >= 0.5 ? "moderate" : "weak",
    version: METHOD_VERSION,
  };
}

export interface Ranked<T> { item: T; result: Result; rank: number; robust: boolean | null }
export interface Excluded<T> { item: T; coverage: number }
export interface Ranking<T> { ranked: Ranked<T>[]; excluded: Excluded<T>[]; candidates: number }

/**
 * Rank candidates (deterministic, tie-break by id). Candidates below the coverage threshold
 * are excluded and reported. With 2+ criteria, robust = stays in the top N when each
 * criterion's weight is doubled in turn.
 */
export function rank<T extends { id: string }>(items: T[], prep: (t: T) => Prepared, criteria: ScoreCriterion[], opts: { n?: number } = {}): Ranking<T> {
  const n = opts.n ?? MAX_RESULTS;
  if (!criteria.length) return { ranked: [], excluded: [], candidates: items.length };
  const prepared = items.map((item) => ({ item, p: prep(item) }));
  const order = (w: Record<string, number>) => {
    const all = prepared.map(({ item, p }) => ({ item, result: score(p, criteria, w) }));
    const ok = all.filter((r) => r.result.overall !== null && !r.result.limited)
      .sort((a, b) => (b.result.overall! - a.result.overall!) || a.item.id.localeCompare(b.item.id));
    const bad = all.filter((r) => r.result.overall === null || r.result.limited).map((r) => ({ item: r.item, coverage: r.result.coverage }));
    return { ok, bad };
  };
  const base = order({});
  const tops = criteria.length > 1
    ? criteria.map((c) => new Set(order({ [c.key]: 2 }).ok.slice(0, n).map((r) => r.item.id)))
    : null;
  return {
    ranked: base.ok.slice(0, n).map((r, i) => ({ ...r, rank: i + 1, robust: tops ? tops.every((s) => s.has(r.item.id)) : null })),
    excluded: base.bad,
    candidates: items.length,
  };
}
