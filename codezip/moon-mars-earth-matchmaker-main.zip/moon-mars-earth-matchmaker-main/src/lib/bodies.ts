/**
 * Explorable bodies. The explorer is driven by this config: each body brings its 3D texture,
 * data grid (public/data/<id>-grid.json), criteria and quick picks; the workflow is shared.
 */
import moonTex from "@/assets/moon-lroc-color.jpg.asset.json";
import elev from "@/assets/moon-lola-elevation.png.asset.json";
import marsTex from "@/assets/mars-color.jpg.asset.json";
import marsElev from "@/assets/mars-mola-elevation.png.asset.json";
import { MARS_CRITERIA, MOON_CRITERIA, type CriterionDef } from "./criteria";
import { MARS_RADIUS_KM, MOON_RADIUS_KM, type BodyId } from "./data";

export interface MoonPoint { lat: number; lon: number; label?: string }
export interface BodyConfig {
  id: BodyId; name: string; available: boolean;
  texture: string; bump: string; bumpOffsetX: number; overlayOffsetX: number;
  radiusKm: number; convention: string; criteria: CriterionDef[]; presets: MoonPoint[];
  /** Native data grid the regions are built from, for the resolution note. */
  gridNote: string;
}

export const BODIES: BodyConfig[] = [
  {
    id: "moon", name: "Moon", available: true, texture: moonTex.url, bump: elev.url, bumpOffsetX: 0.5, overlayOffsetX: 0.5,
    radiusKm: MOON_RADIUS_KM, convention: "Selenographic, planetocentric latitude; east-positive longitude.",
    criteria: MOON_CRITERIA, gridNote: "built from the 0.5° Drive grids",
    presets: [
      { lat: -89.5, lon: 222.7, label: "Shackleton rim (south pole)" },
      { lat: -85.4, lon: 31.8, label: "Malapert Massif" },
      { lat: 0.67, lon: 23.47, label: "Apollo 11 site" },
      { lat: 20.19, lon: 30.77, label: "Apollo 17 site" },
      { lat: 25.0, lon: 300.0, label: "Mare Imbrium" },
    ],
  },
  {
    id: "mars", name: "Mars", available: true, texture: marsTex.url, bump: marsElev.url, bumpOffsetX: 0.5, overlayOffsetX: 0.5,
    radiusKm: MARS_RADIUS_KM, convention: "Areocentric (planetocentric) latitude; east-positive longitude, IAU 2000.",
    criteria: MARS_CRITERIA, gridNote: "built from the 0.5° MOLA, 0.05° ice and 5° neutron Drive grids",
    presets: [
      { lat: 18.38, lon: 77.58, label: "Jezero crater (Perseverance)" },
      { lat: -4.59, lon: 137.44, label: "Gale crater (Curiosity)" },
      { lat: 46.7, lon: 117.5, label: "Utopia Planitia" },
      { lat: -13.9, lon: 300.8, label: "Valles Marineris" },
      { lat: 18.65, lon: 226.2, label: "Olympus Mons" },
      { lat: -42.4, lon: 70.5, label: "Hellas Planitia" },
    ],
  },
];
export const MOON = BODIES[0]!;
export const MARS = BODIES[1]!;
export const bodyById = (id: BodyId) => BODIES.find((b) => b.id === id) ?? MOON;
