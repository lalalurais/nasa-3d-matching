/**
 * Comparison criteria for a body pair. A criterion is rankable when it has scored variables.
 * Same-unit variables use a shared scale; different-unit ones use each world's own
 * percentile (VarMeta.scoreMode). `method` explains the match to users.
 */
import type { VarKey } from "./data";
import type { ScoreCriterion } from "./scoring";

export interface CriterionDef {
  key: string; label: string; summary: string;
  scored: { key: VarKey; w: number }[];
  context: VarKey[];
  excludedReason?: string;
  /** How the criterion is matched, shown to users. */
  method?: string;
}

/** Rock-type matching. Separate from illumination. */
const GEOCHEM = (world: "Moon" | "Mars"): CriterionDef => ({
  key: "geochemistry", label: "Geochemistry & mineralogy", summary: "Rock type: mare basalt, highlands, volcanic, sedimentary, polar…",
  scored: [{ key: "litho", w: 1 }], context: [],
  method: world === "Moon"
    ? "Rock class, not raw chemistry: LROC mare map (mare basalt vs anorthositic highlands) vs each Earth site's catalog geology. Same class = 100, related = 50 (highlands vs impact breccia), different = 0. Only catalog sites have a rock class."
    : "Rock class, not raw chemistry: USGS Geologic Map of Mars unit groups vs each Earth site's catalog geology. Same class = 100, related = 50, different = 0. Only catalog sites have a rock class.",
});
/** Solar power. Separate from geochemistry. */
const ILLUM_MOON: CriterionDef = {
  key: "illumination", label: "Solar illumination (power)", summary: "Sunlight available for solar panels.", scored: [{ key: "illum", w: 1 }], context: ["dayfrac"],
  method: "Percentile within each world: Moon = mean sunlight on level ground over 12 lunar days from 15 Nov 2026, computed from the Drive's SPICE kernels (no atmosphere), Earth = 2024 annual-mean surface irradiance (after air and clouds). Different quantities, so only their relative rank is compared.",
};
const ILLUM_MARS: CriterionDef = {
  key: "illumination", label: "Solar illumination (power)", summary: "Sunlight available for solar panels.", scored: [{ key: "illum", w: 1 }], context: ["dayfrac"],
  method: "Percentile within each world: Mars = mean top-of-atmosphere irradiance over one sol from 15 Nov 2026 (season-dependent, before dust losses), Earth = 2024 annual-mean surface irradiance. Different quantities, so only their relative rank is compared.",
};

export const MOON_CRITERIA: CriterionDef[] = [
  {
    key: "terrain", label: "Terrain relief", summary: "How rugged the ground is across a ~60 km area.",
    scored: [{ key: "relief", w: 1 }, { key: "range", w: 1 }], context: [], method: "Same metres, same ~60 km footprint on both worlds.",
  },
  {
    key: "geography", label: "Landforms (geography)", summary: "Low basin or high ground, flat plain or steep slopes.",
    scored: [{ key: "elev", w: 1 }, { key: "slope", w: 1 }], context: [], method: "Percentile within each world for mean elevation and mean slope (reference surfaces and slope baselines differ).",
  },
  {
    key: "roughness", label: "Roughness", summary: "Small-scale surface roughness.", scored: [{ key: "rough", w: 1 }], context: [], method: "Percentile within each world (methods differ, raw metres not compared).",
  },
  {
    key: "temperature", label: "Temperature", summary: "Day, night, noon and midnight surface temperature.", scored: [{ key: "tday", w: 1 }, { key: "tnight", w: 1 }, { key: "tnoon", w: 1 }, { key: "tmid", w: 1 }], context: ["tmean"], method: "Direct °C match per local-time window (Moon measured, Earth modelled).",
  },
  {
    key: "radiation", label: "Radiation", summary: "Radiation environment.", scored: [{ key: "rad", w: 1 }], context: [], method: "Percentile within each world (events/s vs µSv/h are different units).",
  },
  {
    key: "ice", label: "Water / ice indicators", summary: "Hydrogen (Moon) and permafrost (Earth).", scored: [{ key: "ice", w: 1 }], context: [], method: "Percentile within each world (ppm H vs permafrost index).",
  },
  ILLUM_MOON,
  GEOCHEM("Moon"),
];

export const isRankable = (c: CriterionDef) => c.scored.length > 0;

export function selectedCriteria(all: CriterionDef[], keys: string[]) {
  const sel = all.filter((c) => keys.includes(c.key));
  return { rankable: sel.filter(isRankable), viewOnly: sel.filter((c) => !isRankable(c)), all: sel };
}
export const toScoreCriteria = (defs: CriterionDef[]): ScoreCriterion[] => defs.map((c) => ({ key: c.key, vars: c.scored }));
export const scoredKeys = (defs: CriterionDef[]) => defs.flatMap((c) => c.scored.map((v) => v.key));

/** Mars vs Earth. Same scoring rules as the Moon. */
export const MARS_CRITERIA: CriterionDef[] = [
  {
    key: "terrain", label: "Terrain relief", summary: "How rugged the ground is across a ~60 km area.",
    scored: [{ key: "relief", w: 1 }, { key: "range", w: 1 }], context: [], method: "Same metres, same ~55–60 km footprint on both worlds (Mars 1° MOLA bin, Earth 0.5° ETOPO cell).",
  },
  {
    key: "geography", label: "Landforms (geography)", summary: "Low basin or high ground, flat plain or steep slopes.",
    scored: [{ key: "elev", w: 1 }, { key: "slope", w: 1 }], context: [], method: "Percentile within each world for mean elevation and mean slope (areoid vs sea level).",
  },
  { key: "roughness", label: "Roughness", summary: "Small-scale surface roughness.", scored: [{ key: "rough", w: 1 }], context: [], method: "Percentile within each world (raw metres not compared)." },
  {
    key: "temperature", label: "Temperature", summary: "Mean surface temperature.", scored: [{ key: "tmean", w: 1 }], context: ["tmax", "tmin"],
    method: "Direct °C match of the Mars file's mean surface temperature with Earth's average over all local times. The Mars file has no day / night split, so only the mean is ranked.",
  },
  { key: "radiation", label: "Radiation", summary: "Radiation environment (neutron proxy on Mars).", scored: [{ key: "rad", w: 1 }], context: [], method: "Percentile within each world (fast-neutron counts/s vs µSv/h are different units)." },
  { key: "ice", label: "Water / ice indicators", summary: "Ice consistency (Mars) and permafrost (Earth).", scored: [{ key: "ice", w: 1 }], context: [], method: "Percentile within each world (ice consistency vs permafrost index)." },
  ILLUM_MARS,
  GEOCHEM("Mars"),
];
