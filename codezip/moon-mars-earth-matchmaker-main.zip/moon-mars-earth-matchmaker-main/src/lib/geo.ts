/** Normalise longitude to -180..180. */
export function lon180(lon: number) {
  return ((((lon + 180) % 360) + 360) % 360) - 180;
}
export function fmtLat(lat: number) {
  return `${Math.abs(lat).toFixed(2)}° ${lat >= 0 ? "N" : "S"}`;
}
export function fmtLon(lon: number) {
  const l = lon180(lon);
  return `${Math.abs(l).toFixed(2)}° ${l >= 0 ? "E" : "W"}`;
}
export function fmtCoord(lat: number, lon: number) {
  return `${fmtLat(lat)}, ${fmtLon(lon)}`;
}
