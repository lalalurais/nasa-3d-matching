import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/** Team Drive folder "Hackathon NASA Spaces Apps Challenge / Website feedback". */
const FEEDBACK_FOLDER_ID = "1PtASqC-udC4W9e5f5cpVyslOW6OwSN80";

export const FEEDBACK_TYPES = ["Hackathon judge feedback", "Scientific consultation", "Data partnership", "General feedback"] as const;

export const feedbackSchema = z.object({
  type: z.enum(FEEDBACK_TYPES),
  name: z.string().trim().min(1, "Please enter your name").max(100),
  email: z.string().trim().email("Please enter a valid email").max(255),
  affiliation: z.string().trim().max(150).optional().default(""),
  message: z.string().trim().min(1, "Please write a message").max(3000),
  website: z.string().max(0).optional().default(""), // honeypot, must stay empty
});

export const sendFeedback = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => feedbackSchema.parse(d))
  .handler(async ({ data }) => {
    const lov = process.env["LOVABLE_API_KEY"], key = process.env["GOOGLE_DRIVE_API_KEY"];
    if (!lov || !key) throw new Error("Feedback storage is not configured.");
    const now = new Date().toISOString();
    const text = [`Type: ${data.type}`, `Name: ${data.name}`, `Email: ${data.email}`, `Affiliation: ${data.affiliation || "-"}`, `Sent: ${now}`, "", data.message].join("\n");
    const safeName = data.name.replace(/[^\p{L}\p{N} ._-]/gu, "").slice(0, 40);
    const meta = { name: `${now.slice(0, 16).replace("T", " ")} · ${data.type} · ${safeName}.txt`, parents: [FEEDBACK_FOLDER_ID], mimeType: "text/plain" };
    const boundary = "s2e" + crypto.randomUUID();
    const body = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n${text}\r\n--${boundary}--`;
    const res = await fetch("https://connector-gateway.lovable.dev/google_drive/upload/drive/v3/files?uploadType=multipart&fields=id", {
      method: "POST",
      headers: { Authorization: `Bearer ${lov}`, "X-Connection-Api-Key": key, "Content-Type": `multipart/related; boundary=${boundary}` },
      body,
    });
    if (!res.ok) { const t = await res.text(); console.error(`Drive upload failed [${res.status}]: ${t}`); throw new Error("Could not save your message. Please try again."); }
    return { ok: true };
  });
