import sitesJson from "@/data/earth-sites.json";
import { EARTH_LITHO, lithoLabel } from "./lithology";

export type VarKey = "relief" | "range" | "elev" | "slope" | "rough" | "tday" | "tnight" | "tnoon" | "tmid" | "tmean" | "tmax" | "tmin" | "ice" | "rad" | "illum" | "dayfrac" | "litho";
export type Values = Partial<Record<VarKey, number | null>>;
export type BodyId = "moon" | "mars";

export interface Site {
  id: string; name: string; country: string; continent: string; lat: number; lon: number;
  terrain: string; geology: string; caves: boolean; water: string; biology: string; access: string; use: string; ref: string;
  values: Values;
  cells: { terrain: [number, number]; temp: [number, number] };
  /** True for a candidate found by the whole-Earth search (not in the analog catalog). */
  discovery?: boolean;
}
export interface MoonGrid {
  step: number; nlat: number; nlon: number;
  vars: Record<VarKey, (number | null)[]>;
  radEstimated: number[];
  /** Mars only: % of native MOLA pixels with real laser shots (rest interpolated by NASA). */
  observedPct?: (number | null)[];
  /** Geologic map unit per bin (index into unitNames, -1 = none): Moon = LROC mare name, Mars = SIM 3292 unit. */
  unitNames?: string[]; unit?: number[];
}
export type PlanetGrid = MoonGrid;

/** Catalog sites; the rock class is read from each site's geology description (see lithology.ts). */
export const SITES: Site[] = (sitesJson as unknown as { sites: Site[] }).sites.map((s) => ({ ...s, values: { ...s.values, litho: EARTH_LITHO[s.id] ?? null } }));
export const PERCENTILES = (sitesJson as unknown as { percentiles: { moon: Record<"ice" | "rad", number[]>; earth: Record<"ice" | "rad", number[]> } }).percentiles;

export const DRIVE_FOLDER_URL = "https://drive.google.com/drive/folders/1VZQrxSebCMdlVoCY0T08HG6wZPOWuvrq";
export const driveLink = (id: string) => `https://drive.google.com/file/d/${id}/view`;
export const driveFolderLink = (id: string) => `https://drive.google.com/drive/folders/${id}`;

/** Drive file IDs of the datasets each variable comes from. */
export const SOURCES = {
  moonTerrain: { id: "1vYTmO8iQiue8uPqkZw5HChktLwqbkEln", name: "moon_terrain_0_5deg.csv", dataset: "NASA LRO LOLA GDR (doi:10.17189/1520642)", basis: "Mission-averaged laser altimetry" },
  earthTerrain: { id: "1DewMrZuc0qUkNmbYUwWTxrULZtam_4DK", name: "earth_terrain_0_5deg.csv", dataset: "NOAA ETOPO 2022 (doi:10.25921/fd45-gt74)", basis: "Global relief model" },
  moonTemp: { id: "1nGuzHNFDTK85iNvUZv-PPZvYSuO2HFHH", name: "moon_locations_0_5deg.csv", dataset: "LRO Diviner GCP bolometric temperature", basis: "Historical average, Jul 2009–Apr 2015, by lunar local solar time" },
  earthTemp: { id: "1dzxb_pmrqGbXUmTxzoBGnqPc4zQsqT79", name: "earth_locations_0_5x0_625deg.csv", dataset: "NASA MERRA-2 surface skin temperature (M2T1NXSLV TS)", basis: "Reanalysis average by local solar time" },
  moonIce: { id: "19yUTl_mrb1Hwid8n5iAa_HXPXtFLyIq3", name: "Moon_Ice_Data.xlsx", dataset: "Lawrence et al. (2022) bulk hydrogen, JHU repository", basis: "Neutron spectroscopy, top tens of cm" },
  earthIce: { id: "1Q00KcbvF_WSWdZNqiRp_Uxtopvao4Lc4", name: "Earth_Ice_Data.xlsx", dataset: "Gruber (2012) Permafrost Zonation Index, Univ. Zurich", basis: "Modelled index, 0–1" },
  moonRad: { id: "1ZNm_8sJgEblqExNlaQXr9UCuahpuT2qd", name: "Moon_Radiation_Coordinates.xlsx", dataset: "Lunar orbital radiation proxy", basis: "Orbital count rate (events/s)" },
  earthRad: { id: "1OM-MbBEDA_sdVEHpzKLiPM3LRWH5Ript", name: "Earth_Radiation_Coordinates.xlsx", dataset: "Kobayashi et al. (2024) EXPACS dose, Zenodo", basis: "Simulated ground-level mean 2001–2023" },
  marsTerrain: { id: "1vGsdmzoOuNXMvthD73w_NMhxridK6mxC", name: "mars_terrain_0_5deg.csv", dataset: "NASA MGS MOLA MEGDR 32 ppd (doi:10.17189/1z1b-kv84)", basis: "Laser altimetry, gaps interpolated by NASA" },
  marsIce: { id: "1WrA_hn5USTZRTFJ-8tc20jnrWrmky43b", name: "Mars_Ice_Coordinates.xlsx", dataset: "SWIM combined ice consistency map, 0–1 m depth", basis: "Ice consistency proxy (not an ice percentage), 60°S–60°N" },
  marsRad: { id: "1GjWFczG5xwB9F9PKUL7R4gw3CEvYEqPa", name: "Mars_Radiation_Coordinates.xlsx", dataset: "Mars Odyssey GRS neutron spectrometer (ODY-M-GRS-5-AND-V2.0)", basis: "Fast-neutron count rate, 5° cells (not a dose)" },
  marsTemp: { id: "1WmEV3UGEJG-M87zxcUKOQz-wl6h5kP8Z", name: "mars_temperature_0p5deg.csv", dataset: "Mars surface temperature grid, 0.5° (team Drive; origin not documented in the file)", basis: "Mean surface temperature per cell, with surface min / max columns" },
  earthMinerals: { id: "1ofrgZZn4jcBeWlzq7n1YkHStlPFVpGAP", name: "Geochemistry/Planetary_Geochemistry/Earth (folder)", dataset: "NASA EMIT L2B mineral identification, 60 m", basis: "5 + 5 scenes over the Atacama region (Chile), 2022–2023 only" },
  moonGeochem: { id: "1IPxPitwWMZuFyvBL7Edq8eEZCjIoJstJ", name: "Geochemistry/Planetary_Geochemistry/Moon (folder)", dataset: "NASA PDS search listings (Diviner, Moon Mineralogy Mapper)", basis: "File listings only, no measured values" },
  marsGeochem: { id: "1-wsWJKnSndvD41LZT_17XKC-i5tr7pOt", name: "Geochemistry/Planetary_Geochemistry/Mars (folder)", dataset: "NASA PDS search listings (CRISM)", basis: "File listings only, no measured values" },
  earthIllum: { id: "1WWsCsxbGdmL7r9XZ2A8iCXiUGsJWSmhf", name: "earth_illumination_2024_0p5deg.csv", dataset: "Earth surface solar irradiance 2024, 0.5° (team Drive; origin not documented in the file)", basis: "Annual-mean irradiance in W/m² per 0.5° cell" },
  marsIllum: { id: "1uNisXYL7Eiv7RNNY-JI0pbY4D3eJExgD", name: "mars_illumination_0p5deg.csv", dataset: "Mars solar illumination, 0.5° (team Drive)", basis: "Mean top-of-atmosphere irradiance and daylight fraction over one sol from 15 Nov 2026 12:00 UTC" },
  moonIllum: { id: "", url: driveFolderLink("1mNe-jb1I57kUYhIJImXFRQJ9Zwr_oUnS"), name: "Illumination/lunar_kernels (de440s.bsp, pck00011.tpc, naif0012.tls) + Moon_Illumination_Coordinates.xlsx", dataset: "Sun–Moon geometry from NASA/JPL NAIF SPICE kernels (DE440 ephemeris, IAU_MOON frame), computed by scripts/add_moon_illum.py", basis: "Mean irradiance on level ground (no air on the Moon) and daylight fraction, hourly over 12 lunar days from 15 Nov 2026 12:00 UTC; crater and horizon shadows not modelled" },
  moonLitho: { id: "", url: "https://pds.lroc.asu.edu/data/LRO-L-LROC-5-RDR-V1.0/LROLRC_2001/EXTRAS/SHAPEFILE/LROC_GLOBAL_MARE/", name: "LROC_GLOBAL_MARE_180 shapefile", dataset: "LROC global mare boundaries (Nelson et al. 2014, LPSC 45 #2861)", basis: "Mare basalt vs highlands, majority of 16 samples per 2° bin" },
  marsLitho: { id: "", url: "https://pubs.usgs.gov/sim/3292/", name: "SIM3292_Global_Geology shapefile", dataset: "USGS Geologic Map of Mars (Tanaka et al. 2014, SIM 3292, doi:10.3133/sim3292)", basis: "Map unit groups (volcanic, highland, lowland/basin/transition, polar, impact), majority of 16 samples per 1° bin" },
  earthLitho: { id: "", url: "/data#lithology", name: "Analog catalog geology descriptions", dataset: "Space2Earth analog catalog geology (rock class per site)", basis: "Rock class read from each site's geology description" },
} as const;
export type SourceKey = keyof typeof SOURCES;
/** Link for a source: its web page when it is not a Drive file, else the Drive file. */
export const sourceUrl = (k: SourceKey) => { const s = SOURCES[k]; return "url" in s ? s.url : driveLink(s.id); };

export interface VarMeta {
  key: VarKey; label: string; unit: string; moonUnit?: string; earthUnit?: string;
  moonSrc: SourceKey; earthSrc: SourceKey;
  /** Same quantity, unit and footprint on both worlds: may be used in a shared score. */
  comparable: boolean; earthModelled: boolean; note: string;
  /** How it is scored: shared physical scale, or each world's own percentile ("high for the Moon" vs "high for Earth"). */
  scoreMode?: "shared" | "percentile" | "category";
  /** How the Earth value was obtained, when "measured"/"modelled" would be wrong. */
  earthKind?: string;
}

const TEMP_NOTE = "Scored directly in °C over the same local-solar-time window. Caveat: Moon = measured Diviner brightness temperature, Earth = modelled MERRA-2 temperature.";
export const VARS: VarMeta[] = [
  { key: "relief", label: "Local relief (elevation std. dev.)", unit: "m", moonSrc: "moonTerrain", earthSrc: "earthTerrain", comparable: true, earthModelled: false, note: "Spread of elevation over a ~55–60 km area from ~1.9 km pixels (Moon: 2° LOLA bin; Earth: 0.5° ETOPO cell)." },
  { key: "range", label: "Elevation range (max − min)", unit: "m", moonSrc: "moonTerrain", earthSrc: "earthTerrain", comparable: true, earthModelled: false, note: "Highest minus lowest point over the same ~55–60 km area." },
  { key: "elev", label: "Mean elevation", unit: "m", moonSrc: "moonTerrain", earthSrc: "earthTerrain", comparable: false, earthModelled: false, note: "Scored by percentile within each world (low basin vs high ground): Moon heights are above a 1,737.4 km sphere and Earth heights above sea level, so raw metres are never compared.", scoreMode: "percentile" },
  { key: "slope", label: "Mean slope", unit: "°", moonSrc: "moonTerrain", earthSrc: "earthTerrain", comparable: false, earthModelled: false, note: "Scored by percentile within each world (flat vs steep for that world): LOLA slopes use 30–120 m laser baselines and Earth slopes ~1.85 km pixels, so raw degrees are never compared.", scoreMode: "percentile" },
  { key: "rough", label: "Mean roughness", unit: "m", moonSrc: "moonTerrain", earthSrc: "earthTerrain", comparable: false, earthModelled: false, note: "Scored by percentile within each world: the methods differ (LOLA laser residual vs undocumented Earth method), so raw metres are never compared.", scoreMode: "percentile" },
  { key: "tday", label: "Temperature, day (06–18 h)", unit: "°C", moonSrc: "moonTemp", earthSrc: "earthTemp", comparable: true, scoreMode: "shared", earthModelled: true, note: TEMP_NOTE },
  { key: "tnight", label: "Temperature, night (18–06 h)", unit: "°C", moonSrc: "moonTemp", earthSrc: "earthTemp", comparable: true, scoreMode: "shared", earthModelled: true, note: TEMP_NOTE },
  { key: "tnoon", label: "Temperature, noon (10–14 h)", unit: "°C", moonSrc: "moonTemp", earthSrc: "earthTemp", comparable: true, scoreMode: "shared", earthModelled: true, note: TEMP_NOTE },
  { key: "tmid", label: "Temperature, midnight (22–02 h)", unit: "°C", moonSrc: "moonTemp", earthSrc: "earthTemp", comparable: true, scoreMode: "shared", earthModelled: true, note: TEMP_NOTE },
  { key: "tmean", label: "Mean temperature (all local times)", unit: "°C", moonSrc: "moonTemp", earthSrc: "earthTemp", comparable: true, scoreMode: "shared", earthModelled: true, note: "Scored directly in °C: average over all local times. Moon = measured Diviner, Earth = modelled MERRA-2." },
  { key: "tmax", label: "Warmest local-time average", unit: "°C", moonSrc: "moonTemp", earthSrc: "earthTemp", comparable: false, earthModelled: true, note: "Shown for context: warmest local-time bin of the average day." },
  { key: "tmin", label: "Coldest local-time average", unit: "°C", moonSrc: "moonTemp", earthSrc: "earthTemp", comparable: false, earthModelled: true, note: "Shown for context: coldest local-time bin of the average day." },
  { key: "ice", label: "Water / ice indicator", unit: "", moonUnit: "ppm H", earthUnit: "permafrost index 0–1", moonSrc: "moonIce", earthSrc: "earthIce", comparable: false, earthModelled: true, note: "Scored by percentile within each world: hydrogen (ppm) and permafrost index are different quantities, so only their relative rank is compared.", scoreMode: "percentile" },
  { key: "rad", label: "Radiation", unit: "", moonUnit: "events/s", earthUnit: "µSv/h", moonSrc: "moonRad", earthSrc: "earthRad", comparable: false, earthModelled: true, note: "Scored by percentile within each world: orbital count rate and ground dose are different quantities, so only their relative rank is compared.", scoreMode: "percentile" },
  { key: "illum", label: "Solar irradiance (solar-panel power)", unit: "W/m²", earthUnit: "W/m²", moonSrc: "moonIllum", earthSrc: "earthIllum", comparable: false, earthModelled: false, earthKind: "2024 annual mean", scoreMode: "percentile", note: "Scored by percentile within each world (sunny for that world vs dim for that world): Earth = 2024 annual-mean surface irradiance after air and clouds, Moon = airless surface irradiance over 12 lunar days from 15 Nov 2026, Mars = one-sol mean top-of-atmosphere irradiance. Raw W/m² are never compared." },
  { key: "dayfrac", label: "Daylight fraction", unit: "", moonSrc: "moonIllum", earthSrc: "earthIllum", comparable: false, earthModelled: false, earthKind: "not in the Earth file", note: "Shown for context: share of the time with the Sun above the horizon (Moon: 12 lunar days, Mars: one sol). The Earth file has no daylight fraction." },
  { key: "litho", label: "Rock type (lithologic class)", unit: "", moonSrc: "moonLitho", earthSrc: "earthLitho", comparable: false, earthModelled: false, earthKind: "catalog geology", scoreMode: "category", note: "Matched by rock class, not raw chemistry: same class = 100, related class = 50, otherwise 0. Earth places outside the catalog have no rock class." },
];
export const VAR_BY_KEY = Object.fromEntries(VARS.map((v) => [v.key, v])) as Record<VarKey, VarMeta>;

/** Mars side of each variable; a missing entry means the Drive has no Mars data for it. */
const MARS_SIDE: Partial<Record<VarKey, { unit: string; src: SourceKey; note: string; label?: string }>> = {
  relief: { unit: "m", src: "marsTerrain", note: "Spread of elevation over a ~59 km area (1° MOLA bin) from ~1.85 km pixels; Earth: 0.5° ETOPO cell (~55 km)." },
  range: { unit: "m", src: "marsTerrain", note: "Highest minus lowest point over the same ~55–60 km area." },
  elev: { unit: "m", src: "marsTerrain", note: "Scored by percentile within each world (low basin vs high ground): Mars heights are above the areoid, Earth heights above sea level." },
  slope: { unit: "°", src: "marsTerrain", note: "Scored by percentile within each world: 3×3 fitted-plane slope at ~1.85 km on Mars vs Earth's ETOPO slope." },
  tmean: { unit: "°C", src: "marsTemp", note: "Scored directly in °C against Earth's average over all local times. Mars = mean surface temperature column of the Drive file (its origin is not documented), Earth = modelled MERRA-2." },
  tmax: { unit: "°C", src: "marsTemp", note: "Shown for context: surface_max_c column of the Mars file, averaged over the region. Not the same definition as Earth's warmest local-time average." },
  tmin: { unit: "°C", src: "marsTemp", note: "Shown for context: surface_min_c column of the Mars file, averaged over the region. Not the same definition as Earth's coldest local-time average." },
  rough: { unit: "m", src: "marsTerrain", note: "Scored by percentile within each world: Mars 3×3 detrended RMS vs Earth roughness, so raw metres are never compared." },
  ice: { unit: "ice consistency", src: "marsIce", label: "Water / ice indicator", note: "Scored by percentile within each world: Mars ice consistency (top 0–1 m; higher = more consistent with shallow ice, below 0 = evidence against) and Earth permafrost index are different quantities. No Mars data poleward of 60°." },
  illum: { unit: "W/m²", src: "marsIllum", note: "Scored by percentile within each world: Mars = mean top-of-atmosphere irradiance over one sol from 15 Nov 2026 (season-dependent, before dust losses), Earth = 2024 annual-mean surface irradiance." },
  dayfrac: { unit: "", src: "marsIllum", note: "Shown for context: share of that sol with the Sun above the horizon. The Earth file has no daylight fraction." },
  litho: { unit: "", src: "marsLitho", note: "Matched by rock class from the USGS Geologic Map of Mars unit groups vs each Earth site's catalog geology: same class = 100, related = 50, otherwise 0." },
  rad: { unit: "fast neutrons/s", src: "marsRad", note: "Scored by percentile within each world: Odyssey fast-neutron count rate (5° cells) vs Earth ground dose. Neutron counts are not a dose." },
};
/** Unit, source and note for the planet side (Moon or Mars) of a variable. src null = no data for this body. */
export function planetSide(body: BodyId, k: VarKey): { unit: string; src: SourceKey | null; note: string } {
  const v = VAR_BY_KEY[k];
  if (body === "moon") {
    if (k === "illum") return { unit: "W/m²", src: "moonIllum", note: "Scored by percentile within each world: Moon = mean sunlight on level ground over 12 lunar days from 15 Nov 2026 (no atmosphere, 1361 W/m² at 1 AU), computed from the Drive's SPICE kernels; Earth = 2024 annual-mean surface irradiance after air and clouds. Crater and horizon shadows are not modelled." };
    if (k === "dayfrac") return { unit: "", src: "moonIllum", note: "Shown for context: share of those 12 lunar days with the Sun's centre above the level horizon. The Earth file has no daylight fraction." };
    if (k === "litho") return { unit: "", src: "moonLitho", note: "Matched by rock class from the LROC mare map (mare basalt vs anorthositic highlands) vs each Earth site's catalog geology: same class = 100, related = 50, otherwise 0." };
    return { unit: v.moonUnit ?? v.unit, src: v.moonSrc, note: v.note };
  }
  const m = MARS_SIDE[k];
  return m ? { unit: m.unit, src: m.src, note: m.note } : { unit: v.unit, src: null, note: "No Mars data in the team Drive yet." };
}

/** Look up the Moon grid cell for a selenographic point (lon east-positive, any range). */
export interface MoonCell { index: number; values: Values; radEstimated: boolean; cellLat: number; cellLon: number; step: number }
export function moonCell(grid: MoonGrid, lat: number, lon: number): MoonCell {
  const i = Math.min(grid.nlat - 1, Math.max(0, Math.floor((lat + 90) / grid.step)));
  const l = ((lon % 360) + 360) % 360;
  const j = Math.min(grid.nlon - 1, Math.floor(l / grid.step));
  const n = i * grid.nlon + j;
  const values: Values = {};
  (Object.keys(grid.vars) as VarKey[]).forEach((k) => (values[k] = grid.vars[k]?.[n] ?? null));
  return {
    index: n,
    values,
    radEstimated: grid.radEstimated[n] === 1,
    cellLat: -90 + (i + 0.5) * grid.step,
    cellLon: (j + 0.5) * grid.step,
    step: grid.step,
  };
}

export async function fetchMoonGrid(): Promise<MoonGrid> {
  const r = await fetch("/data/moon-grid.json");
  if (!r.ok) throw new Error(`Moon grid failed to load (${r.status})`);
  return r.json();
}
export const moonGridQuery = { queryKey: ["moon-grid"], queryFn: fetchMoonGrid, staleTime: Infinity } as const;
export const gridQuery = (body: BodyId) => ({
  queryKey: [`${body}-grid`],
  queryFn: async (): Promise<PlanetGrid> => {
    const r = await fetch(`/data/${body}-grid.json`);
    if (!r.ok) throw new Error(`${body} grid failed to load (${r.status})`);
    return r.json();
  },
  staleTime: Infinity,
});

/** Every Earth land cell (0.5°, ~55 km) from public/data/earth-grid.json; vars are aligned with `cells` (grid index i*nlon+j). */
export interface EarthGrid { step: number; nlat: number; nlon: number; cells: number[]; vars: Partial<Record<VarKey, (number | null)[]>> }
export const earthCellCenter = (g: Pick<EarthGrid, "step" | "nlon">, idx: number) => ({
  lat: -90 + (Math.floor(idx / g.nlon) + 0.5) * g.step, lon: ((idx % g.nlon) + 0.5) * g.step,
});
export const earthGridQuery = {
  queryKey: ["earth-grid"],
  queryFn: async (): Promise<EarthGrid> => {
    const r = await fetch("/data/earth-grid.json");
    if (!r.ok) throw new Error(`Earth grid failed to load (${r.status})`);
    const raw = (await r.json()) as EarthGrid & { scale: Record<string, number>; vars: Record<string, (number | null)[]> };
    const vars: EarthGrid["vars"] = {};
    for (const [k, arr] of Object.entries(raw.vars)) { const sc = raw.scale[k] ?? 1; vars[k as VarKey] = arr.map((v) => (v == null ? null : v / sc)); }
    return { step: raw.step, nlat: raw.nlat, nlon: raw.nlon, cells: raw.cells, vars };
  },
  staleTime: Infinity,
} as const;

/** Display a value of any variable: rock classes by name, fractions as %, numbers with their unit. */
export function fmtValue(k: VarKey, v: number | null | undefined, side: BodyId | "earth") {
  if (k === "litho") return lithoLabel(side, v);
  if (k === "dayfrac") return v == null ? "No data available" : `${Math.round(v * 100)} %`;
  const unit = side === "earth" ? VAR_BY_KEY[k].earthUnit ?? VAR_BY_KEY[k].unit : planetSide(side, k).unit;
  return fmtVal(v, unit);
}
export function fmtVal(v: number | null | undefined, unit: string) {
  if (v === null || v === undefined || Number.isNaN(v)) return "No data available";
  const d = Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 1 ? 1 : 3;
  return `${v.toFixed(d)} ${unit}`;
}

export const MOON_RADIUS_KM = 1737.4;
/** MOLA reference radius used by the Drive Mars terrain README. */
export const MARS_RADIUS_KM = 3396;
/** Ground size of a lat/lon bin on a sphere, in km (north–south, east–west at the bin centre). */
export function binSizeKm(step: number, lat: number, radiusKm: number) {
  const ns = (Math.PI * radiusKm * step) / 180;
  return { ns, ew: ns * Math.cos((lat * Math.PI) / 180) };
}
export const googleMapsUrl = (lat: number, lon: number) => `https://maps.google.com/?q=${lat.toFixed(5)},${lon.toFixed(5)}`;
export const osmUrl = (lat: number, lon: number) => `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=9/${lat}/${lon}`;
