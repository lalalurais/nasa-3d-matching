/** Cost model from the team Drive file Financial simulation/NASA_Analog_Mission_Cost_Simulator.xlsx, plus location-dependent transport. */
import data from "@/data/cost-simulator.json";
import { distanceKm } from "./analogs";

export type Dest = "earth" | "moon" | "mars";
export interface Rate { destination: string; id: Dest; ratePerKg: number; fixed: number }
export interface Scenario { id: string; experiment: string; site: string; target: string; massKg: number; fragility: string; multiplier: number }
export interface LogisticsSite { name: string; region: string; match: string; parallels: string; logistics: string; siteId: string | null }

export const COSTS = data as unknown as { source: string; rates: Rate[]; scenarios: Scenario[]; sites: LogisticsSite[] };
export const rateOf = (id: Dest) => COSTS.rates.find((r) => r.id === id)!;

/** Spreadsheet formulas: variable = mass × $/kg × fragility; single test = variable + fixed; total = single × iterations. */
export function destinationCost(r: Pick<Rate, "ratePerKg" | "fixed">, massKg: number, fragility: number, iterations: number) {
  const variable = massKg * r.ratePerKg * fragility;
  const single = variable + r.fixed;
  return { variable, single, total: single * iterations };
}
export function simulate(massKg: number, fragility: number, iterations: number) {
  const earth = destinationCost(rateOf("earth"), massKg, fragility, iterations);
  const row = (id: Dest) => {
    const c = destinationCost(rateOf(id), massKg, fragility, iterations);
    return { ...c, savings: c.total - earth.total, reduction: c.total ? (c.total - earth.total) / c.total : 0 };
  };
  return { earth, moon: row("moon"), mars: row("mars") };
}
export const logisticsFor = (siteId: string) => COSTS.sites.find((s) => s.siteId === siteId) ?? null;

/** NASA field centers payloads can ship from (public center locations). */
export const NASA_CENTERS = [
  { id: "ksc", name: "Kennedy Space Center, Florida", lat: 28.5729, lon: -80.649 },
  { id: "jsc", name: "Johnson Space Center, Texas", lat: 29.5593, lon: -95.09 },
  { id: "jpl", name: "Jet Propulsion Laboratory, California", lat: 34.2013, lon: -118.1714 },
  { id: "arc", name: "Ames Research Center, California", lat: 37.4089, lon: -122.0644 },
  { id: "gsfc", name: "Goddard Space Flight Center, Maryland", lat: 38.9917, lon: -76.8524 },
  { id: "msfc", name: "Marshall Space Flight Center, Alabama", lat: 34.6466, lon: -86.6741 },
] as const;
export type CenterId = (typeof NASA_CENTERS)[number]["id"];
export const centerById = (id: string) => NASA_CENTERS.find((c) => c.id === id) ?? NASA_CENTERS[0];

/**
 * Transport from a NASA center to the Earth test site, per the user's shipping rate.
 * Straight-line (great-circle) distance; real routes are longer. Rate is $ per kg per 1,000 km and is
 * not in the team spreadsheet yet, so it is null until someone enters one (then the cost is null too).
 * transport per test = mass × fragility × rate × distance / 1,000; total = per test × iterations.
 */
export function transportCost(from: { lat: number; lon: number }, to: { lat: number; lon: number }, massKg: number, fragility: number, iterations: number, ratePer1000Km: number | null) {
  const km = distanceKm(from, to);
  if (ratePer1000Km == null || !Number.isFinite(ratePer1000Km)) return { km, perTest: null, total: null };
  const perTest = massKg * fragility * ratePer1000Km * (km / 1000);
  return { km, perTest, total: perTest * iterations };
}
