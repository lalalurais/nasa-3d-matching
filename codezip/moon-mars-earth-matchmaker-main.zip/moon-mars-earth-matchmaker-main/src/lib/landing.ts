/**
 * Landing-site recommendations (pure, no UI). Each factor is the bin's percentile within its own world,
 * flipped where lower is better, so no thresholds are invented; the index is the mean of available factors.
 * Regional ~55–60 km statistics: a screening aid, not landing-safety certification.
 */
import type { BodyId, MoonGrid, VarKey } from "./data";
import { pctRank } from "./analogs";

export interface LandingFactor { key: VarKey; label: string; better: "low" | "high"; why: string }
export const LANDING_FACTORS: Record<BodyId, LandingFactor[]> = {
  moon: [
    { key: "slope", label: "Gentle slopes", better: "low", why: "Touchdown stability and rover traverses." },
    { key: "relief", label: "Low local relief", better: "low", why: "Fewer hazards and less shadowing across the region." },
    { key: "illum", label: "More sunlight", better: "high", why: "Solar-panel power (mean sunlight over 12 lunar days)." },
    { key: "ice", label: "Water-ice indicator (hydrogen)", better: "high", why: "In-situ water for life support and propellant." },
    { key: "rad", label: "Lower radiation proxy", better: "low", why: "Crew and electronics exposure." },
  ],
  mars: [
    { key: "slope", label: "Gentle slopes", better: "low", why: "Touchdown stability and rover traverses." },
    { key: "relief", label: "Low local relief", better: "low", why: "Fewer hazards for terrain-relative navigation." },
    { key: "elev", label: "Low elevation", better: "low", why: "A thicker air column above the site gives parachutes more time to slow the lander." },
    { key: "illum", label: "More sunlight", better: "high", why: "Solar-panel power (one-sol top-of-atmosphere irradiance)." },
    { key: "ice", label: "Shallow-ice indicator", better: "high", why: "In-situ water for life support and propellant." },
    { key: "rad", label: "Lower radiation proxy", better: "low", why: "Crew and electronics exposure." },
  ],
};
/** Bins need slope and relief plus at least this share of the factors. */
export const LANDING_MIN_COVERAGE = 0.6;
export const LANDING = { n: 10, minSpacingDeg: 10 } as const;

export interface LandingScore { index: number; lat: number; lon: number; lsi: number; coverage: number; factors: Partial<Record<VarKey, number>> }

const sorted = (a: (number | null)[] | undefined) => (a ?? []).filter((v): v is number => typeof v === "number" && !Number.isNaN(v)).sort((x, y) => x - y);

export function landingScorer(grid: MoonGrid, body: BodyId) {
  const fs = LANDING_FACTORS[body];
  const dist = Object.fromEntries(fs.map((f) => [f.key, sorted(grid.vars[f.key])])) as Record<VarKey, number[]>;
  return (index: number): LandingScore | null => {
    const factors: Partial<Record<VarKey, number>> = {};
    let s = 0, n = 0;
    for (const f of fs) {
      const v = grid.vars[f.key]?.[index];
      if (typeof v !== "number" || !dist[f.key]!.length) continue;
      const p = pctRank(dist[f.key]!, v);
      const g = f.better === "low" ? 1 - p : p;
      factors[f.key] = g; s += g; n++;
    }
    const coverage = n / fs.length;
    if (factors.slope == null || factors.relief == null || coverage < LANDING_MIN_COVERAGE) return null;
    const i = Math.floor(index / grid.nlon), j = index % grid.nlon;
    return { index, lat: -90 + (i + 0.5) * grid.step, lon: (j + 0.5) * grid.step, lsi: s / n, coverage, factors };
  };
}

const ang = (a: { lat: number; lon: number }, b: { lat: number; lon: number }) => {
  const r = Math.PI / 180;
  const c = Math.sin(a.lat * r) * Math.sin(b.lat * r) + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.cos((b.lon - a.lon) * r);
  return Math.acos(Math.min(1, Math.max(-1, c))) / r;
};

/** Top landing regions, at least `minSpacingDeg` apart (deterministic: ties by bin index). */
export function recommendLanding(grid: MoonGrid, body: BodyId, o: { n?: number; minSpacingDeg?: number } = {}): (LandingScore & { rank: number })[] {
  const n = o.n ?? LANDING.n, sp = o.minSpacingDeg ?? LANDING.minSpacingDeg;
  const f = landingScorer(grid, body);
  const all: LandingScore[] = [];
  for (let c = 0; c < grid.nlat * grid.nlon; c++) { const x = f(c); if (x) all.push(x); }
  all.sort((a, b) => b.lsi - a.lsi || a.index - b.index);
  const out: LandingScore[] = [];
  for (const x of all) { if (out.length >= n) break; if (!out.some((q) => ang(q, x) < sp)) out.push(x); }
  return out.map((x, i) => ({ ...x, rank: i + 1 }));
}

/** Gravity and terramechanics: what scales with gravity and what does not (memory rule). */
export const GRAVITY = { earth: 9.807, moon: 1.625, mars: 3.721 } as const;
export const gravityRatio = (body: BodyId) => GRAVITY[body] / GRAVITY.earth;
/**
 * Field-test advice for a rover or lander of `massKg`:
 * planetary weight = m·g_planet; on Earth, an offload rig must carry the rest so the wheels feel planetary load.
 * Cohesionless bearing capacity scales with unit weight γ = ρg, so the same soil on Earth supports 1/ratio more.
 * Friction angle, grain density and cohesion do not scale.
 */
export function terramechanics(body: BodyId, massKg: number) {
  const ratio = gravityRatio(body);
  const planetWeightN = massKg * GRAVITY[body];
  const earthWeightN = massKg * GRAVITY.earth;
  return { ratio, planetWeightN, earthWeightN, offloadN: earthWeightN - planetWeightN, testMassKg: massKg * ratio, bearingFactor: 1 / ratio };
}
