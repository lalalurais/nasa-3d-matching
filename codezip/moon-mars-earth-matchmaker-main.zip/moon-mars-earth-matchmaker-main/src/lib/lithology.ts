/**
 * Geochemistry & mineralogy criterion, matched by lithologic (rock-type) class.
 * Raw oxide or mineral abundances are not compared: the Drive has no gridded Moon/Mars values,
 * and analog studies match rock suites, not exact chemistry. Separate from the illumination criterion.
 *
 * Planet classes come from published geologic maps, rasterised by scripts/add_illum_litho.py:
 *  - Moon: LROC global mare boundaries (Nelson et al. 2014) → mare basalt vs anorthositic highlands.
 *  - Mars: unit groups of the USGS Geologic Map of Mars (Tanaka et al. 2014, SIM 3292).
 * Earth classes come from each catalog site's geology description (src/data/earth-sites.json).
 * Match: same class = 1, related class = 0.5, otherwise 0.
 */
import type { BodyId } from "./data";

export const EARTH_CLASSES = [
  "Basalt / mafic volcanic", "Anorthosite", "Impact breccia / melt", "Evaporites & salts",
  "Clastic sediments & clays", "Acid-sulfate / iron-sulfide", "Ice & permafrost",
] as const;
export const PLANET_CLASSES: Record<BodyId, readonly string[]> = {
  moon: ["Highlands (anorthositic crust)", "Mare basalt"],
  mars: ["Volcanic units", "Highland units (cratered crust)", "Lowland, basin & transition deposits", "Polar deposits", "Impact units"],
};
/** Similarity table [planet class][Earth class]. */
export const LITHO_MATCH: Record<BodyId, number[][]> = {
  moon: [
    [0, 1, 0.5, 0, 0, 0, 0], // highlands: anorthosite; impact breccias are related (highland crust is impact-brecciated)
    [1, 0, 0, 0, 0, 0, 0], // mare basalt: basalt
  ],
  mars: [
    [1, 0, 0, 0, 0, 0, 0], // volcanic: basalt
    [0.5, 0, 1, 0, 0.5, 0.5, 0], // highlands: impact-brecciated basaltic crust with local clays and sulfates
    [0, 0, 0, 0.5, 1, 0.5, 0], // lowland/basin/transition: sedimentary fill, local evaporites and sulfates
    [0, 0, 0, 0, 0, 0, 1], // polar layered deposits: ice
    [0, 0, 1, 0, 0, 0, 0], // impact units: impact breccia
  ],
};

/** Earth catalog site → class, with the catalog geology text it is read from. */
export const EARTH_LITHO: Record<string, number> = {
  holuhraun: 0, kazumura: 0, maunakea: 0, cratersmoon: 0, eifel: 0, svalbard: 0, blackpoint: 0, lonar: 0, lanzarote: 0,
  mistastin: 1, manicouagan: 1,
  haughton: 2, ries: 2, sudbury: 2, meteorcrater: 2,
  atacama: 3, deathvalley: 3, axelheiberg: 3, qaidam: 3,
  mdrs: 4, namib: 4, pilbara: 4,
  riotinto: 5,
  domec: 6, dryvalleys: 6,
};

export function lithoLabel(side: BodyId | "earth", v: number | null | undefined) {
  if (v == null || v < 0) return "No data available";
  return (side === "earth" ? EARTH_CLASSES : PLANET_CLASSES[side])[v] ?? "No data available";
}
export function lithoSimilarity(body: BodyId, planet: number | null | undefined, earth: number | null | undefined) {
  if (planet == null || earth == null || planet < 0 || earth < 0) return null;
  return LITHO_MATCH[body][planet]?.[earth] ?? null;
}
