import type React from "react";
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { earthGridQuery, gridQuery, moonCell, SITES, type BodyId, type EarthGrid, type MoonGrid, type Site, type VarKey } from "./data";
import { computeBounds, discover, prepare, resolveEarthSite, reverseSearch } from "./analogs";
import { recommendLanding } from "./landing";
import { rank, type Ranked } from "./scoring";
import { selectedCriteria, scoredKeys, toScoreCriteria } from "./criteria";
import { bodyById, type MoonPoint } from "./bodies";

export type { MoonPoint };

/** analogs = Moon/Mars region → Earth places; reverse = Earth place → Moon/Mars regions; landing = recommended landing regions. */
export type Mode = "analogs" | "reverse" | "landing";
interface Ctx {
  mode: Mode; setMode: (m: Mode) => void;
  /** Reverse search: Earth reference (catalog id or `new-<cell>`). */
  earthRefId: string | null; setEarthRefId: (id: string | null) => void;
  /** World on the left globe (Moon or Mars). Switching clears the region and result. */
  body: BodyId; setBody: (b: BodyId) => void;
  point: MoonPoint | null; setPoint: (p: MoonPoint | null) => void;
  siteId: string | null; setSiteId: (id: string | null) => void;
  compare: string[]; toggleCompare: (id: string) => void;
  criteria: string[]; setCriteria: (c: string[]) => void;
  reducedMotion: boolean; setReducedMotion: (v: boolean) => void;
  grid: MoonGrid | undefined; gridError: Error | null;
  /** Every Earth land cell, for the whole-Earth search and the Earth map layer. */
  earth: EarthGrid | undefined;
}
// Keep one context object across hot reloads; a fresh one would orphan the mounted provider.
const g = globalThis as unknown as { __e2sSelectionCtx?: React.Context<Ctx | null> };
const C = g.__e2sSelectionCtx ?? (g.__e2sSelectionCtx = createContext<Ctx | null>(null));

export function SelectionProvider({ children }: { children: ReactNode }) {
  const [point, setPoint] = useState<MoonPoint | null>(null);
  const [siteId, setSiteId] = useState<string | null>(null);
  const [compare, setCompare] = useState<string[]>([]);
  const [criteria, setCriteria] = useState<string[]>(["terrain"]);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [body, setBodyState] = useState<BodyId>("moon");
  const [mode, setMode] = useState<Mode>("analogs");
  const [earthRefId, setEarthRefId] = useState<string | null>(null);
  const q = useQuery(gridQuery(body));
  const eq = useQuery(earthGridQuery);
  const setBody = (b: BodyId) => { if (b !== body) { setBodyState(b); setPoint(null); setSiteId(null); } };

  useEffect(() => {
    try {
      const s = JSON.parse(sessionStorage.getItem("s2e-v4") || "null");
      if (s) { if (s.body === "mars" || s.body === "moon") setBodyState(s.body); if (s.point) setPoint(s.point); if (s.siteId) setSiteId(s.siteId); if (s.compare) setCompare(s.compare); if (Array.isArray(s.criteria)) setCriteria(s.criteria); if (s.mode === "reverse" || s.mode === "landing") setMode(s.mode); if (typeof s.earthRefId === "string") setEarthRefId(s.earthRefId); }
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) setReducedMotion(true);
    } catch { /* ignore */ }
  }, []);
  useEffect(() => {
    sessionStorage.setItem("s2e-v4", JSON.stringify({ body, point, siteId, compare, criteria, mode, earthRefId }));
  }, [body, point, siteId, compare, criteria, mode, earthRefId]);

  const toggleCompare = (id: string) =>
    setCompare((c) => (c.includes(id) ? c.filter((x) => x !== id) : c.length >= 4 ? [...c.slice(1), id] : [...c, id]));

  return (
    <C.Provider value={{ mode, setMode, earthRefId, setEarthRefId, body, setBody, point, setPoint, siteId, setSiteId, compare, toggleCompare, criteria, setCriteria, reducedMotion, setReducedMotion, grid: q.data, gridError: (q.error ?? eq.error) as Error | null, earth: eq.data }}>
      {children}
    </C.Provider>
  );
}
export function useSelection() {
  const c = useContext(C);
  if (!c) throw new Error("useSelection outside provider");
  return c;
}

/** Selected Moon/Mars region + Earth ranking (catalog) and whole-Earth discoveries for the selected criteria. */
export function useAnalogs() {
  const s = useSelection();
  const body = bodyById(s.body);
  const allScored = useMemo(() => scoredKeys(body.criteria), [body]);
  // The grid query is keyed by body, so a grid never pairs with another body's criteria once loaded.
  const bounds = useMemo(() => (s.grid && s.earth ? computeBounds(s.grid, allScored as VarKey[], SITES, body.id, s.earth) : null), [s.grid, s.earth, allScored, body.id]);
  const sel = useMemo(() => selectedCriteria(body.criteria, s.criteria), [body, s.criteria]);
  const cell = useMemo(() => (s.grid && s.point ? moonCell(s.grid, s.point.lat, s.point.lon) : null), [s.grid, s.point]);
  const keys = useMemo(() => scoredKeys(sel.rankable) as VarKey[], [sel]);
  const discoveries = useMemo<Ranked<Site>[] | null>(() => (
    cell && bounds && s.earth ? discover({ earth: s.earth, planet: cell.values, keys, criteria: toScoreCriteria(sel.rankable), calib: bounds }) : null
  ), [cell, bounds, s.earth, keys, sel]);
  return useMemo(() => {
    if (!s.grid || !bounds) return { loading: true as const, sel, body };
    const prep = (site: (typeof SITES)[number]) => prepare(cell?.values ?? {}, site, keys, bounds);
    const ranking = cell ? rank(SITES, prep, toScoreCriteria(sel.rankable)) : null;
    const moonMissing = cell ? keys.filter((k) => cell.values[k] == null) : [];
    const all = [...(ranking?.ranked ?? []), ...(discoveries ?? [])];
    return { loading: false as const, sel, cell, bounds, ranking, discoveries: discoveries ?? [], all, prep, moonMissing, body, keys };
  }, [s.grid, bounds, cell, keys, sel, discoveries, body]);
}

/** Reverse search: the Earth reference place and its best-matching Moon/Mars regions. */
export function useReverse() {
  const s = useSelection(); const a = useAnalogs();
  const ref = useMemo(() => resolveEarthSite(s.earthRefId, s.earth), [s.earthRefId, s.earth]);
  const matches = useMemo(() => {
    if (s.mode !== "reverse" || a.loading || !ref || !s.grid) return null;
    return reverseSearch({ grid: s.grid, earth: ref.values, keys: a.keys, criteria: toScoreCriteria(a.sel.rankable), calib: a.bounds });
  }, [s.mode, a, ref, s.grid]);
  return { ref, matches };
}

/** Recommended landing regions on the current world. */
export function useLanding() {
  const s = useSelection();
  return useMemo(() => (s.mode === "landing" && s.grid ? recommendLanding(s.grid, s.body) : null), [s.mode, s.grid, s.body]);
}
