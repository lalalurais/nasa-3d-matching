import { PERCENTILES, SITES, VAR_BY_KEY, earthCellCenter, type BodyId, type EarthGrid, type MoonGrid, type Site, type Values, type VarKey } from "./data";
import { makeBounds, scale, score, type Bounds, type Num, type Prepared, type Ranked, type ScoreCriterion } from "./scoring";
import { lon180 } from "./geo";
import { LITHO_MATCH } from "./lithology";

export type BoundsSet = Partial<Record<VarKey, Bounds>>;
export type World = "moon" | "earth";

/** Percentile rank (0–1, mid-rank for ties) of v inside a sorted distribution. Binary search, so whole-planet scans stay fast. */
export function pctRank(sorted: number[], v: number) {
  if (!sorted.length) return NaN;
  if (sorted.length === 1) return 0.5;
  const bound = (strict: boolean) => {
    let lo = 0, hi = sorted.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (strict ? sorted[m]! < v : sorted[m]! <= v) lo = m + 1; else hi = m; }
    return lo;
  };
  const below = bound(true), upto = bound(false);
  return Math.min(1, Math.max(0, ((below + upto) / 2 - 0.5) / (sorted.length - 1)));
}
const PCT_BOUNDS: Bounds = { p5: 0, p95: 1, q: [0.25, 0.5, 0.75] };
const sortNums = (a: readonly Num[]) => a.filter((v): v is number => typeof v === "number" && !Number.isNaN(v)).sort((x, y) => x - y);

export interface Calib {
  bounds: BoundsSet;
  /** Value used for scoring: the raw value on a shared scale, or the world's own percentile. */
  value: (k: VarKey, world: World, v: Num) => Num;
  /** Position 0–1 of a world's value on the scale used for scoring (shared scale or own-world percentile). */
  pos: (k: VarKey, world: World, v: Num) => number | null;
  /** Match table for categorical variables (rock class), else undefined. */
  table: (k: VarKey) => number[][] | undefined;
}

/**
 * Shared-scale variables: pooled planet + Earth 5th–95th percentile bounds.
 * Percentile variables: each world's value becomes its percentile within that world
 * (the planet side is the Moon or Mars, whichever body the grid belongs to),
 * so "high for the Moon" is matched with "high for Earth".
 * With an Earth grid, Earth's side is every Earth land cell; without one, the catalog sites (and prebuilt tables).
 */
export function computeBounds(grid: MoonGrid, keys: VarKey[], sites: Site[] = SITES, body: BodyId = "moon", earth?: EarthGrid): Calib {
  const bounds: BoundsSet = {};
  const dist: Partial<Record<VarKey, Record<World, number[]>>> = {};
  const tables = PERCENTILES as unknown as Record<World, Partial<Record<VarKey, number[]>>>;
  for (const k of keys) {
    const earthVals = earth?.vars[k];
    if (VAR_BY_KEY[k].scoreMode === "category") { bounds[k] = PCT_BOUNDS; continue; }
    if (VAR_BY_KEY[k].scoreMode === "percentile") {
      dist[k] = {
        // "moon" = the planet side; Moon has prebuilt tables, other bodies use their own grid.
        moon: (body === "moon" ? tables.moon[k] : undefined) ?? sortNums(grid.vars[k] ?? []),
        earth: earthVals ? sortNums(earthVals) : tables.earth[k] ?? sortNums(sites.map((s) => s.values[k])),
      };
      bounds[k] = PCT_BOUNDS;
    } else bounds[k] = makeBounds([...(grid.vars[k] ?? []), ...(earthVals ?? sites.map((s) => s.values[k]))]);
  }
  const value = (k: VarKey, w: World, v: Num): Num => {
    if (typeof v !== "number" || Number.isNaN(v)) return null;
    const d = dist[k];
    return d ? pctRank(d[w], v) : v;
  };
  const category = (k: VarKey) => VAR_BY_KEY[k].scoreMode === "category";
  return {
    bounds, value,
    pos: (k, w, v) => { if (category(k)) return null; const x = value(k, w, v); const b = bounds[k]; return x == null || !b ? null : scale(x, b); },
    table: (k) => (k === "litho" ? LITHO_MATCH[body] : undefined),
  };
}

export function prepare(moon: Values, site: Site, keys: VarKey[], c: Calib): Prepared {
  const p: Prepared = {};
  for (const k of keys) if (c.bounds[k]) p[k] = { moon: c.value(k, "moon", moon[k]), earth: c.value(k, "earth", site.values[k]), bounds: c.bounds[k]!, table: c.table(k) };
  return p;
}

const R_EARTH_KM = 6371;
/** Great-circle distance in km. */
export function distanceKm(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const r = Math.PI / 180, dLat = (b.lat - a.lat) * r, dLon = (b.lon - a.lon) * r;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLon / 2) ** 2;
  return 2 * R_EARTH_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}

export const DISCOVERY = { n: 10, minFromCatalogKm: 150, minSpacingKm: 500 } as const;

/** Earth cell as a Site-shaped candidate (no catalog description: it is not in the catalog). */
export function cellAsSite(earth: EarthGrid, pos: number, keys: readonly VarKey[] = Object.keys(earth.vars) as VarKey[]): Site {
  const idx = earth.cells[pos]!;
  const c = earthCellCenter(earth, idx);
  const values: Values = {};
  for (const k of keys) values[k] = earth.vars[k]?.[pos] ?? null;
  const lat = c.lat, lon = lon180(c.lon);
  return {
    id: `new-${idx}`, name: "New candidate", country: "Not in the analog catalog", continent: "", lat, lon,
    terrain: "", geology: "", caves: false, water: "", biology: "", access: "", use: "", ref: "Space2Earth whole-Earth search of the Drive Earth grids",
    values, cells: { terrain: [lat, lon], temp: [lat, lon] }, discovery: true,
  };
}

/**
 * Search every Earth land cell for the closest match to a planet region ("places NASA hasn't listed yet").
 * Skips cells within `minFromCatalogKm` of a cataloged analog site and keeps candidates at least
 * `minSpacingKm` apart, so the list shows distinct places rather than neighbouring cells.
 */
export function discover(o: {
  earth: EarthGrid; planet: Values; keys: VarKey[]; criteria: ScoreCriterion[]; calib: Calib; sites?: Site[];
  n?: number; minFromCatalogKm?: number; minSpacingKm?: number;
}): Ranked<Site>[] {
  const { earth, planet, keys, criteria, calib } = o;
  const sites = o.sites ?? SITES;
  const n = o.n ?? DISCOVERY.n, minCat = o.minFromCatalogKm ?? DISCOVERY.minFromCatalogKm, minSp = o.minSpacingKm ?? DISCOVERY.minSpacingKm;
  if (!criteria.length || !keys.length) return [];
  const pv: Partial<Record<VarKey, Num>> = {};
  for (const k of keys) pv[k] = calib.value(k, "moon", planet[k]);
  const ev = keys.map((k) => earth.vars[k] ?? []);
  const scored: { pos: number; overall: number }[] = [];
  for (let pos = 0; pos < earth.cells.length; pos++) {
    const p: Prepared = {};
    keys.forEach((k, i) => { if (calib.bounds[k]) p[k] = { moon: pv[k], earth: calib.value(k, "earth", ev[i]![pos]), bounds: calib.bounds[k]!, table: calib.table(k) }; });
    const r = score(p, criteria);
    if (r.overall !== null && !r.limited) scored.push({ pos, overall: r.overall });
  }
  scored.sort((a, b) => b.overall - a.overall || earth.cells[a.pos]! - earth.cells[b.pos]!);
  const picked: Site[] = [];
  for (const s of scored) {
    if (picked.length >= n) break;
    const c = earthCellCenter(earth, earth.cells[s.pos]!);
    const pt = { lat: c.lat, lon: lon180(c.lon) };
    if (sites.some((x) => distanceKm(pt, x) < minCat)) continue;
    if (picked.some((x) => distanceKm(pt, x) < minSp)) continue;
    picked.push(cellAsSite(earth, s.pos));
  }
  return picked.map((site, i) => ({ item: { ...site, name: `New candidate N${i + 1}` }, result: score(prepare(planet, site, keys, calib), criteria), rank: i + 1, robust: null }));
}

/** Earth location (catalog site id, or `new-<grid index>` for any Earth land cell) as a Site; null if unknown or ocean. */
export function resolveEarthSite(id: string | null | undefined, earth?: EarthGrid, sites: Site[] = SITES): Site | null {
  if (!id) return null;
  const s = sites.find((x) => x.id === id);
  if (s) return s;
  const m = /^new-(\d+)$/.exec(id);
  if (!m || !earth) return null;
  const pos = earth.cells.indexOf(Number(m[1]));
  return pos < 0 ? null : { ...cellAsSite(earth, pos), name: "Earth location" };
}
/** Id of the Earth land cell containing a point, or null over the ocean. */
export function earthCellId(earth: EarthGrid, lat: number, lon: number) {
  const i = Math.min(earth.nlat - 1, Math.max(0, Math.floor((lat + 90) / earth.step)));
  const j = Math.min(earth.nlon - 1, Math.floor((((lon % 360) + 360) % 360) / earth.step));
  const idx = i * earth.nlon + j;
  return earth.cells.includes(idx) ? `new-${idx}` : null;
}

/** A Moon or Mars data bin returned by the reverse search. */
export interface PlanetMatch { id: string; index: number; lat: number; lon: number }
export const REVERSE = { n: 10, minSpacingDeg: 10 } as const;
const angDeg = (a: { lat: number; lon: number }, b: { lat: number; lon: number }) => {
  const r = Math.PI / 180;
  const c = Math.sin(a.lat * r) * Math.sin(b.lat * r) + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.cos((b.lon - a.lon) * r);
  return Math.acos(Math.min(1, Math.max(-1, c))) / r;
};
/**
 * Reverse search (Earth → Moon/Mars): score every planet bin against one Earth place with the same
 * criteria and scales as the forward search, keep the best bins at least `minSpacingDeg` apart.
 */
export function reverseSearch(o: {
  grid: MoonGrid; earth: Values; keys: VarKey[]; criteria: ScoreCriterion[]; calib: Calib; n?: number; minSpacingDeg?: number;
}): Ranked<PlanetMatch>[] {
  const { grid, keys, criteria, calib } = o;
  const n = o.n ?? REVERSE.n, sp = o.minSpacingDeg ?? REVERSE.minSpacingDeg;
  if (!criteria.length || !keys.length) return [];
  const ev: Partial<Record<VarKey, Num>> = {};
  for (const k of keys) ev[k] = calib.value(k, "earth", o.earth[k]);
  const cols = keys.map((k) => grid.vars[k] ?? []);
  const total = grid.nlat * grid.nlon;
  const scored: { n: number; overall: number }[] = [];
  for (let c = 0; c < total; c++) {
    const p: Prepared = {};
    keys.forEach((k, i) => { if (calib.bounds[k]) p[k] = { moon: calib.value(k, "moon", cols[i]![c]), earth: ev[k], bounds: calib.bounds[k]!, table: calib.table(k) }; });
    const r = score(p, criteria);
    if (r.overall !== null && !r.limited) scored.push({ n: c, overall: r.overall });
  }
  scored.sort((a, b) => b.overall - a.overall || a.n - b.n);
  const picked: PlanetMatch[] = [];
  for (const x of scored) {
    if (picked.length >= n) break;
    const i = Math.floor(x.n / grid.nlon), j = x.n % grid.nlon;
    const pt = { id: `bin-${x.n}`, index: x.n, lat: -90 + (i + 0.5) * grid.step, lon: (j + 0.5) * grid.step };
    if (picked.some((q) => angDeg(q, pt) < sp)) continue;
    picked.push(pt);
  }
  return picked.map((item, i) => {
    const values: Values = {};
    keys.forEach((k, ki) => (values[k] = cols[ki]![item.index] ?? null));
    const p: Prepared = {};
    for (const k of keys) if (calib.bounds[k]) p[k] = { moon: calib.value(k, "moon", values[k]), earth: ev[k], bounds: calib.bounds[k]!, table: calib.table(k) };
    return { item, result: score(p, criteria), rank: i + 1, robust: null };
  });
}
