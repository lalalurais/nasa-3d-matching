import type { VarKey } from "@/lib/data";
import { makeBounds } from "@/lib/scoring";
const STOPS: number[][] = [[46, 150, 245], [9, 96, 225], [0, 66, 166], [7, 23, 63]]; // Blue Yonder → Deep Blue
export function rampColor(t: number) {
  const x = Math.min(0.999, Math.max(0, 1 - t)) * (STOPS.length - 1); // high values = light
  const i = Math.floor(x), f = x - i;
  return STOPS[i]!.map((c, k) => Math.round(c + (STOPS[i + 1]![k]! - c) * f));
}
/** Data layer as an equirectangular canvas. `cells` = grid index of each value (sparse grids such as Earth land cells). */
export function buildOverlay(grid: { nlat: number; nlon: number; vars: Partial<Record<VarKey, (number | null)[]>>; cells?: number[] }, key: VarKey, range?: [number, number]) {
  const c = document.createElement("canvas");
  c.width = grid.nlon; c.height = grid.nlat;
  const ctx = c.getContext("2d")!;
  const img = ctx.createImageData(grid.nlon, grid.nlat);
  const vals = grid.vars[key] ?? [];
  const b = range ? { p5: range[0], p95: range[1] } : makeBounds(vals);
  vals.forEach((v, n) => {
    if (v == null || (range && v < range[0])) return;
    const idx = grid.cells ? grid.cells[n]! : n;
    const i = Math.floor(idx / grid.nlon), j = idx % grid.nlon;
    const o = ((grid.nlat - 1 - i) * grid.nlon + j) * 4;
    const [r, g, bb] = rampColor((v - b.p5) / (b.p95 - b.p5 || 1));
    img.data.set([r!, g!, bb!, 255], o);
  });
  ctx.putImageData(img, 0, 0);
  return { canvas: c, min: b.p5, max: b.p95 };
}
