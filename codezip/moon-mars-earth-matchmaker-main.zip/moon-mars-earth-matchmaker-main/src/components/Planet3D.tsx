/** Planet-agnostic 3D body: textured sphere + optional overlay, markers and picking. */
import { Canvas, useFrame, useLoader, useThree, type ThreeEvent } from "@react-three/fiber";
import { OrbitControls, Stars, Html, Line } from "@react-three/drei";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";

export interface Marker { id: string; lat: number; lon: number; label: string; badge?: string; tone: "primary" | "secondary" | "selected" | "moon" }
export interface Region { lat0: number; lat1: number; lon0: number; lon1: number }
export interface Planet3DProps {
  texture: string; bump?: string; bumpOffsetX?: number;
  overlay?: HTMLCanvasElement | null | undefined; overlayOffsetX?: number;
  markers?: Marker[]; pick?: { lat: number; lon: number } | null;
  onPick?: ((lat: number, lon: number) => void) | undefined; onMarker?: ((id: string) => void) | undefined;
  focus?: { lat: number; lon: number; key: string } | null;
  reducedMotion?: boolean; companion?: string; atmosphere?: boolean;
  region?: Region | null; autoRotate?: boolean; label?: string;
}

export function latLonToVec(lat: number, lon: number, r = 1) {
  const la = THREE.MathUtils.degToRad(lat), lo = THREE.MathUtils.degToRad(lon);
  return new THREE.Vector3(r * Math.cos(la) * Math.cos(lo), r * Math.sin(la), -r * Math.cos(la) * Math.sin(lo));
}
export function vecToLatLon(v: THREE.Vector3) {
  const n = v.clone().normalize();
  return { lat: THREE.MathUtils.radToDeg(Math.asin(n.y)), lon: THREE.MathUtils.radToDeg(Math.atan2(-n.z, n.x)) };
}
const TONE: Record<Marker["tone"], string> = { primary: "#2E96F5", secondary: "#FFFFFF", selected: "#EAFE07", moon: "#EAFE07" };

function Body({ texture, bump, bumpOffsetX = 0, overlay, overlayOffsetX = 0, markers = [], pick, onPick, onMarker, atmosphere, region }: Planet3DProps) {
  const map = useLoader(THREE.TextureLoader, texture);
  const bumpTex = useLoader(THREE.TextureLoader, bump ?? texture);
  useMemo(() => {
    map.colorSpace = THREE.SRGBColorSpace; map.anisotropy = 4;
    bumpTex.wrapS = THREE.RepeatWrapping; bumpTex.offset.x = bumpOffsetX; bumpTex.needsUpdate = true;
  }, [map, bumpTex, bumpOffsetX]);
  const overlayTex = useMemo(() => {
    if (!overlay) return null;
    const t = new THREE.CanvasTexture(overlay);
    t.wrapS = THREE.RepeatWrapping; t.offset.x = overlayOffsetX; t.magFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [overlay, overlayOffsetX]);
  const handleClick = (e: ThreeEvent<MouseEvent>) => {
    if (!onPick || e.delta > 5) return; // ignore drags
    e.stopPropagation();
    const { lat, lon } = vecToLatLon(e.object.worldToLocal(e.point.clone()));
    onPick(lat, lon);
  };
  return (
    <group>
      <mesh onClick={handleClick}>
        <sphereGeometry args={[1, 128, 64]} />
        <meshStandardMaterial map={map} bumpMap={bump ? bumpTex : null} bumpScale={bump ? 4 : 0} roughness={1} metalness={0} />
      </mesh>
      {overlayTex && (
        <mesh raycast={() => null}>
          <sphereGeometry args={[1.003, 128, 64]} />
          <meshBasicMaterial map={overlayTex} transparent opacity={0.72} depthWrite={false} />
        </mesh>
      )}
      {atmosphere && (
        <mesh raycast={() => null}>
          <sphereGeometry args={[1.025, 64, 32]} />
          <meshBasicMaterial color="#2E96F5" transparent opacity={0.08} side={THREE.BackSide} />
        </mesh>
      )}
      {markers.map((m) => (
        <MarkerPin key={m.id} m={m} onMarker={onMarker} />
      ))}
      {region && <RegionOutline r={region} />}
      {pick && (
        <mesh position={latLonToVec(pick.lat, pick.lon, 1.012)}>
          <ringGeometry args={[0.02, 0.032, 32]} />
          <meshBasicMaterial color="#EAFE07" side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}

/** Outline of a lat/lon data bin drawn on the sphere surface. */
function RegionOutline({ r }: { r: Region }) {
  const pts = useMemo(() => {
    const out: THREE.Vector3[] = [], n = 12, R = 1.006;
    for (let i = 0; i <= n; i++) out.push(latLonToVec(r.lat0, r.lon0 + ((r.lon1 - r.lon0) * i) / n, R));
    for (let i = 0; i <= n; i++) out.push(latLonToVec(r.lat0 + ((r.lat1 - r.lat0) * i) / n, r.lon1, R));
    for (let i = 0; i <= n; i++) out.push(latLonToVec(r.lat1, r.lon1 - ((r.lon1 - r.lon0) * i) / n, R));
    for (let i = 0; i <= n; i++) out.push(latLonToVec(r.lat1 - ((r.lat1 - r.lat0) * i) / n, r.lon0, R));
    return out;
  }, [r.lat0, r.lat1, r.lon0, r.lon1]);
  return <Line points={pts} color="#EAFE07" lineWidth={3} />;
}

/** Numbered marker; its label hides when the point is on the far side of the globe. */
function MarkerPin({ m, onMarker }: { m: Marker; onMarker?: ((id: string) => void) | undefined }) {
  const p = useMemo(() => latLonToVec(m.lat, m.lon, 1.01), [m.lat, m.lon]);
  const label = useRef<HTMLDivElement>(null);
  const { camera } = useThree();
  useFrame(() => {
    if (!label.current) return;
    const visible = p.clone().normalize().dot(camera.position.clone().normalize()) > 0.15;
    label.current.style.opacity = visible ? "1" : "0";
    label.current.style.pointerEvents = visible ? "auto" : "none";
  });
  const sel = m.tone === "selected";
  return (
    <group position={p}>
      <mesh onClick={(e) => { e.stopPropagation(); onMarker?.(m.id); }}>
        <sphereGeometry args={[sel ? 0.03 : 0.02, 16, 16]} />
        <meshBasicMaterial color={TONE[m.tone]} />
      </mesh>
      <Html zIndexRange={[10, 0]} center={false}>
        <div ref={label} style={{ transform: "translate(6px,-50%)" }}>
          <button type="button" tabIndex={-1} onClick={() => onMarker?.(m.id)}
            className={`flex items-center gap-1 whitespace-nowrap rounded-full px-1.5 py-0.5 text-[11px] font-bold ring-1 ${sel ? "bg-highlight text-primary-foreground ring-highlight" : "bg-background/90 text-foreground ring-border"}`}>
            {m.badge && <span className={`grid h-4 min-w-4 place-items-center rounded-full px-1 ${sel ? "bg-deep-blue text-highlight" : "bg-blue-yonder text-deep-blue"}`}>{m.badge}</span>}
            <span className={sel ? "" : "hidden sm:inline"}>{m.label}</span>
          </button>
        </div>
      </Html>
    </group>
  );
}

function FocusRig({ focus, reducedMotion, controls }: { focus: Planet3DProps["focus"]; reducedMotion?: boolean | undefined; controls: React.RefObject<any> }) {
  const { camera } = useThree();
  const target = useRef<THREE.Vector3 | null>(null);
  useEffect(() => {
    if (!focus) return;
    const dist = camera.position.length();
    target.current = latLonToVec(focus.lat, focus.lon, dist);
    if (reducedMotion) { camera.position.copy(target.current); target.current = null; controls.current?.update(); }
  }, [focus?.key]); // eslint-disable-line react-hooks/exhaustive-deps
  useFrame((_, dt) => {
    if (!target.current) return;
    const d = camera.position.length();
    const next = camera.position.clone().lerp(target.current, 1 - Math.exp(-4 * Math.min(dt, 0.05))).setLength(d);
    camera.position.copy(next); camera.lookAt(0, 0, 0); controls.current?.update();
    if (next.distanceTo(target.current) < 0.01) target.current = null;
  });
  return null;
}

export default function Planet3D(props: Planet3DProps) {
  const controls = useRef<any>(null);
  const [ready, setReady] = useState(false);
  return (
    <div className="relative h-full w-full" data-scene-ready={ready ? "" : undefined} role="img" aria-label={props.label ?? "Interactive 3D globe"}>
      <Canvas camera={{ position: [3, 0.6, 0.4], fov: 40 }} dpr={[1, 2]} onCreated={() => setReady(true)} gl={{ antialias: true }}>
        <color attach="background" args={["#030a1f"]} />
        <ambientLight intensity={0.35} />
        <directionalLight position={[5, 2, 3]} intensity={2.2} />
        <Stars radius={60} depth={30} count={2500} factor={3} fade speed={props.reducedMotion ? 0 : 0.4} />
        <Suspense fallback={null}>
          <Body {...props} />
          {props.companion && <Companion url={props.companion} />}
        </Suspense>
        <OrbitControls ref={controls} enablePan={false} minDistance={1.4} maxDistance={8} autoRotate={!props.reducedMotion && (props.autoRotate ?? !props.pick)} autoRotateSpeed={0.3} />
        <FocusRig focus={props.focus} reducedMotion={props.reducedMotion} controls={controls} />
      </Canvas>
    </div>
  );
}

function Companion({ url }: { url: string }) {
  const map = useLoader(THREE.TextureLoader, url);
  map.colorSpace = THREE.SRGBColorSpace;
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, dt) => { if (ref.current) ref.current.rotation.y += Math.min(dt, 0.05) * 0.1; });
  return (
    <mesh ref={ref} position={[-9, 3, -14]} raycast={() => null}>
      <sphereGeometry args={[1.6, 48, 24]} />
      <meshStandardMaterial map={map} />
    </mesh>
  );
}
