import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ExternalLink, FileText, MapPin } from "lucide-react";
import { Planet } from "@/components/Planet";
import { buildOverlay } from "@/components/overlay";
import { HelpDialog } from "@/components/HelpDialog";
import { useAnalogs, useLanding, useReverse, useSelection, type Mode } from "@/lib/selection";
import { BODIES, bodyById, type BodyConfig } from "@/lib/bodies";
import { isRankable } from "@/lib/criteria";
import { binSizeKm, fmtVal, fmtValue, googleMapsUrl, moonCell, osmUrl, planetSide, SITES, SOURCES, sourceUrl, VAR_BY_KEY, type BodyId, type MoonCell, type Site, type VarKey } from "@/lib/data";
import { fmtCoord, fmtLat, fmtLon } from "@/lib/geo";
import { COVERAGE_THRESHOLD, MAX_RESULTS, METHOD_VERSION, score, type Ranked, type Result } from "@/lib/scoring";
import { earthCellId, prepare, REVERSE, type Calib } from "@/lib/analogs";
import { toScoreCriteria } from "@/lib/criteria";
import { LANDING, LANDING_FACTORS, LANDING_MIN_COVERAGE, landingScorer } from "@/lib/landing";
import { PLANET_CLASSES } from "@/lib/lithology";
import { rampColor } from "@/components/overlay";
import { GuidedTour } from "@/components/GuidedTour";
import earthTex from "@/assets/earth-blue-marble.jpg.asset.json";

const pct = (x: number | null | undefined) => (x == null ? "—" : `${Math.round(x * 100)}`);
const LAYERS: { k: VarKey | "none"; l: string; mars?: string }[] = [
  { k: "none", l: "Surface photo" }, { k: "relief", l: "Local relief" }, { k: "range", l: "Elevation range" }, { k: "elev", l: "Elevation" },
  { k: "slope", l: "Slope" }, { k: "rough", l: "Roughness" }, { k: "tnoon", l: "Noon temperature" }, { k: "tnight", l: "Night temperature" },
  { k: "ice", l: "Hydrogen (ice indicator)", mars: "Ice consistency" }, { k: "rad", l: "Radiation proxy", mars: "Fast neutrons (radiation proxy)" },
  { k: "illum", l: "Solar irradiance" }, { k: "litho", l: "Rock type (geologic map)" },
];
const MODES: { k: Mode; l: string; hint: (b: string) => string }[] = [
  { k: "analogs", l: "→ Earth analogs", hint: (b) => `Pick a ${b} region, find Earth places like it.` },
  { k: "reverse", l: "Earth → ", hint: (b) => `Pick an Earth place, find ${b} regions like it.` },
  { k: "landing", l: "Landing sites", hint: (b) => `Recommended ${b} landing regions from the data.` },
];
const unitName = (grid: { unitNames?: string[]; unit?: number[] } | undefined, index: number) => {
  const u = grid?.unit?.[index]; return u != null && u >= 0 ? grid?.unitNames?.[u] ?? null : null;
};

export function Explorer({ world }: { world?: BodyId | undefined }) {
  const s = useSelection();
  const a = useAnalogs();
  const navigate = useNavigate();
  const body = bodyById(s.body);
  useEffect(() => { if (world) s.setBody(world); }, [world]); // eslint-disable-line react-hooks/exhaustive-deps
  const [layer, setLayer] = useState<VarKey | "none">("none");
  const layers = LAYERS.filter((x) => x.k === "none" || (s.grid?.vars[x.k] ?? []).some((v) => v != null));
  const activeLayer = layers.some((x) => x.k === layer) ? layer : "none";
  const ov = useMemo(() => (s.grid && activeLayer !== "none" ? buildOverlay(s.grid, activeLayer, activeLayer === "litho" ? [0, PLANET_CLASSES[body.id].length - 1] : undefined) : null), [s.grid, activeLayer, body.id]);
  const cell = a.loading ? null : a.cell;
  const ranked = a.loading ? [] : (a.ranking?.ranked ?? []);
  const found = a.loading ? [] : a.discoveries;
  const selected = [...ranked, ...found].find((r) => r.item.id === s.siteId) ?? null;
  const selSite = selected?.item ?? (s.siteId ? SITES.find((x) => x.id === s.siteId) ?? null : null);
  const [earthLayer, setEarthLayer] = useState<VarKey | "none">("none");
  const earthLayers = LAYERS.filter((x) => x.k === "none" || (s.earth?.vars[x.k] ?? []).some((v) => v != null));
  const eov = useMemo(() => (s.earth && earthLayer !== "none" ? buildOverlay(s.earth, earthLayer) : null), [s.earth, earthLayer]);
  const region = cell ? { lat0: cell.cellLat - cell.step / 2, lat1: cell.cellLat + cell.step / 2, lon0: cell.cellLon - cell.step / 2, lon1: cell.cellLon + cell.step / 2 } : null;
  const rv = useReverse();
  const land = useLanding();
  const [earthMsg, setEarthMsg] = useState<string | null>(null);
  const mode = s.mode;
  const atCell = (lat: number, lon: number) => !!cell && Math.abs(cell.cellLat - lat) < 1e-6 && Math.abs(cell.cellLon - lon) < 1e-6;

  const forwardMarkers = ranked.map((r) => ({
    id: r.item.id, lat: r.item.lat, lon: r.item.lon, badge: String(r.rank), label: r.item.name.split(" (")[0]!,
    tone: (r.item.id === s.siteId ? "selected" : "primary") as "selected" | "primary" | "secondary",
  })).concat(found.map((r) => ({
    id: r.item.id, lat: r.item.lat, lon: r.item.lon, badge: `N${r.rank}`, label: "New",
    tone: (r.item.id === s.siteId ? "selected" : "secondary") as "selected" | "primary" | "secondary",
  })));
  const reverseEarthMarkers = SITES.map((x) => ({ id: x.id, lat: x.lat, lon: x.lon, label: x.name.split(" (")[0]!, tone: (x.id === s.earthRefId ? "selected" : "primary") as "selected" | "primary" | "secondary" }))
    .concat(rv.ref && rv.ref.discovery ? [{ id: rv.ref.id, lat: rv.ref.lat, lon: rv.ref.lon, label: "Your Earth place", tone: "selected" as const }] : []);
  const markers = mode === "reverse" ? reverseEarthMarkers : forwardMarkers;
  const planetMarkers = mode === "reverse"
    ? (rv.matches ?? []).map((m) => ({ id: m.item.id, lat: m.item.lat, lon: m.item.lon, badge: `R${m.rank}`, label: unitName(s.grid, m.item.index) ?? `${pct(m.result.overall)}`, tone: (atCell(m.item.lat, m.item.lon) ? "selected" : "primary") as "selected" | "primary" }))
    : mode === "landing"
      ? (land ?? []).map((l) => ({ id: `L-${l.index}`, lat: l.lat, lon: l.lon, badge: `L${l.rank}`, label: unitName(s.grid, l.index) ?? "Landing", tone: (atCell(l.lat, l.lon) ? "selected" : "primary") as "selected" | "primary" }))
      : [];
  const onPlanetMarker = (id: string) => {
    const m = rv.matches?.find((x) => x.item.id === id);
    if (m) { s.setPoint({ lat: m.item.lat, lon: m.item.lon, label: `Match R${m.rank}` }); return; }
    const l = land?.find((x) => `L-${x.index}` === id);
    if (l) { s.setPoint({ lat: l.lat, lon: l.lon, label: `Landing L${l.rank}` }); s.setSiteId(null); }
  };
  const onEarthPick = (lat: number, lon: number) => {
    if (mode !== "reverse" || !s.earth) return;
    const id = earthCellId(s.earth, lat, lon);
    if (!id) { setEarthMsg(`No Earth land data at ${fmtCoord(lat, lon)} (ocean). Click on land or pick a catalog site.`); return; }
    setEarthMsg(null); s.setEarthRefId(id); s.setPoint(null);
  };
  const onEarthMarker = (id: string) => {
    if (mode === "reverse") { setEarthMsg(null); s.setEarthRefId(id); s.setPoint(null); } else s.setSiteId(id);
  };
  const earthFocus = mode === "reverse" ? (rv.ref ? { lat: rv.ref.lat, lon: rv.ref.lon, key: rv.ref.id } : null) : selSite ? { lat: selSite.lat, lon: selSite.lon, key: selSite.id } : null;

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-4xl">{mode === "reverse" ? `Find ${body.name} regions like an Earth place` : mode === "landing" ? `Where to land on ${body.id === "moon" ? "the Moon" : "Mars"}` : `Find Earth analogs for a ${body.name} region`}</h1>
          <div role="tablist" aria-label="Search direction" className="mt-2 flex flex-wrap gap-1 text-sm">
            {MODES.map((m) => (
              <button key={m.k} role="tab" type="button" aria-selected={mode === m.k} title={m.hint(body.name)}
                onClick={() => { if (m.k === mode) return; if (m.k === "reverse" || mode === "reverse") s.setPoint(null); s.setMode(m.k); if (m.k !== "analogs") s.setSiteId(null); }}
                className={`rounded-md border px-3 py-1 ${mode === m.k ? "bg-electric-blue font-bold text-highlight" : "text-muted-foreground hover:bg-accent"}`}>
                {m.k === "analogs" ? `${body.name} ${m.l}` : m.k === "reverse" ? `${m.l}${body.name}` : m.l}
              </button>
            ))}
          </div>
          <p className="mt-1 hidden max-w-2xl text-sm text-muted-foreground sm:block">{MODES.find((m) => m.k === mode)!.hint(body.name)}</p>
        </div>
        <div className="flex items-center gap-2">
          <div role="group" aria-label="World to explore" className="flex rounded-md border p-0.5 text-sm">
            {BODIES.map((b) => (
              <button key={b.id} type="button" disabled={!b.available} aria-pressed={b.id === body.id}
                onClick={() => { s.setBody(b.id); void navigate({ to: "/", search: { world: b.id }, replace: true }); }}
                className={`rounded px-3 py-1 ${b.id === body.id ? "bg-electric-blue font-bold text-highlight" : "text-muted-foreground hover:bg-accent"} disabled:cursor-not-allowed`}
                title={b.available ? undefined : "Coming soon, once validated Mars data is available"}>
                {b.name}{!b.available && " (soon)"}
              </button>
            ))}
          </div>
          <GuidedTour />
          <HelpDialog />
        </div>
      </div>

      {/* Source order = mobile stacking (Moon map, Earth map, Moon panels, Earth panels); 2 columns from md up. */}
      <div className="grid items-start gap-x-6 gap-y-3 md:grid-cols-2">
        <section data-tour="moon" aria-labelledby="moon-h" className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 id="moon-h" className="text-xl">1 · {body.name}</h2>
            <label className="flex items-center gap-2 text-xs">Map layer
              <select value={activeLayer} onChange={(e) => setLayer(e.target.value as VarKey | "none")} className="rounded border bg-deep-blue px-2 py-1">
                {layers.map((x) => <option key={x.k} value={x.k}>{body.id === "mars" && x.mars ? x.mars : x.l}</option>)}
              </select>
            </label>
          </div>
          <Planet key={body.id} className="h-[240px] overflow-hidden rounded-lg border sm:h-[320px] lg:h-[420px]" label={`3D ${body.name}. Click to select a data region.`}
            texture={body.texture} bump={body.bump} bumpOffsetX={body.bumpOffsetX} overlay={ov?.canvas} overlayOffsetX={body.overlayOffsetX}
            pick={s.point} region={region} onPick={(lat, lon) => { s.setPoint({ lat, lon }); s.setSiteId(null); }}
            markers={planetMarkers} onMarker={onPlanetMarker} autoRotate={!s.point && !planetMarkers.length}
            reducedMotion={s.reducedMotion} focus={s.point ? { lat: s.point.lat, lon: s.point.lon, key: `${s.point.lat},${s.point.lon}` } : null}
            fallback={<p className="text-sm">Use the coordinates box or quick picks below to choose a region.</p>} />
          {s.point && <p className="text-xs font-bold text-highlight md:hidden">{body.name} region: {fmtCoord(s.point.lat, s.point.lon)}</p>}
        </section>

        <section data-tour="earth" aria-labelledby="earth-h" className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 id="earth-h" className="text-xl">{mode === "reverse" ? "2 · Earth reference place" : "2 · Earth analogs"}</h2>
            <label className="flex items-center gap-2 text-xs">Map layer
              <select value={earthLayer} onChange={(e) => setEarthLayer(e.target.value as VarKey | "none")} className="rounded border bg-deep-blue px-2 py-1">
                {earthLayers.map((x) => <option key={x.k} value={x.k}>{x.k === "ice" ? "Permafrost (ice indicator)" : x.l}</option>)}
              </select>
            </label>
          </div>
          <Planet className="h-[240px] overflow-hidden rounded-lg border sm:h-[320px] lg:h-[420px]" label="3D Earth with numbered analog markers."
            texture={earthTex.url} atmosphere overlay={eov?.canvas} overlayOffsetX={0.5} markers={markers} onMarker={onEarthMarker} autoRotate={mode === "reverse" ? !rv.ref : !s.siteId && !ranked.length}
            onPick={mode === "reverse" ? onEarthPick : undefined}
            reducedMotion={s.reducedMotion} focus={earthFocus}
            fallback={<p className="text-sm">The ranked list below works without 3D.</p>} />
          {earthMsg && mode === "reverse" && <p role="alert" className="text-xs text-highlight">{earthMsg}</p>}
          {mode === "reverse" && <p className="text-xs text-muted-foreground">Click any land area or a catalog site marker to set the Earth reference.</p>}
        </section>

        <div className="min-w-0 space-y-3">
          {eov && <p className="text-xs text-muted-foreground">Earth layer scale: {eov.min.toFixed(1)} (dark) → {eov.max.toFixed(1)} (light). Earth data covers land only.</p>}
          {ov && activeLayer !== "litho" && <p className="text-xs text-muted-foreground">Layer scale: {ov.min.toFixed(1)} (dark) → {ov.max.toFixed(1)} (light). Grey areas: no data.</p>}
          {ov && activeLayer === "litho" && <LithoLegend body={body.id} />}
          {mode === "reverse" && <EarthRefPicker />}
          {mode === "landing" && <LandingMethod body={body} />}
          {mode !== "reverse" && <PointPicker body={body} />}
          {mode !== "landing" && <CriteriaPanel body={body} />}
          {mode === "reverse" && <EarthRefPanel />}
          <RegionPanel cell={cell} />
        </div>

        <div data-tour="results" className="min-w-0 space-y-3">
          {mode === "analogs" && (selected && cell ? <ResultPanel r={selected} cell={cell} onBack={() => s.setSiteId(null)} /> : <ResultsList />)}
          {mode === "reverse" && (cell && rv.ref && s.point && !a.loading
            ? <ResultPanel r={{ item: rv.ref, result: score(prepare(cell.values, rv.ref, a.keys, a.bounds), toScoreCriteria(a.sel.rankable)), rank: 0, robust: null }} badge={s.point.label?.replace("Match ", "") ?? "•"} cell={cell} onBack={() => s.setPoint(null)} backLabel={`All ${body.name} matches`} />
            : <ReverseList />)}
          {mode === "landing" && (cell && s.point ? <LandingDetail cell={cell} /> : <LandingList />)}
        </div>
      </div>
    </div>
  );
}

function PointPicker({ body }: { body: BodyConfig }) {
  const s = useSelection();
  const [lat, setLat] = useState(""); const [lon, setLon] = useState("");
  const [err, setErr] = useState<string | null>(null);
  return (
    <form className="flex flex-wrap items-end gap-2 text-sm" onSubmit={(e) => {
      e.preventDefault();
      const la = Number(lat), lo = Number(lon);
      if (!lat || !lon || !Number.isFinite(la) || !Number.isFinite(lo) || Math.abs(la) > 90) { setErr("Enter latitude −90 to 90 and longitude −180 to 360."); return; }
      setErr(null); s.setPoint({ lat: la, lon: lo }); s.setSiteId(null);
    }}>
      <label className="flex flex-col text-xs">Latitude<input inputMode="decimal" value={lat} onChange={(e) => setLat(e.target.value)} placeholder="-89.5" className="w-24 rounded border bg-deep-blue px-2 py-1 text-sm" /></label>
      <label className="flex flex-col text-xs">Longitude (E+)<input inputMode="decimal" value={lon} onChange={(e) => setLon(e.target.value)} placeholder="222.7" className="w-24 rounded border bg-deep-blue px-2 py-1 text-sm" /></label>
      <button className="rounded bg-primary px-3 py-1 font-bold text-primary-foreground">Go</button>
      <span className="w-full text-xs text-muted-foreground">Quick picks:</span>
      {body.presets.map((p) => (
        <button type="button" key={p.label} onClick={() => { s.setPoint(p); s.setSiteId(null); }} className="rounded border px-2 py-0.5 text-xs hover:bg-accent">{p.label}</button>
      ))}
      {err && <p role="alert" className="w-full text-xs text-highlight">{err}</p>}
    </form>
  );
}

function CriteriaPanel({ body }: { body: BodyConfig }) {
  const s = useSelection();
  const toggle = (k: string) => s.setCriteria(s.criteria.includes(k) ? s.criteria.filter((x) => x !== k) : [...s.criteria, k]);
  return (
    <fieldset data-tour="criteria" className="rounded-lg border bg-card p-3">
      <legend className="px-1 font-display font-bold">Criteria</legend>
      <p className="mb-2 text-xs text-muted-foreground">Pick one for a focused search, or several for a combined ranking.</p>
      <ul className="space-y-2">
        {body.criteria.map((c) => (
          <li key={c.key}>
            <label className="flex cursor-pointer items-start gap-2 text-sm">
              <input type="checkbox" className="mt-1 accent-[var(--neon-yellow)]" checked={s.criteria.includes(c.key)} onChange={() => toggle(c.key)} />
              <span>
                <span className="font-bold">{c.label}</span>{" "}
                <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ${isRankable(c) ? "bg-highlight text-primary-foreground" : "border text-muted-foreground"}`}>{isRankable(c) ? "ranked" : "view only"}</span>
                <span className="block text-xs text-muted-foreground">{c.summary}</span>
                {c.method && s.criteria.includes(c.key) && <span className="mt-1 block text-xs">How it is matched: {c.method}</span>}
                {!isRankable(c) && s.criteria.includes(c.key) && <span className="mt-1 block text-xs">Not in the ranking: {c.excludedReason}</span>}
              </span>
            </label>
          </li>
        ))}
      </ul>
    </fieldset>
  );
}

function RegionPanel({ cell }: { cell: MoonCell | null }) {
  const s = useSelection(); const a = useAnalogs();
  const body = a.body;
  if (a.loading) return <p className="text-sm text-muted-foreground">Loading {body.name} data…</p>;
  if (!cell || !s.point) return <p className="rounded-lg border border-dashed p-3 text-sm">Click {body.id === "moon" ? "the Moon" : "Mars"} (or use a quick pick) to select a data region.</p>;
  const km = binSizeKm(cell.step, cell.cellLat, body.radiusKm);
  const observed = s.grid?.observedPct?.[cell.index];
  const h = cell.step / 2;
  const vars = a.sel.all.flatMap((c) => [...c.scored.map((v) => v.key), ...c.context]);
  return (
    <div className="rounded-lg border bg-card p-3 text-sm">
      <h3 className="font-display text-base font-bold">Selected {body.name} region</h3>
      <p className="mt-1 font-bold text-highlight">{s.point.label ? `${s.point.label} · ` : ""}{fmtCoord(s.point.lat, s.point.lon)}</p>
      <p className="text-xs">Data region: {fmtLat(cell.cellLat - h)} to {fmtLat(cell.cellLat + h)}, {fmtLon(cell.cellLon - h)} to {fmtLon(cell.cellLon + h)}</p>
      <p className="text-xs text-muted-foreground">Resolution: {cell.step}° × {cell.step}° bin ≈ {km.ns.toFixed(0)} km N–S × {km.ew.toFixed(0)} km E–W, {body.gridNote}. Regional statistics, not landing-safety certification. {body.convention}</p>
      {unitName(s.grid, cell.index) && <p className="text-xs">Geologic map: <b>{unitName(s.grid, cell.index)}</b> ({body.id === "moon" ? "LROC mare map" : "USGS SIM 3292 unit"})</p>}
      {observed != null && <p className="text-xs text-muted-foreground">MOLA laser coverage: {observed}% of pixels measured directly, the rest interpolated by NASA.</p>}
      {vars.length > 0 && (
        <dl className="mt-2 grid grid-cols-[1fr_auto] gap-x-3 gap-y-1">
          {vars.map((k) => (
            <div key={k} className="contents">
              <dt>{VAR_BY_KEY[k].label}{!VAR_BY_KEY[k].comparable && !VAR_BY_KEY[k].scoreMode && <span className="text-xs text-muted-foreground"> (view only)</span>}</dt>
              <dd className="text-right">{fmtValue(k, cell.values[k], body.id)}</dd>
            </div>
          ))}
        </dl>
      )}
    </div>
  );
}

function ResultsList() {
  const s = useSelection(); const a = useAnalogs();
  if (a.loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (!a.cell) return <p className="rounded-lg border border-dashed p-3 text-sm">Earth matches appear here after you select a {a.body.name} region.</p>;
  if (!a.sel.rankable.length) {
    return (
      <div className="rounded-lg border bg-card p-3 text-sm">
        <p className="font-bold">No ranking for these criteria.</p>
        <p className="mt-1">{a.sel.all.length ? `None of the selected criteria can be scored across both worlds yet. Their values are shown under the ${a.body.name} region and on each place's profile.` : "Select at least one criterion."} Tick <b>Terrain relief</b> to rank Earth places.</p>
      </div>
    );
  }
  const rk = a.ranking!;
  const n = rk.ranked.length;
  return (
    <div className="space-y-2">
      <h3 className="font-display text-lg font-bold">Known analog sites</h3>
      <p className="text-sm">Ranked by <b>{a.sel.rankable.map((c) => c.label).join(" + ")}</b> · {rk.candidates} Earth catalog places considered.</p>
      {a.moonMissing.length > 0 && <p className="rounded border p-2 text-xs">This {a.body.name} region has no data for {a.moonMissing.map((k) => VAR_BY_KEY[k].label.toLowerCase()).join(", ")}. The ranking uses the remaining measurements.</p>}
      {n < MAX_RESULTS && (
        <p role="status" className="rounded border border-highlight p-2 text-xs">
          Showing {n} of {MAX_RESULTS}. {n === 0 ? "No" : "Only these"} Earth places have enough comparable data (at least {Math.round(COVERAGE_THRESHOLD * 100)}% of the selected measurements for both regions).
          {rk.excluded.length > 0 && <> Left out: {rk.excluded.map((e) => `${e.item.name} (${Math.round(e.coverage * 100)}% coverage)`).join(", ")}.</>}
        </p>
      )}
      <ol className="space-y-2">
        {rk.ranked.map((r) => (
          <li key={r.item.id}>
            <button type="button" onClick={() => s.setSiteId(r.item.id)} className="w-full rounded-lg border bg-card p-3 text-left hover:ring-2 hover:ring-highlight focus-visible:ring-2">
              <div className="flex items-start gap-3">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-blue-yonder font-display font-black text-deep-blue">{r.rank}</span>
                <span className="min-w-0 flex-1">
                  <span className="block font-bold">{r.item.name}</span>
                  <span className="block text-xs text-muted-foreground">{r.item.country} · {fmtCoord(r.item.lat, r.item.lon)}</span>
                  <span className="block text-xs">{r.result.strength} analogy · coverage {pct(r.result.coverage)}%{r.robust !== null && ` · ${r.robust ? "robust" : "sensitive to weights"}`}</span>
                </span>
                <span className="text-right"><span className="block font-display text-xl font-black text-highlight">{pct(r.result.overall)}</span><span className="text-[10px] text-muted-foreground">score</span></span>
              </div>
            </button>
          </li>
        ))}
      </ol>
      <h3 className="pt-3 font-display text-lg font-bold">New places not in the analog catalog</h3>
      <p className="text-xs text-muted-foreground">Whole-Earth search over {a.discoveries.length ? "every" : "all"} 0.5° land cell in the team's Earth data. Each is at least 150 km from any known analog site and 500 km from the others. Shown by coordinates only: these are candidates to check, not confirmed field sites.</p>
      {a.discoveries.length === 0 && <p role="status" className="rounded border p-2 text-xs">No new candidates have enough data for these criteria.</p>}
      <ol className="space-y-2">
        {a.discoveries.map((r) => (
          <li key={r.item.id}>
            <button type="button" onClick={() => s.setSiteId(r.item.id)} className="w-full rounded-lg border border-dashed bg-card p-3 text-left hover:ring-2 hover:ring-highlight focus-visible:ring-2">
              <div className="flex items-start gap-3">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-foreground font-display text-xs font-black text-deep-blue">N{r.rank}</span>
                <span className="min-w-0 flex-1">
                  <span className="block font-bold">{fmtCoord(r.item.lat, r.item.lon)}</span>
                  <span className="mt-0.5 inline-block rounded bg-highlight px-1.5 text-[10px] font-bold uppercase text-primary-foreground">New candidate</span>
                  <span className="block text-xs">{r.result.strength} analogy · coverage {pct(r.result.coverage)}%</span>
                </span>
                <span className="text-right"><span className="block font-display text-xl font-black text-highlight">{pct(r.result.overall)}</span><span className="text-[10px] text-muted-foreground">score</span></span>
              </div>
            </button>
          </li>
        ))}
      </ol>
      <p className="text-xs text-muted-foreground">Method v{METHOD_VERSION}. Scores show similar tendencies, never identical matches.</p>
    </div>
  );
}

function ResultPanel({ r, cell, onBack, badge, backLabel = "All results" }: { r: Ranked<Site>; cell: MoonCell; onBack: () => void; badge?: string; backLabel?: string }) {
  const s = useSelection(); const a = useAnalogs();
  if (a.loading) return null;
  const site = r.item;
  const scoredVars = a.sel.rankable.flatMap((c) => c.scored.map((v) => v.key));
  const contextVars = a.sel.all.flatMap((c) => c.context);
  const sims = r.result.vars.filter((v) => v.sim !== null).sort((x, y) => y.sim! - x.sim!);
  const h = cell.step / 2;
  return (
    <article aria-labelledby="res-h" className="space-y-3 rounded-lg border-2 border-highlight bg-card p-3">
      <button type="button" onClick={onBack} className="inline-flex items-center gap-1 text-sm underline"><ArrowLeft className="h-4 w-4" aria-hidden /> {backLabel}</button>
      <header className="flex items-start gap-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-highlight font-display text-sm font-black text-primary-foreground">{badge ?? (site.discovery ? `N${r.rank}` : r.rank)}</span>
        <div className="min-w-0 flex-1">
          <h3 id="res-h" className="font-display text-xl font-bold">{badge ? `${a.body.name} region ${fmtCoord(cell.cellLat, cell.cellLon)} vs ${site.discovery ? "your Earth place" : site.name}` : site.discovery ? `New candidate at ${fmtCoord(site.lat, site.lon)}` : site.name}</h3>
          <p className="text-sm">{badge ? unitName(s.grid, cell.index) ?? "Matched by the reverse search" : site.discovery ? "Not in the known analog catalog — found by the whole-Earth search" : site.country}</p>
        </div>
        <div className="text-right"><p className="font-display text-3xl font-black text-highlight">{pct(r.result.overall)}</p><p className="text-xs">{r.result.strength} · coverage {pct(r.result.coverage)}%</p></div>
      </header>

      <div className="grid gap-2 text-xs sm:grid-cols-2">
        <div className="rounded border p-2"><p className="font-bold">{a.body.name} region</p><p>{fmtCoord(s.point!.lat, s.point!.lon)}</p><p className="text-muted-foreground">Bin {fmtLat(cell.cellLat - h)}–{fmtLat(cell.cellLat + h)}, {fmtLon(cell.cellLon - h)}–{fmtLon(cell.cellLon + h)}</p></div>
        <div className="rounded border p-2"><p className="font-bold">Earth place</p><p>{fmtCoord(site.lat, site.lon)}</p><p className="text-muted-foreground">0.5° data cell at {fmtCoord(site.cells.terrain[0], site.cells.terrain[1])}</p></div>
      </div>

      <Link to="/report" search={{ world: a.body.id, lat: +cell.cellLat.toFixed(3), lon: +cell.cellLon.toFixed(3), site: site.id, c: s.criteria.join(",") }}
        className="flex items-center justify-center gap-2 rounded-md bg-primary px-3 py-2 font-display font-bold text-primary-foreground">
        <FileText className="h-4 w-4" aria-hidden /> Consultation report for this pair
      </Link>
      <div className="flex flex-wrap gap-3 text-sm">
        <a href={googleMapsUrl(site.lat, site.lon)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 rounded bg-primary px-3 py-1 font-bold text-primary-foreground"><MapPin className="h-4 w-4" aria-hidden /> Open in Google Maps</a>
        <a href={osmUrl(site.lat, site.lon)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 rounded border px-3 py-1">OpenStreetMap</a>
        <CopyCoords lat={site.lat} lon={site.lon} />
        {!site.discovery && <Link to="/sites/$id" params={{ id: site.id }} className="inline-flex items-center gap-1 rounded border px-3 py-1">Full profile <ExternalLink className="h-3.5 w-3.5" aria-hidden /></Link>}
        {!site.discovery && <button type="button" onClick={() => s.toggleCompare(site.id)} className="rounded border px-3 py-1">{s.compare.includes(site.id) ? "Remove from comparison" : "Add to comparison"}</button>}
      </div>

      <section>
        <h4 className="font-display font-bold">Score breakdown</h4>
        <ul className="mt-1 space-y-1 text-sm">
          {a.sel.rankable.map((c) => (
            <li key={c.key}><b>{c.label}:</b> {pct(r.result.criteria[c.key])}
              <ul className="ml-4 text-xs text-muted-foreground">{r.result.vars.filter((v) => v.criterion === c.key).map((v) => <li key={v.key}>{VAR_BY_KEY[v.key as VarKey].label}: {v.sim == null ? "No data available" : `${pct(v.sim)} (${v.band})`}</li>)}</ul>
            </li>
          ))}
        </ul>
        {sims.length > 0 && (
          <p className="mt-2 text-sm"><b>Most similar:</b> {VAR_BY_KEY[sims[0]!.key as VarKey].label.toLowerCase()}. {sims.length > 1 && (sims[sims.length - 1]!.sim! < 0.5
            ? <><b>Main difference:</b> {VAR_BY_KEY[sims[sims.length - 1]!.key as VarKey].label.toLowerCase()}.</>
            : <><b>Least similar:</b> {VAR_BY_KEY[sims[sims.length - 1]!.key as VarKey].label.toLowerCase()} (still {pct(sims[sims.length - 1]!.sim)}).</>)}</p>
        )}
      </section>

      <SimilarityChart keys={scoredVars as VarKey[]} moon={cell} site={site} calib={a.bounds} result={r.result} body={a.body.id} />
      <ValuesTable keys={[...(scoredVars as VarKey[]), ...contextVars]} moon={cell} site={site} body={a.body.id} />
      <p className="text-xs text-muted-foreground">{site.discovery ? `Source: ${site.ref}. No site description exists yet.` : `Description: ${site.terrain}. ${site.geology}. Source: ${site.ref}.`}</p>
    </article>
  );
}

function SimilarityChart({ keys, moon, site, calib, result, body }: { keys: VarKey[]; moon: MoonCell; site: Site; calib: Calib; result: Result; body: BodyId }) {
  const name = body === "moon" ? "Moon" : "Mars";
  keys = keys.filter((k) => VAR_BY_KEY[k].scoreMode !== "category");
  if (!keys.length) return null;
  return (
    <figure className="rounded border p-3">
      <figcaption className="mb-3 text-sm font-bold">Where each place sits on the scoring scale</figcaption>
      <div className="space-y-6">
        {keys.map((k) => {
          const b = calib.bounds[k]; const pctMode = VAR_BY_KEY[k].scoreMode === "percentile"; const mv = moon.values[k]; const ev = site.values[k]; const meta = VAR_BY_KEY[k];
          const sim = result.vars.find((v) => v.key === k);
          if (!b) return null;
          const x = (v: number, w: "moon" | "earth") => (calib.pos(k, w, v) ?? 0) * 100;
          return (
            <div key={k} aria-label={`${meta.label}: ${name} ${fmtVal(mv, planetSide(body, k).unit)}, Earth ${fmtVal(ev, meta.earthUnit ?? meta.unit)}`}>
              <div className="mb-5 flex justify-between text-xs"><span className="font-bold">{meta.label}</span><span>similarity {pct(sim?.sim)} · {sim?.band ?? "no data"}</span></div>
              <div className="relative h-3 rounded bg-gradient-scale">
                {mv != null && ev != null && <div className="stripes absolute top-0 h-3 rounded" style={{ left: `${Math.min(x(mv, "moon"), x(ev, "earth"))}%`, width: `${Math.max(1, Math.abs(x(mv, "moon") - x(ev, "earth")))}%` }} />}
                {mv != null && <Pin x={x(mv, "moon")} text={`${name} ${fmtVal(mv, planetSide(body, k).unit)}`} top />}
                {ev != null && <Pin x={x(ev, "earth")} text={`Earth ${fmtVal(ev, meta.earthUnit ?? meta.unit)}`} />}
              </div>
              <div className="mt-5 flex justify-between text-[10px] text-muted-foreground">{pctMode ? <><span>Lowest on its own world</span><span>Highest on its own world</span></> : <><span>5th pct {b.p5.toFixed(0)} {meta.unit}</span><span>95th pct {b.p95.toFixed(0)} {meta.unit}</span></>}</div>
              {(mv == null || ev == null) && <p className="text-xs">No data available for {mv == null ? `the ${name} region` : "this Earth place"}.</p>}
            </div>
          );
        })}
      </div>
      <p className="mt-3 text-[10px] text-muted-foreground">Striped band = gap between the two places. Narrow band = similar. Scale pools every {name} bin and Earth catalog place.</p>
    </figure>
  );
}
function Pin({ x, text, top }: { x: number; text: string; top?: boolean }) {
  return (
    <div className="absolute top-0 h-3" style={{ left: `${x}%` }}>
      <div className={`h-5 w-1 -translate-x-1/2 -translate-y-1 rounded ${top ? "bg-highlight" : "border border-foreground bg-deep-blue"}`} />
      <span className={`absolute -translate-x-1/2 whitespace-nowrap text-[10px] font-bold ${top ? "-top-5 text-highlight" : "top-4"}`}>{top ? "▼ " : "▲ "}{text}</span>
    </div>
  );
}

export function ValuesTable({ keys, moon, site, body = "moon" }: { keys: VarKey[]; moon: Pick<MoonCell, "values" | "radEstimated">; site: Site; body?: BodyId }) {
  if (!keys.length) return null;
  const name = body === "moon" ? "Moon" : "Mars";
  return (
    <div className="overflow-x-auto rounded border">
      <table className="w-full text-xs">
        <caption className="p-2 text-left text-sm font-bold">Side-by-side values</caption>
        <thead><tr className="border-b text-left"><th className="p-2">Measurement</th><th className="p-2">{name}</th><th className="p-2">Earth</th></tr></thead>
        <tbody>
          {keys.map((k) => {
            const m = VAR_BY_KEY[k]; const ps = planetSide(body, k);
            const scored = m.comparable || !!m.scoreMode;
            return (
              <tr key={k} className="border-b align-top">
                <td className="p-2"><b>{m.label}</b> <span className={`ml-1 rounded px-1 text-[10px] ${scored ? "bg-highlight text-primary-foreground" : "border"}`}>{scored ? "scored" : "view only"}</span><p className="text-muted-foreground">{ps.note}</p></td>
                <td className="p-2">{fmtValue(k, moon.values[k], body)}{k === "rad" && moon.radEstimated && <span className="block text-muted-foreground">nearest orbital sample</span>}{ps.src && <a className="block underline" href={sourceUrl(ps.src)} target="_blank" rel="noopener noreferrer">{SOURCES[ps.src].dataset}</a>}</td>
                <td className="p-2">{fmtValue(k, site.values[k], "earth")}<span className="block text-muted-foreground">{m.earthKind ?? (m.earthModelled ? "modelled" : "measured")}</span><a className="block underline" href={sourceUrl(m.earthSrc)} target="_blank" rel="noreferrer">{SOURCES[m.earthSrc].dataset}</a></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function CopyCoords({ lat, lon }: { lat: number; lon: number }) {
  const [done, setDone] = useState(false);
  return (
    <button type="button" className="rounded border px-3 py-1" onClick={async () => {
      try { await navigator.clipboard.writeText(`${lat.toFixed(5)}, ${lon.toFixed(5)}`); setDone(true); setTimeout(() => setDone(false), 1500); } catch { window.prompt("Copy these coordinates", `${lat.toFixed(5)}, ${lon.toFixed(5)}`); }
    }}>{done ? "Copied!" : "Copy coordinates"}</button>
  );
}

function LithoLegend({ body }: { body: BodyId }) {
  const cls = PLANET_CLASSES[body];
  return (
    <ul className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground" aria-label="Rock type colours">
      {cls.map((c, i) => { const [r, g, b] = rampColor(cls.length > 1 ? i / (cls.length - 1) : 0); return <li key={c} className="flex items-center gap-1"><span className="inline-block h-3 w-3 rounded-sm" style={{ background: `rgb(${r},${g},${b})` }} aria-hidden />{c}</li>; })}
      <li>Source: {body === "moon" ? "LROC mare map (Nelson et al. 2014)" : "USGS Geologic Map of Mars (Tanaka et al. 2014)"}</li>
    </ul>
  );
}

function EarthRefPicker() {
  const s = useSelection();
  const [lat, setLat] = useState(""); const [lon, setLon] = useState("");
  const [err, setErr] = useState<string | null>(null);
  return (
    <div className="space-y-2 rounded-lg border bg-card p-3 text-sm">
      <h3 className="font-display text-base font-bold">Earth reference place</h3>
      <label className="block text-xs">Catalog analog site
        <select value={SITES.some((x) => x.id === s.earthRefId) ? s.earthRefId! : ""} onChange={(e) => { s.setEarthRefId(e.target.value || null); s.setPoint(null); }} className="mt-1 w-full rounded border bg-deep-blue px-2 py-1 text-sm">
          <option value="">Choose a site…</option>
          {SITES.map((x) => <option key={x.id} value={x.id}>{x.name} · {x.country}</option>)}
        </select>
      </label>
      <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => {
        e.preventDefault();
        const la = Number(lat), lo = Number(lon);
        if (!lat || !lon || !Number.isFinite(la) || !Number.isFinite(lo) || Math.abs(la) > 90) { setErr("Enter latitude −90 to 90 and longitude −180 to 360."); return; }
        const id = s.earth ? earthCellId(s.earth, la, lo) : null;
        if (!id) { setErr(`No Earth land data at ${fmtCoord(la, lo)} (ocean).`); return; }
        setErr(null); s.setEarthRefId(id); s.setPoint(null);
      }}>
        <span className="w-full text-xs text-muted-foreground">…or any land point on Earth:</span>
        <label className="flex flex-col text-xs">Latitude<input inputMode="decimal" value={lat} onChange={(e) => setLat(e.target.value)} placeholder="-24.1" className="w-24 rounded border bg-deep-blue px-2 py-1 text-sm" /></label>
        <label className="flex flex-col text-xs">Longitude<input inputMode="decimal" value={lon} onChange={(e) => setLon(e.target.value)} placeholder="-70.0" className="w-24 rounded border bg-deep-blue px-2 py-1 text-sm" /></label>
        <button className="rounded bg-primary px-3 py-1 font-bold text-primary-foreground">Use</button>
        {err && <p role="alert" className="w-full text-xs text-highlight">{err}</p>}
      </form>
    </div>
  );
}

function EarthRefPanel() {
  const a = useAnalogs(); const rv = useReverse();
  if (!rv.ref) return <p className="rounded-lg border border-dashed p-3 text-sm">Choose an Earth place (list, coordinates, or click Earth) to search {a.body.id === "moon" ? "the Moon" : "Mars"}.</p>;
  const keys = a.sel.all.flatMap((c) => [...c.scored.map((v) => v.key), ...c.context]);
  return (
    <div className="rounded-lg border bg-card p-3 text-sm">
      <h3 className="font-display text-base font-bold">{rv.ref.discovery ? "Your Earth place" : rv.ref.name}</h3>
      <p className="font-bold text-highlight">{fmtCoord(rv.ref.lat, rv.ref.lon)}</p>
      <p className="text-xs text-muted-foreground">{rv.ref.discovery ? "0.5° Earth land cell (~55 km) from the team Earth grids. No rock class: only catalog sites have one." : `${rv.ref.country} · ${rv.ref.geology}`}</p>
      {keys.length > 0 && (
        <dl className="mt-2 grid grid-cols-[1fr_auto] gap-x-3 gap-y-1">
          {keys.map((k) => <div key={k} className="contents"><dt>{VAR_BY_KEY[k].label}</dt><dd className="text-right">{fmtValue(k, rv.ref!.values[k], "earth")}</dd></div>)}
        </dl>
      )}
    </div>
  );
}

function ReverseList() {
  const s = useSelection(); const a = useAnalogs(); const rv = useReverse();
  if (a.loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  const world = a.body.id === "moon" ? "the Moon" : "Mars";
  if (!rv.ref) return <p className="rounded-lg border border-dashed p-3 text-sm">Matching {a.body.name} regions appear here after you choose an Earth place.</p>;
  if (!a.sel.rankable.length) return <p className="rounded-lg border bg-card p-3 text-sm">Select at least one ranked criterion (for example <b>Terrain relief</b>).</p>;
  const m = rv.matches ?? [];
  return (
    <div className="space-y-2">
      <h3 className="font-display text-lg font-bold">{a.body.name} regions most like {rv.ref.discovery ? "your Earth place" : rv.ref.name}</h3>
      <p className="text-sm">Ranked by <b>{a.sel.rankable.map((c) => c.label).join(" + ")}</b> · every {a.body.id === "moon" ? "2°" : "1°"} bin of {world} scanned, same scales as the forward search. Matches at least {REVERSE.minSpacingDeg}° apart.</p>
      {m.length === 0 && <p role="status" className="rounded border p-2 text-xs">No {a.body.name} region has enough comparable data for these criteria and this Earth place{a.sel.rankable.some((c) => c.key === "geochemistry") && rv.ref.discovery ? " (rock type needs a catalog site)" : ""}.</p>}
      <ol className="space-y-2">
        {m.map((r) => (
          <li key={r.item.id}>
            <button type="button" onClick={() => s.setPoint({ lat: r.item.lat, lon: r.item.lon, label: `Match R${r.rank}` })} className="w-full rounded-lg border bg-card p-3 text-left hover:ring-2 hover:ring-highlight focus-visible:ring-2">
              <div className="flex items-start gap-3">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-blue-yonder font-display text-xs font-black text-deep-blue">R{r.rank}</span>
                <span className="min-w-0 flex-1">
                  <span className="block font-bold">{fmtCoord(r.item.lat, r.item.lon)}</span>
                  {unitName(s.grid, r.item.index) && <span className="block text-xs">{unitName(s.grid, r.item.index)}</span>}
                  <span className="block text-xs">{r.result.strength} analogy · coverage {pct(r.result.coverage)}%</span>
                </span>
                <span className="text-right"><span className="block font-display text-xl font-black text-highlight">{pct(r.result.overall)}</span><span className="text-[10px] text-muted-foreground">score</span></span>
              </div>
            </button>
          </li>
        ))}
      </ol>
      <p className="text-xs text-muted-foreground">Method v{METHOD_VERSION}. Regional statistics; similar tendencies, never identical places.</p>
    </div>
  );
}

function LandingMethod({ body }: { body: BodyConfig }) {
  return (
    <div className="rounded-lg border bg-card p-3 text-sm">
      <h3 className="font-display text-base font-bold">How landing regions are recommended</h3>
      <ul className="mt-1 list-disc space-y-0.5 pl-5 text-xs">
        {LANDING_FACTORS[body.id].map((f) => <li key={f.key}><b>{f.label}</b> — {f.why}</li>)}
      </ul>
      <p className="mt-2 text-xs text-muted-foreground">Each factor is the region's rank within {body.id === "moon" ? "the Moon" : "Mars"} (0 = worst, 100 = best), so no thresholds are invented. Index = mean of the available factors; slope and relief are required and at least {Math.round(LANDING_MIN_COVERAGE * 100)}% of factors must have data. Regions ~55–60 km wide: a screening aid, not landing-safety certification.</p>
    </div>
  );
}

function LandingList() {
  const s = useSelection(); const land = useLanding(); const a = useAnalogs();
  if (!land) return <p className="text-sm text-muted-foreground">Loading {a.body.name} data…</p>;
  return (
    <div className="space-y-2">
      <h3 className="font-display text-lg font-bold">Recommended landing regions</h3>
      <p className="text-xs text-muted-foreground">Top {LANDING.n}, at least {LANDING.minSpacingDeg}° apart. Select one to see its factors and its Earth test sites.</p>
      <ol className="space-y-2">
        {land.map((l) => (
          <li key={l.index}>
            <button type="button" onClick={() => { s.setPoint({ lat: l.lat, lon: l.lon, label: `Landing L${l.rank}` }); s.setSiteId(null); }} className="w-full rounded-lg border bg-card p-3 text-left hover:ring-2 hover:ring-highlight focus-visible:ring-2">
              <div className="flex items-start gap-3">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-blue-yonder font-display text-xs font-black text-deep-blue">L{l.rank}</span>
                <span className="min-w-0 flex-1">
                  <span className="block font-bold">{fmtCoord(l.lat, l.lon)}</span>
                  {unitName(s.grid, l.index) && <span className="block text-xs">{unitName(s.grid, l.index)}</span>}
                  <span className="block text-xs">factors with data {Math.round(l.coverage * 100)}%</span>
                </span>
                <span className="text-right"><span className="block font-display text-xl font-black text-highlight">{pct(l.lsi)}</span><span className="text-[10px] text-muted-foreground">landing index</span></span>
              </div>
            </button>
          </li>
        ))}
      </ol>
    </div>
  );
}

function LandingDetail({ cell }: { cell: MoonCell }) {
  const s = useSelection(); const a = useAnalogs();
  const score_ = useMemo(() => (s.grid ? landingScorer(s.grid, s.body)(cell.index) : null), [s.grid, s.body, cell.index]);
  const top = a.loading ? [] : a.ranking?.ranked.slice(0, 3) ?? [];
  return (
    <article className="space-y-3 rounded-lg border-2 border-highlight bg-card p-3 text-sm">
      <button type="button" onClick={() => s.setPoint(null)} className="inline-flex items-center gap-1 underline"><ArrowLeft className="h-4 w-4" aria-hidden /> All landing regions</button>
      <header className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-xl font-bold">{s.point?.label ?? "Selected region"} · {fmtCoord(cell.cellLat, cell.cellLon)}</h3>
          {unitName(s.grid, cell.index) && <p>{unitName(s.grid, cell.index)}</p>}
        </div>
        <div className="text-right"><p className="font-display text-3xl font-black text-highlight">{score_ ? pct(score_.lsi) : "—"}</p><p className="text-xs">landing index</p></div>
      </header>
      {!score_ && <p role="status" className="rounded border p-2 text-xs">Not enough data here for a landing index (slope and relief are required).</p>}
      {score_ && (
        <ul className="space-y-1">
          {LANDING_FACTORS[s.body].map((f) => {
            const g = score_.factors[f.key];
            return (
              <li key={f.key}>
                <div className="flex justify-between text-xs"><span><b>{f.label}</b> · {fmtValue(f.key, cell.values[f.key], s.body)}</span><span>{g == null ? "No data available" : pct(g)}</span></div>
                <div className="h-2 rounded bg-muted"><div className="h-2 rounded bg-highlight" style={{ width: `${(g ?? 0) * 100}%` }} /></div>
              </li>
            );
          })}
        </ul>
      )}
      <div>
        <h4 className="font-display font-bold">Earth places to test for this landing region</h4>
        {top.length === 0 ? <p className="text-xs">Tick a ranked criterion under “{a.body.name} → Earth analogs” to rank Earth test sites.</p> : (
          <ol className="mt-1 space-y-1 text-xs">{top.map((r) => <li key={r.item.id}>{r.rank}. {r.item.name} — score {pct(r.result.overall)}</li>)}</ol>
        )}
        <button type="button" onClick={() => s.setMode("analogs")} className="mt-2 rounded bg-primary px-3 py-1 font-bold text-primary-foreground">Find Earth analogs for this region</button>
      </div>
    </article>
  );
}
