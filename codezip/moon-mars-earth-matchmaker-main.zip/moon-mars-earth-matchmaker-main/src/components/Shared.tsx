import { Link } from "@tanstack/react-router";
import { fmtCoord } from "@/lib/geo";
import { fmtValue, planetSide, SITES, SOURCES, sourceUrl, VAR_BY_KEY, type VarKey } from "@/lib/data";
import { useAnalogs, useSelection } from "@/lib/selection";
import { bodyById } from "@/lib/bodies";
import { isRankable } from "@/lib/criteria";

/** Criteria picker shared by the comparison pages (same selection as the explorer). */
export function CriteriaChips() {
  const s = useSelection();
  const body = bodyById(s.body);
  return (
    <fieldset className="mb-4 flex flex-wrap gap-3 rounded-lg border bg-card p-3 text-sm">
      <legend className="px-1 font-bold">Criteria</legend>
      {body.criteria.map((c) => (
        <label key={c.key} className="flex items-center gap-1">
          <input type="checkbox" checked={s.criteria.includes(c.key)} onChange={(e) => s.setCriteria(e.target.checked ? [...s.criteria, c.key] : s.criteria.filter((x) => x !== c.key))} />
          {c.label} <span className="text-xs text-muted-foreground">({isRankable(c) ? "ranked" : "view only"})</span>
        </label>
      ))}
    </fieldset>
  );
}

/** Moon or Mars region vs one or more Earth places, for the selected criteria. */
export function ComparisonTable({ siteIds }: { siteIds: string[] }) {
  const a = useAnalogs(); const s = useSelection();
  if (a.loading) return <p>Loading…</p>;
  if (!a.cell || !s.point) return <p className="rounded border border-dashed p-3">Select a {a.body.name} region in the <Link to="/" search={{ world: a.body.id }} className="underline">Explorer</Link> first.</p>;
  const cell = a.cell;
  const sites = SITES.filter((x) => siteIds.includes(x.id));
  const keys = a.sel.all.flatMap((c) => [...c.scored.map((v) => v.key), ...c.context]) as VarKey[];
  if (!keys.length) return <p>Select at least one criterion.</p>;
  return (
    <div className="overflow-x-auto rounded-lg border bg-card">
      <table className="w-full text-sm">
        <thead><tr className="border-b text-left"><th className="p-2">Measurement</th><th className="p-2">{a.body.name} {fmtCoord(s.point.lat, s.point.lon)}</th>{sites.map((x) => <th key={x.id} className="p-2">{x.name}<br /><span className="text-xs font-normal">{fmtCoord(x.lat, x.lon)}</span></th>)}</tr></thead>
        <tbody>{keys.map((k) => {
          const v = VAR_BY_KEY[k]; const ps = planetSide(a.body.id, k);
          return (
            <tr key={k} className="border-b align-top">
              <td className="p-2 font-bold">{v.label} <span className="text-xs font-normal">({v.comparable || v.scoreMode ? "scored" : "view only"})</span><p className="text-xs font-normal text-muted-foreground">{ps.note}</p></td>
              <td className="p-2">{fmtValue(k, cell.values[k], a.body.id)}{ps.src && <a className="block text-xs underline" href={sourceUrl(ps.src)} target="_blank" rel="noopener noreferrer">{SOURCES[ps.src].dataset}</a>}</td>
              {sites.map((x) => <td key={x.id} className="p-2">{fmtValue(k, x.values[k], "earth")}<a className="block text-xs underline" href={sourceUrl(v.earthSrc)} target="_blank" rel="noreferrer">{SOURCES[v.earthSrc].dataset}</a></td>)}
            </tr>
          );
        })}</tbody>
      </table>
    </div>
  );
}
