import { Link } from "@tanstack/react-router";
import logo from "@/assets/space-apps-logo-white.svg.asset.json";
import lucerne from "@/assets/nasa-space-apps-lucerne.png.asset.json";
import { useSelection } from "@/lib/selection";
import { useState } from "react";
import { Menu, X } from "lucide-react";

export const CREATORS = ["Alisson Dayhana Garcia Rios", "Yinuo Tong", "Diana Krasniqi", "Laura Isabel Silvestri", "Yu Zhu"];
const NAV = [
  { to: "/", label: "Start" },
  { to: "/moon", label: "Moon" },
  { to: "/mars", label: "Mars" },
  { to: "/sites", label: "Location Profiles" },
  { to: "/compare", label: "Scientific Comparison" },
  { to: "/economics", label: "Economic Feasibility" },
  { to: "/report", label: "Consultation Report" },
  { to: "/data", label: "Data & Methodology" },
  { to: "/feedback", label: "Feedback" },
] as const;

export function SiteHeader() {
  const { reducedMotion, setReducedMotion } = useSelection();
  const [open, setOpen] = useState(false);
  return (
    <header className="border-b border-border bg-deep-blue print:hidden">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3">
        <img src={logo.url} alt="NASA Space Apps Challenge logo" className="h-10 w-auto" />
        <span className="h-8 w-px bg-border" aria-hidden />
        <img src={lucerne.url} alt="NASA Space Apps Lucerne logo" className="h-10 w-10 rounded-full" />
        <div className="min-w-0 flex-1">
          <p className="font-display text-sm font-black tracking-[0.2em] text-highlight">SPACE APPS CHALLENGE 2026</p>
          <p className="truncate text-xs text-foreground md:text-sm">Identify Earth Locations that Analog the Permanent Moon Base Locations and Mars</p>
        </div>
        <label className="hidden items-center gap-2 text-xs text-foreground md:flex">
          <input type="checkbox" checked={reducedMotion} onChange={(e) => setReducedMotion(e.target.checked)} className="accent-[var(--neon-yellow)]" />
          Reduce motion
        </label>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X /> : <Menu />}</button>
      </div>
      <nav className={`${open ? "block" : "hidden"} border-t border-border md:block`} aria-label="Main">
        <ul className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-2 md:flex-row md:flex-wrap">
          <li className="mr-3 font-display text-lg font-black text-foreground">Space2Earth</li>
          {NAV.map((n) => (
            <li key={n.to}>
              <Link to={n.to} onClick={() => setOpen(false)} className="block rounded px-2.5 py-1 text-sm text-foreground hover:bg-accent" activeProps={{ className: "bg-electric-blue text-highlight font-bold" }} activeOptions={{ exact: n.to === "/" }}>
                {n.label}
              </Link>
            </li>
          ))}
          <li className="md:hidden">
            <label className="flex items-center gap-2 px-2.5 py-1 text-sm"><input type="checkbox" checked={reducedMotion} onChange={(e) => setReducedMotion(e.target.checked)} /> Reduce motion</label>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-border bg-deep-blue print:hidden">
      <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-sm md:flex-row md:justify-between">
        <img src={lucerne.url} alt="NASA Space Apps Lucerne logo" className="mb-2 h-12 w-12 rounded-full" />
        <p>Space2Earth · NASA Space Apps Lucerne · Space Apps Challenge 2026 · Created by {CREATORS.join(", ")}</p>
        <p className="flex gap-4"><Link to="/credits" className="underline">Credits</Link><Link to="/data" className="underline">Data sources</Link><Link to="/feedback" className="underline">Feedback &amp; contact</Link></p>
      </div>
    </footer>
  );
}

export function PageTitle({ title, intro }: { title: string; intro?: React.ReactNode }) {
  return (
    <div className="mb-6">
      <h1 className="text-3xl text-foreground md:text-4xl">{title}</h1>
      {intro && <p className="mt-2 max-w-3xl text-muted-foreground">{intro}</p>}
    </div>
  );
}
