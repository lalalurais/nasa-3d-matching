import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CircleHelp } from "lucide-react";
import { COVERAGE_THRESHOLD, MAX_RESULTS } from "@/lib/scoring";

export function HelpDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <button type="button" className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-sm font-bold text-primary-foreground hover:opacity-90">
          <CircleHelp className="h-4 w-4" aria-hidden /> Help
        </button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto border-border bg-deep-blue text-foreground sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl font-black">How to use the explorer</DialogTitle>
          <DialogDescription className="text-muted-foreground">Four steps, about a minute.</DialogDescription>
        </DialogHeader>
        <ol className="space-y-3 text-sm">
          <li><b className="text-highlight">0. Pick a world.</b> Use the Moon / Mars switch at the top. Everything below works the same for both.</li>
          <li><b className="text-highlight">1. Choose criteria.</b> Under the globe, tick what matters to you. You can do this before or after picking a place. Criteria marked <i>view only</i> show each world's own numbers but don't change the ranking.</li>
          <li><b className="text-highlight">2. Select a region.</b> Drag to turn the globe, scroll or pinch to zoom, and click a spot. The yellow box is the data region used, with its coordinates and size. You can also type coordinates or use a quick pick.</li>
          <li><b className="text-highlight">3. Read the Earth ranking.</b> The Earth globe shows up to {MAX_RESULTS} numbered places, matching the list below it. Number 1 is the closest match for the criteria you chose.</li>
          <li><b className="text-highlight">4. Open a result.</b> Click a number on the globe or a list entry to see both places side by side: coordinates, values with units and sources, a chart, and a Google Maps link.</li>
        </ol>
        <div className="mt-2 space-y-2 rounded-lg border bg-card p-3 text-sm">
          <p><b>Similarity score (0–100).</b> Same-unit measurements (relief, temperature) are placed on a shared scale running from the 5th to the 95th percentile of all values on both worlds; different-unit ones (roughness, radiation, ice) use each world's own percentile, so "high for Mars" is matched with "high for Earth". 100 means the two places sit at the same point on that scale; 0 means they are at opposite ends. It describes similar tendencies, never an identical match.</p>
          <p><b>Data coverage.</b> The share of the selected measurements that exist for both places. Places under {Math.round(COVERAGE_THRESHOLD * 100)}% are left out of the ranking. Missing values show as “No data available” and are never filled in.</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
