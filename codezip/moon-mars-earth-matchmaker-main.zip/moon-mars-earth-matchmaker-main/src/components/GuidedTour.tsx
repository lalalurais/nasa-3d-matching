import { useCallback, useEffect, useLayoutEffect, useState } from "react";
import { Compass, X } from "lucide-react";
import { useAnalogs, useSelection } from "@/lib/selection";
import { bodyById } from "@/lib/bodies";

const DONE_KEY = "e2s-tour-done";

interface Step { target: string; title: string; text: string }
const STEPS: Step[] = [
  { target: "moon", title: "1 · Pick a Moon or Mars region", text: "Use the Moon / Mars switch at the top to choose a world. Drag to turn the globe and scroll to zoom. Click any spot: a yellow box shows the data region with its coordinates and size. No idea where to start? Use “Pick a famous site for me”." },
  { target: "criteria", title: "2 · Choose what matters", text: "Tick one criterion for a focused search, or several for a combined ranking. Open a criterion to see how the two worlds' values are matched." },
  { target: "earth", title: "3 · See the Earth analogs", text: "The Earth globe shows up to 10 numbered places. Number 1 is the closest match for your region and criteria. It updates whenever you change either." },
  { target: "results", title: "4 · Open a result", text: "Click a number on the globe or in this list to compare both places side by side: score breakdown, data coverage, a chart, values with sources, and map links." },
];

/** Step-by-step spotlight tour of the explorer. Starts once for first-time visitors; reopen from the button. */
export function GuidedTour() {
  const s = useSelection(); const a = useAnalogs();
  const [i, setI] = useState<number | null>(null);
  const [rect, setRect] = useState<DOMRect | null>(null);

  useEffect(() => { if (!localStorage.getItem(DONE_KEY)) setI(0); }, []);
  const close = useCallback(() => { setI(null); localStorage.setItem(DONE_KEY, "1"); }, []);

  const step = i == null ? null : STEPS[i]!;
  useLayoutEffect(() => {
    if (!step) return;
    const el = document.querySelector<HTMLElement>(`[data-tour="${step.target}"]`);
    if (!el) return;
    el.scrollIntoView({ block: "center", behavior: s.reducedMotion ? "auto" : "smooth" });
    const upd = () => setRect(el.getBoundingClientRect());
    upd();
    const t = setInterval(upd, 250);
    window.addEventListener("resize", upd); window.addEventListener("scroll", upd, true);
    return () => { clearInterval(t); window.removeEventListener("resize", upd); window.removeEventListener("scroll", upd, true); };
  }, [step, s.reducedMotion]);

  useEffect(() => {
    if (i == null) return;
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") close(); if (e.key === "ArrowRight") setI((x) => (x! < STEPS.length - 1 ? x! + 1 : x)); if (e.key === "ArrowLeft") setI((x) => Math.max(0, x! - 1)); };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [i, close]);

  const pad = 8;
  const below = rect ? rect.bottom + 220 < window.innerHeight : true;
  const cardTop = rect ? (below ? rect.bottom + pad + 8 : Math.max(8, rect.top - pad - 8 - 200)) : 80;
  const cardLeft = rect ? Math.min(Math.max(8, rect.left), window.innerWidth - 348) : 8;

  return (
    <>
      <button type="button" onClick={() => setI(0)} className="inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm font-bold hover:bg-card">
        <Compass className="h-4 w-4" aria-hidden /> Guided tour
      </button>
      {step && (
        <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-labelledby="tour-title">
          <div className="absolute inset-0" onClick={close} />
          {rect && (
            <div className="pointer-events-none absolute rounded-lg border-2 border-highlight transition-all"
              style={{ top: rect.top - pad, left: rect.left - pad, width: rect.width + pad * 2, height: rect.height + pad * 2, boxShadow: "0 0 0 9999px color-mix(in oklab, var(--deep-blue) 75%, transparent)" }} />
          )}
          <div className="absolute w-[340px] max-w-[calc(100vw-16px)] space-y-2 rounded-lg border-2 border-highlight bg-deep-blue p-4 text-sm shadow-xl" style={{ top: cardTop, left: cardLeft }}>
            <div className="flex items-start justify-between gap-2">
              <h2 id="tour-title" className="font-display text-lg font-black text-highlight">{step.title}</h2>
              <button type="button" onClick={close} aria-label="Close tour"><X className="h-4 w-4" /></button>
            </div>
            <p>{step.text}</p>
            {i === 0 && !s.point && (
              <button type="button" className="rounded border px-2 py-1 text-xs" onClick={() => { const b = bodyById(s.body); const p = b.presets.find((x) => x.label?.startsWith("Apollo 11")) ?? b.presets[0]!; s.setPoint(p); }}>Pick a famous site for me</button>
            )}
            {i === 1 && !s.criteria.length && <p className="text-xs text-highlight">Tick at least one criterion to see a ranking.</p>}
            {i === 2 && !a.loading && a.ranking && <p className="text-xs">Showing {a.ranking.ranked.length} places right now.</p>}
            <div className="flex items-center justify-between pt-1">
              <span className="text-xs text-muted-foreground">Step {i! + 1} of {STEPS.length}</span>
              <div className="flex gap-2">
                {i! > 0 && <button type="button" onClick={() => setI(i! - 1)} className="rounded border px-3 py-1">Back</button>}
                {i! < STEPS.length - 1
                  ? <button type="button" onClick={() => setI(i! + 1)} className="rounded bg-primary px-3 py-1 font-bold text-primary-foreground">Next</button>
                  : <button type="button" onClick={close} className="rounded bg-primary px-3 py-1 font-bold text-primary-foreground">Finish</button>}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
