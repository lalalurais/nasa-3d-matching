import { lazy, Suspense, useEffect, useState } from "react";
import type { Planet3DProps } from "./Planet3D";
const Planet3D = lazy(() => import("./Planet3D"));

function hasWebGL() {
  try { const c = document.createElement("canvas"); return !!(c.getContext("webgl2") || c.getContext("webgl")); } catch { return false; }
}
/** Client-only 3D body with a 2D fallback slot for devices without WebGL. */
export function Planet({ fallback, className, ...props }: Planet3DProps & { fallback: React.ReactNode; className?: string }) {
  const [ok, setOk] = useState<boolean | null>(null);
  useEffect(() => setOk(hasWebGL()), []);
  return (
    <div className={className}>
      {ok === null ? <div className="grid h-full place-items-center text-muted-foreground">Loading 3D view…</div>
        : ok ? <Suspense fallback={<div className="grid h-full place-items-center text-muted-foreground">Loading 3D view…</div>}><Planet3D {...props} /></Suspense>
        : <div className="h-full overflow-auto p-4"><p className="mb-2 text-sm text-muted-foreground">3D is not supported on this device. Use the list instead.</p>{fallback}</div>}
    </div>
  );
}
