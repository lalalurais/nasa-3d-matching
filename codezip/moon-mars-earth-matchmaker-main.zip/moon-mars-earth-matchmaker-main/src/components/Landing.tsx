import { Link } from "@tanstack/react-router";
import { Planet } from "@/components/Planet";
import { BODIES } from "@/lib/bodies";
import { useSelection } from "@/lib/selection";
import logo from "@/assets/space-apps-logo-white.svg.asset.json";
import lucerne from "@/assets/nasa-space-apps-lucerne.png.asset.json";

const BLURB = {
  moon: "Polar cold traps, ancient maria and Apollo sites. Ranked by terrain, geography, roughness, temperature, radiation and ice.",
  mars: "Jezero, Gale, Valles Marineris and more. Ranked by terrain, geography, roughness, temperature, radiation and ice.",
} as const;

export function Landing() {
  const s = useSelection();
  return (
    <div className="mx-auto max-w-5xl py-6 text-center md:py-12">
      <div className="mb-6 flex items-center justify-center gap-4">
        <img src={logo.url} alt="NASA Space Apps Challenge logo" className="h-12 w-auto" />
        <img src={lucerne.url} alt="NASA Space Apps Lucerne logo" className="h-14 w-14 rounded-full" />
      </div>
      <h1 className="text-4xl md:text-6xl">Space2Earth</h1>
      <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">Find the places on Earth that best stand in for a region on the Moon or Mars — the ones space agencies already use, and new ones nobody has listed yet.</p>
      <p className="mt-10 font-display text-2xl font-bold text-highlight md:text-3xl">Your adventure is one click away from:</p>
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        {BODIES.map((b) => (
          <Link key={b.id} to="/" search={{ world: b.id }} onClick={() => s.setBody(b.id)} aria-label={`Explore the ${b.name}`}
            className="group block rounded-2xl border-2 bg-card p-4 text-left transition hover:border-highlight focus-visible:border-highlight">
            <Planet className="pointer-events-none h-56 overflow-hidden rounded-lg md:h-72" label={`3D ${b.name} preview`} texture={b.texture} bump={b.bump} bumpOffsetX={b.bumpOffsetX}
              autoRotate reducedMotion={s.reducedMotion} fallback={<img src={b.texture} alt="" className="h-full w-full object-cover" />} />
            <p className="mt-4 font-display text-4xl font-black group-hover:text-highlight">{b.name}</p>
            <p className="mt-1 text-sm text-muted-foreground">{BLURB[b.id]}</p>
            <span className="mt-4 inline-block rounded bg-primary px-4 py-2 font-bold text-primary-foreground">Explore {b.name} →</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
