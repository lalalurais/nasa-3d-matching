# Remix of Remix of Remix of Remix of Remix of Open Knowledge Hub

it should be public for everyone for now (so after that upload it online. make sure to use all data that we have on our Google Drive for this purpouse and upload the prompt)

Google Drive folder: https://drive.google.com/drive/folders/1VZQrxSebCMdlVoCY0T08HG6wZPOWuvrq?usp=sharing

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://moon-mars-earth-matchmaker.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/99498f6e-d227-4c8d-8bc2-615c119a7a18).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
