# Roadmap
- [x] Link a Google Drive connection to the remixed project (re-checked after the latest remix request)
- [x] Side-by-side Moon/Earth explorer with Help, criteria, top-10 markers and result panel
- [x] Rank all criteria (shared scale for same units, own-world percentile otherwise)
- [x] Cost simulator on Economic Feasibility + logistics on place profiles
- [x] Interactive guided tour
- [x] Google Maps link fix + copy coordinates + OpenStreetMap
- [x] Mars module from the Drive Mars files (terrain, ice, radiation)
- [x] Mars temperature ranking
- [ ] Publish the site publicly (waiting on the user to publish)

## Space2Earth round
- [x] Rename to Space2Earth, Lucerne logo in header/footer/start page
- [x] Start page "Your adventure is one click away from:" with Moon / Mars
- [x] 20 Earth candidates: 10 known analog sites + 10 new places from the whole-Earth search
- [x] Earth map layer on the Earth globe
- [x] Geography and Mars temperature ranked
- [x] NASA center → test site transport cost (needs a user-entered rate)
- [ ] Real shipping rate from the team (waiting on team)
- [x] Geochemistry ranked by rock class (raw Moon/Mars chemistry still not in the Drive)
- [ ] Publish (when asked)

## Reverse search, report, illumination, geochemistry, landing round
- [x] Earth map layer alignment fix
- [x] Solar illumination criterion (separate from geochemistry) from the Drive illumination files
- [x] Geochemistry ranked by lithologic class (LROC mare map, USGS Mars map, catalog geology)
- [x] Reverse search: pick an Earth place, find matching Moon/Mars regions
- [x] Landing-site recommendations on Moon and Mars
- [x] Consultation report (print / save as PDF, shareable link), with gravity terramechanics advisory
- [x] No paywall, no login (keep everything open)
- [x] Moon illumination ranked (computed from the Drive SPICE kernels by scripts/add_moon_illum.py)
