"""Moon solar illumination computed from the NAIF SPICE kernels in the team Drive (Data/Illumination/lunar_kernels:
de440s.bsp planetary ephemeris, pck00011.tpc IAU_MOON orientation, naif0012.tls leap seconds) on the 0.5° pixel centres
of Illumination/Moon_Illumination_Coordinates.xlsx, then averaged into the app's 2° Moon bins.
Airless body, so surface irradiance on a horizontal plane = 1361 W/m² x (1 AU / Sun distance)² x max(0, cos incidence).
Period: 12 synodic months (354.37 days) from 15 Nov 2026 12:00 UTC (same start as the Drive Mars file), hourly steps:
every longitude gets whole lunar days and the 1.54° lunar seasons are covered.
Not modelled: horizon / crater shadowing (polar shadowed craters are smaller than a 2° bin), solar disk size, Earthshine.
Inputs: /tmp/drive/{de440s.bsp,pck00011.tpc,naif0012.tls,moon_illum.xlsx}."""
import json, numpy as np, pandas as pd, spiceypy as sp
D = "/tmp/drive"; P = "/dev-server/public/data/moon-grid.json"
S0, AU = 1361.0, 149597870.7  # W/m² (Kopp & Lean 2011 TSI), km
for k in ("naif0012.tls", "pck00011.tpc", "de440s.bsp"): sp.furnsh(f"{D}/{k}")
x = pd.read_excel(f"{D}/moon_illum.xlsx", sheet_name="Moon_Data")
lat = np.radians(x.Latitude.values); lon = np.radians(x.Longitude.values)
N = np.stack([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)], 1)  # surface normals, IAU_MOON
t0 = sp.str2et("2026-11-15T12:00:00"); days = 12 * 29.530589
ets = t0 + np.arange(0, days * 86400, 3600.0)
sun = np.array([sp.spkpos("SUN", et, "IAU_MOON", "LT+S", "MOON")[0] for et in ets])  # km
r = np.linalg.norm(sun, axis=1); u = sun / r[:, None]; flux = S0 * (AU / r) ** 2
E = np.zeros(len(N)); L = np.zeros(len(N))
for a in range(0, len(ets), 256):
    c = N @ u[a:a + 256].T
    E += (np.clip(c, 0, None) * flux[a:a + 256]).sum(1); L += (c > 0).sum(1)
x["illum"] = E / len(ets); x["dayfrac"] = L / len(ets)
print("0.5° irradiance pct 0/5/50/95/100:", np.percentile(x.illum, [0, 5, 50, 95, 100]).round(1), "steps", len(ets))
g = json.load(open(P)); st = g["step"]
b = ((x.Latitude + 90) // st).astype(int) * g["nlon"] + ((x.Longitude % 360) // st).astype(int)
gb = x.groupby(b); n = g["nlat"] * g["nlon"]
il = gb.illum.mean().reindex(range(n)); df = gb.dayfrac.mean().reindex(range(n))
g["vars"]["illum"] = [None if np.isnan(v) else round(float(v), 2) for v in il]
g["vars"]["dayfrac"] = [None if np.isnan(v) else round(float(v), 4) for v in df]
json.dump(g, open(P, "w"), separators=(",", ":"))
print("2° bins", int(il.notna().sum()), "of", n, "equator", round(float(il[45 * g["nlon"]]), 1), "pole", round(float(il[n - 1]), 1), "dayfrac 5/50/95", np.nanpercentile(df, [5, 50, 95]).round(3))
