"""Preprocess Google Drive datasets into compact JSON for the app.
Run from /tmp/drive after downloading (see scripts/README). Outputs to src/data/."""
import json, numpy as np, pandas as pd, os
OUT = "/dev-server/src/data"; os.makedirs(OUT, exist_ok=True)
B = "/tmp/drive/big"; F = "/tmp/drive/f"
STEP = 2.0  # Moon grid resolution in degrees
nlat, nlon = int(180/STEP), int(360/STEP)

def binidx(lat, lon360):
    i = np.clip(((lat + 90)//STEP).astype(int), 0, nlat-1)
    j = np.clip(((lon360 % 360)//STEP).astype(int), 0, nlon-1)
    return i*nlon + j

def agg(idx, vals):
    s = np.zeros(nlat*nlon); c = np.zeros(nlat*nlon)
    ok = ~np.isnan(vals)
    np.add.at(s, idx[ok], vals[ok]); np.add.at(c, idx[ok], 1)
    with np.errstate(invalid="ignore"): r = s/c
    return r

grid = {}
mt = pd.read_csv(f"{B}/moon_terrain.csv")
idx = binidx(mt.latitude_center_deg.values, mt.longitude_center_deg_east.values)
for k, col in [("elev","elevation_mean_m"),("slope","slope_mean_deg"),("rough","roughness_mean_m")]:
    grid[k] = agg(idx, mt[col].values.astype(float))
mtp = pd.read_csv(f"{B}/moon_temp.csv", encoding="utf-8-sig")
idx = binidx(mtp.latitude_center_deg.values, mtp.longitude_center_deg.values)
for k, col in [("tday","mean_day_06_18_c"),("tnight","mean_night_18_06_c"),("tnoon","mean_noon_10_14_c"),("tmid","mean_midnight_22_02_c"),("tmax","maximum_observed_time_bin_c"),("tmin","minimum_observed_time_bin_c")]:
    grid[k] = agg(idx, mtp[col].values.astype(float))
mi = pd.read_excel(f"{F}/moon_ice.xlsx", sheet_name=0)
grid["ice"] = agg(binidx(mi.Latitude_deg.values, mi.Longitude_deg.values), mi.Hydrogen_abundance_ppm.values.astype(float))
mr = pd.read_excel(f"{F}/moon_rad.xlsx")
grid["rad"] = agg(binidx(mr.Latitude.values, mr.Longitude.values), mr.iloc[:,2].values.astype(float))
# radiation is sparse orbital sampling: fill empty cells by nearest sample within 6 deg (flagged estimated)
lat_c = (np.arange(nlat)+0.5)*STEP-90; lon_c = (np.arange(nlon)+0.5)*STEP
LA, LO = np.meshgrid(lat_c, lon_c, indexing="ij"); LA=LA.ravel(); LO=LO.ravel()
radEst = np.zeros(nlat*nlon, dtype=bool)
pl, po, pv = np.radians(mr.Latitude.values), np.radians(mr.Longitude.values), mr.iloc[:,2].values
for n in np.where(np.isnan(grid["rad"]))[0]:
    a, b = np.radians(LA[n]), np.radians(LO[n])
    d = np.arccos(np.clip(np.sin(a)*np.sin(pl)+np.cos(a)*np.cos(pl)*np.cos(po-b), -1, 1))
    k = d.argmin()
    if np.degrees(d[k]) <= 6: grid["rad"][n] = pv[k]; radEst[n] = True

def r(x, d=2): return None if (x is None or np.isnan(x)) else round(float(x), d)
moon = {"step": STEP, "nlat": nlat, "nlon": nlon, "lon": "0-360 east-positive, planetocentric",
        "vars": {k: [r(v) for v in grid[k]] for k in grid}, "radEstimated": [int(x) for x in radEst]}
json.dump(moon, open(f"{OUT}/moon-grid.json","w"), separators=(",",":"))

# Elevation image for 3D displacement/shading (720x360 from 0.5 deg terrain CSV)
from PIL import Image
e = mt.pivot_table(index="latitude_center_deg", columns="longitude_center_deg_east", values="elevation_mean_m").values[::-1]
e = np.nan_to_num(e, nan=np.nanmean(e)); n_ = (e-e.min())/(e.max()-e.min())
Image.fromarray((n_*255).astype(np.uint8)).save("/tmp/drive/moon_elev.png")
print("moon elev range", e.min(), e.max())

# ---- Earth sites: sample Drive Earth grids at site coordinates ----
sites = json.load(open("/dev-server/scripts/sites_seed.json"))
et = pd.read_csv(f"{B}/earth_terrain.csv")
etp = pd.read_csv(f"{B}/earth_temp.csv", encoding="utf-8-sig")
ei = pd.read_excel(f"{F}/earth_ice.xlsx", sheet_name=0)
er = pd.read_excel(f"{F}/earth_rad.xlsx", sheet_name=0)
def nearest(df, la, lo, latc, lonc, lon360=False):
    L = df[lonc].values; lo2 = lo % 360 if lon360 else lo
    dl = np.abs(((L - lo2) + 180) % 360 - 180)
    d = (df[latc].values-la)**2 + (dl*np.cos(np.radians(la)))**2
    return df.iloc[int(d.argmin())]
for s in sites:
    la, lo = s["lat"], s["lon"]
    t = nearest(et, la, lo, "latitude_center_deg", "longitude_center_deg_east", True)
    p = nearest(etp, la, lo, "latitude_center_deg", "longitude_center_deg")
    i = nearest(ei, la, lo, "Latitude_deg", "Longitude_deg")
    q = nearest(er, la, lo, "Latitude", "Longitude")
    s["values"] = {"elev": r(t.elevation_mean_m,1), "slope": r(t.slope_mean_deg), "rough": r(t.roughness_mean_m),
      "tday": r(p.mean_day_06_18_c), "tnight": r(p.mean_night_18_06_c), "tnoon": r(p.mean_noon_10_14_c), "tmid": r(p.mean_midnight_22_02_c),
      "tmax": r(p.maximum_observed_time_bin_c), "tmin": r(p.minimum_observed_time_bin_c),
      "ice": r(i.Permafrost_Zonation_Index,3) if abs(i.Latitude_deg-la)<1 else None, "rad": r(q.iloc[2],4)}
    s["cells"] = {"terrain": [r(t.latitude_center_deg), r(t.longitude_center_deg_east)], "temp": [r(p.latitude_center_deg), r(p.longitude_center_deg)]}
# Earth-wide distributions for within-body percentile of ice/radiation
def pct_table(v): v=np.sort(v[~np.isnan(v)]); return [r(x,4) for x in np.percentile(v, np.arange(0,101,1))]
ref = {"moon": {k: pct_table(grid[k]) for k in ["ice","rad"]},
       "earth": {"ice": pct_table(ei.Permafrost_Zonation_Index.values.astype(float)), "rad": pct_table(er.iloc[:,2].values.astype(float))}}
json.dump({"sites": sites, "percentiles": ref}, open(f"{OUT}/earth-sites.json","w"), indent=1)
print(json.dumps([[s["name"], s["values"]] for s in sites])[:3000])
