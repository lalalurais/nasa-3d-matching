"""Extract NASA_Analog_Mission_Cost_Simulator.xlsx (team Drive, Financial simulation/) into src/data/cost-simulator.json."""
import json, sys, openpyxl
wb = openpyxl.load_workbook(sys.argv[1] if len(sys.argv) > 1 else "/tmp/sim.xlsx", data_only=True)
cs = wb["Cost_Simulator"]
rates = []
for r in cs.iter_rows(min_row=1, values_only=True):
    if r[0] and isinstance(r[1], (int, float)) and isinstance(r[2], (int, float)):
        rates.append({"destination": r[0], "id": "earth" if "Earth" in r[0] else "moon" if "Moon" in r[0] else "mars", "ratePerKg": r[1], "fixed": r[2]})
sc = [dict(id=r[0], experiment=r[1], site=r[2], target=r[3], massKg=r[4], fragility=r[5], multiplier=r[6])
      for r in wb["Simulated_Dataset_45_Scenarios"].iter_rows(min_row=2, values_only=True) if r[0]]
SITE_IDS = {"Atacama": "atacama", "Svalbard": "svalbard", "Devon": "haughton", "Mauna Kea": "maunakea", "Rio Tinto": "riotinto", "Lanzarote": "lanzarote", "McMurdo": "dryvalleys", "Mojave": "mdrs"}
sites = []
for r in wb["Earth_Analog_Sites"].iter_rows(min_row=2, values_only=True):
    if r[0]:
        sid = next((v for k, v in SITE_IDS.items() if k in r[0]), None)
        sites.append(dict(name=r[0], region=r[1], match=r[2], parallels=r[3], logistics=r[4], siteId=sid))
json.dump({"source": "Financial simulation/NASA_Analog_Mission_Cost_Simulator.xlsx", "rates": rates, "scenarios": sc, "sites": sites}, open("src/data/cost-simulator.json", "w"), indent=1, ensure_ascii=False)
print(len(rates), len(sc), len(sites))
