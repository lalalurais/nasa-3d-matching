"""Add solar illumination and lithologic (rock-type) class to the prebuilt grids.
Inputs:
  /tmp/drive/earth_illum.csv  Drive Data/Temperature, illumination,.../Earth/earth_illumination_2024_0p5deg.csv
                              (2024 annual-mean surface irradiance, W/m², 0.5°, lon -180..180)
  /tmp/drive/mars_illum.csv   Drive .../mars/mars_illumination_0p5deg.csv (one sol from 2026-11-15 12:00 UTC:
                              mean top-of-atmosphere irradiance W/m² and daylight fraction, 0.5°)
  /tmp/geo/moon/LROC_GLOBAL_MARE_180.*  LROC global mare boundaries (Nelson et al. 2014, LPSC 45 #2861), PDS LROLRC_2001 EXTRAS
  /tmp/geo/mars/.../SIM3292_Global_Geology.*  Tanaka et al. 2014, Geologic Map of Mars, USGS SIM 3292 (unit groups from the map legend)
The Drive Moon_Illumination_Coordinates.xlsx holds LOLA mean elevation only (see its Read_Me), so the Moon gets no illumination.
Rock classes are majority votes of 4x4 sample points per bin."""
import json, numpy as np, pandas as pd, shapefile
from shapely.geometry import shape
from shapely import STRtree, points
P="/dev-server/public/data"; S="/dev-server/src/data/earth-sites.json"

PPD = 8  # raster pixels per degree used to rasterise the map polygons

def rasterise(path, valfn, default):
    """Equirectangular raster (lon -180..180, lat 90..-90) of a polygon map. Larger polygons first, so nested
    polygons and holes drawn later win; holes are drawn back with the default value."""
    from PIL import Image, ImageDraw
    r = shapefile.Reader(path); shapes = []
    for sr in r.iterShapeRecords():
        g = shape(sr.shape.__geo_interface__); shapes.append((g.area, g, valfn(sr.record)))
    W, H = 360 * PPD, 180 * PPD
    img = Image.new("I", (W, H), default); d = ImageDraw.Draw(img)
    xy = lambda ring: [((x + 180) * PPD, (90 - y) * PPD) for x, y in ring.coords]
    for _, g, v in sorted(shapes, key=lambda t: -t[0]):
        for poly in getattr(g, "geoms", [g]):
            d.polygon(xy(poly.exterior), fill=int(v))
            for h in poly.interiors: d.polygon(xy(h), fill=default)
    return np.array(img, dtype=np.int64)  # [row from north, col from -180]

def sample(r, lat, lon180):
    i = np.clip(((90 - lat) * PPD).astype(int), 0, r.shape[0] - 1); j = np.clip(((lon180 + 180) * PPD).astype(int), 0, r.shape[1] - 1)
    return r[i, j]

def bin_majority(r, step, nlat, nlon, ncls, sub=4):
    o = (np.arange(sub) + 0.5) / sub * step
    I, J, A, B = np.meshgrid(np.arange(nlat), np.arange(nlon), o, o, indexing="ij")
    lat = (-90 + I * step + A).ravel(); lon = (J * step + B).ravel()
    c = sample(r, lat, ((lon + 180) % 360) - 180).reshape(nlat * nlon, sub * sub)
    counts = np.stack([(c == k).sum(1) for k in range(ncls)], 1)
    return np.where(counts.sum(1) > 0, counts.argmax(1), -1)

def centres(g):
    st = g["step"]; I, J = np.meshgrid(np.arange(g["nlat"]), np.arange(g["nlon"]), indexing="ij")
    return -90 + (I.ravel() + 0.5) * st, (((J.ravel() + 0.5) * st + 180) % 360) - 180

# ---------- Moon: 0 = highlands (non-mare), 1 = mare basalt ----------
moon = json.load(open(f"{P}/moon-grid.json"))
MP = "/tmp/geo/moon/LROC_GLOBAL_MARE_180"
names = sorted({rec["MARE_NAME"] for rec in shapefile.Reader(MP).records() if rec["MARE_NAME"]}); nid = {n: i for i, n in enumerate(names)}
rm = rasterise(MP, lambda rec: nid.get(rec["MARE_NAME"], len(names)), -1)  # mare id per pixel, -1 = highlands
cls = bin_majority((rm >= 0).astype(int), moon["step"], moon["nlat"], moon["nlon"], 2)
moon["vars"]["litho"] = [int(x) for x in cls]
lat, lon180 = centres(moon); nm = sample(rm, lat, lon180)
moon["unitNames"] = names; moon["unit"] = [int(x) if (c == 1 and 0 <= x < len(names)) else -1 for x, c in zip(nm, cls)]
json.dump(moon, open(f"{P}/moon-grid.json", "w"), separators=(",", ":"))
print("moon mare bins", int((cls == 1).sum()), "of", len(cls), flush=True)

# ---------- Mars: unit groups of SIM 3292 ----------
# 0 volcanic, 1 highland, 2 lowland/basin/transition/apron deposits, 3 polar, 4 impact
def mars_group(unit):
    t = unit.lstrip("elm").lstrip("AHN")
    return {"v": 0, "h": 1, "l": 2, "b": 2, "t": 2, "a": 2, "p": 3, "i": 4}[t[0]]
mars = json.load(open(f"{P}/mars-grid.json"))
GP = "/tmp/geo/mars/SIM3292_MarsGlobalGeologicGIS_20M/SIM3292_Shapefiles/SIM3292_Global_Geology"
units = sorted({rec["Unit"] for rec in shapefile.Reader(GP).records()}); uid = {u: i for i, u in enumerate(units)}
ru = rasterise(GP, lambda rec: uid[rec["Unit"]], -1)
grp = np.array([mars_group(u) for u in units] + [-1])
cls = bin_majority(grp[ru], mars["step"], mars["nlat"], mars["nlon"], 5)
lat, lon180 = centres(mars); un = sample(ru, lat, lon180)
mars["vars"]["litho"] = [None if x < 0 else int(x) for x in cls]
desc = {rec["Unit"]: rec["UnitDesc"] for rec in shapefile.Reader(GP).records()}
mars["unitNames"] = [f"{u} · {desc[u]}" for u in units]; mars["unit"] = [int(x) for x in un]
st = mars["step"]
# Illumination: one-sol mean TOA irradiance and daylight fraction, 0.5° -> 1° mean
mi = pd.read_csv("/tmp/drive/mars_illum.csv")
b = ((mi.latitude_planetocentric_deg + 90) // st).astype(int) * mars["nlon"] + ((mi.longitude_east_deg % 360) // st).astype(int)
g = mi.groupby(b)
il = g.next_sol_mean_toa_irradiance_w_m2.mean().reindex(range(mars["nlat"] * mars["nlon"]))
df = g.next_sol_daylight_fraction.mean().reindex(range(mars["nlat"] * mars["nlon"]))
mars["vars"]["illum"] = [None if np.isnan(x) else round(float(x), 2) for x in il]
mars["vars"]["dayfrac"] = [None if np.isnan(x) else round(float(x), 4) for x in df]
json.dump(mars, open(f"{P}/mars-grid.json", "w"), separators=(",", ":"))
print("mars classes", np.bincount(cls[cls >= 0]), "illum", np.nanpercentile(il, [5, 50, 95]))

# ---------- Earth: 2024 annual-mean surface irradiance ----------
ei = pd.read_csv("/tmp/drive/earth_illum.csv")
ek = ((ei.latitude + 90) // 0.5).astype(int).clip(0, 359) * 720 + ((ei.longitude % 360) // 0.5).astype(int).clip(0, 719)
ev = ei.groupby(ek).illumination_w_m2.mean()
earth = json.load(open(f"{P}/earth-grid.json"))
earth["scale"]["illum"] = 10
earth["vars"]["illum"] = [None if np.isnan(x) else int(round(x * 10)) for x in ev.reindex(earth["cells"]).values]
json.dump(earth, open(f"{P}/earth-grid.json", "w"), separators=(",", ":"))
data = json.load(open(S))
for s in data["sites"]:
    k = int((s["lat"] + 90) // 0.5) * 720 + int((s["lon"] % 360) // 0.5)
    s["values"]["illum"] = round(float(ev.get(k, np.nan)), 2) if k in ev.index else None
json.dump(data, open(S, "w"), indent=1)
print("earth illum sites", [(s["id"], s["values"]["illum"]) for s in data["sites"]][:6])
