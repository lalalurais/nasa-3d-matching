"""Build public/data/earth-grid.json: every Earth land cell (0.5°, ~55 km, ETOPO mean elevation > 0 m) with the
same measurements used for the cataloged analog sites, so the whole planet can be searched for new candidates
and drawn as a map layer. Also adds mean temperature (tmean) to src/data/earth-sites.json.
Inputs (team Drive): /tmp/drive/big/earth_terrain.csv (roughness/earth_terrain_0_5deg.csv, NOAA ETOPO 2022),
/tmp/drive/big/earth_temp.csv (earth_locations_0_5x0_625deg.csv, MERRA-2), /tmp/drive/f/earth_ice.xlsx (Gruber 2012 PZI),
/tmp/drive/f/earth_rad.xlsx (EXPACS, 1°). Values are stored as integers with a per-variable scale to keep the file small."""
import json, numpy as np, pandas as pd
D="/tmp/drive"; STEP=0.5; NLAT,NLON=360,720
et=pd.read_csv(f"{D}/big/earth_terrain.csv",usecols=["latitude_center_deg","longitude_center_deg_east","elevation_mean_m","elevation_min_m","elevation_max_m","elevation_std_m","slope_mean_deg","roughness_mean_m"])
et=et[et.elevation_mean_m>0].copy()
et["i"]=((et.latitude_center_deg+90)//STEP).astype(int).clip(0,NLAT-1); et["j"]=((et.longitude_center_deg_east%360)//STEP).astype(int).clip(0,NLON-1)
et=et.sort_values(["i","j"]); idx=(et.i*NLON+et.j).values
lat=et.latitude_center_deg.values; lon=et.longitude_center_deg_east.values
V={"elev":et.elevation_mean_m.values,"relief":et.elevation_std_m.values,"range":(et.elevation_max_m-et.elevation_min_m).values,
   "slope":et.slope_mean_deg.values,"rough":et.roughness_mean_m.values}
# Temperature: MERRA-2 0.5° x 0.625° grid -> nearest temperature cell to each 0.5° centre
tp=pd.read_csv(f"{D}/big/earth_temp.csv",encoding="utf-8-sig")
tlat=np.sort(tp.latitude_center_deg.unique()); tlon=np.sort(tp.longitude_center_deg.unique())
tp["k"]=np.searchsorted(tlat,tp.latitude_center_deg)*len(tlon)+np.searchsorted(tlon,tp.longitude_center_deg)
tpk=tp.set_index("k")
lon180=((lon+180)%360)-180
ii=np.abs(lat[:,None]-tlat[None,:]).argmin(1); jj=np.abs(((lon180[:,None]-tlon[None,:])+180)%360-180).argmin(1)
kk=ii*len(tlon)+jj
for key,col in [("tday","mean_day_06_18_c"),("tnight","mean_night_18_06_c"),("tnoon","mean_noon_10_14_c"),("tmid","mean_midnight_22_02_c"),("tmean","mean_all_local_times_c"),("tmax","maximum_observed_time_bin_c"),("tmin","minimum_observed_time_bin_c")]:
    V[key]=tpk[col].reindex(kk).values.astype(float)
# Ice: PZI on a 0.5° grid (60°S–90°N); 0 = no permafrost, missing = no data
ei=pd.read_excel(f"{D}/f/earth_ice.xlsx",sheet_name="Earth_Data")
ek=((ei.Latitude_deg+90)//STEP).astype(int)*NLON+((ei.Longitude_deg%360)//STEP).astype(int)
ice=ei.groupby(ek).Permafrost_Zonation_Index.mean(); V["ice"]=ice.reindex(idx).values.astype(float)
# Radiation: EXPACS 1° points -> nearest
er=pd.read_excel(f"{D}/f/earth_rad.xlsx",sheet_name="Earth_Data"); er.columns=["la","lo","v"]
rk=(er.la.round().astype(int)+90)*361+(er.lo.round().astype(int)+180); rad=er.groupby(rk).v.mean()
V["rad"]=rad.reindex((np.round(lat).astype(int)+90)*361+(np.round(lon180).astype(int)+180)).values.astype(float)
SCALE={"elev":1,"relief":1,"range":1,"slope":100,"rough":100,"tday":10,"tnight":10,"tnoon":10,"tmid":10,"tmean":10,"tmax":10,"tmin":10,"ice":1000,"rad":100000}
q=lambda a,s:[None if np.isnan(x) else int(round(x*s)) for x in a]
out={"step":STEP,"nlat":NLAT,"nlon":NLON,"lon":"0-360 east-positive","landRule":"ETOPO 2022 mean elevation > 0 m","cells":[int(x) for x in idx],
     "scale":SCALE,"vars":{k:q(V[k],SCALE[k]) for k in SCALE}}
json.dump(out,open("/dev-server/public/data/earth-grid.json","w"),separators=(",",":"))
print("land cells",len(idx)); [print(k, np.nanpercentile(V[k],[5,50,95]).round(3), np.isnan(V[k]).mean().round(3)) for k in SCALE]
# Mean temperature for cataloged sites (nearest MERRA-2 cell, as for the other windows)
S="/dev-server/src/data/earth-sites.json"; data=json.load(open(S))
for s in data["sites"]:
    la,lo=s["lat"],s["lon"]; d=(tp.latitude_center_deg-la)**2+((((tp.longitude_center_deg-lo)+180)%360-180)*np.cos(np.radians(la)))**2
    s["values"]["tmean"]=round(float(tp.iloc[int(d.values.argmin())].mean_all_local_times_c),2)
json.dump(data,open(S,"w"),indent=1)
