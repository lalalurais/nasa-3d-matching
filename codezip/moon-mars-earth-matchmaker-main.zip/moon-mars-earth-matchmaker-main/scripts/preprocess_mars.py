"""Build public/data/mars-grid.json (1° bins ≈ 59 km, same footprint as Earth's 0.5° cells) from the team Drive Mars files.
Inputs in /tmp/drive/mars: mars_terrain.csv (Mars/mars_terrain_0_5deg.csv, MOLA MEGDR), mars_rad.xlsx (Mars_Radiation_Coordinates.xlsx,
Odyssey neutron spectrometer 5°), ice_sum.npy/ice_cnt.npy (1° aggregate of Mars_Ice_Coordinates.xlsx, SWIM ice consistency, made by ice_agg.py).
Also writes the Mars elevation image used to shade the 3D globe."""
import json, numpy as np, pandas as pd
from PIL import Image
D="/tmp/drive/mars"; STEP=1.0; nlat,nlon=180,360
def r(x,d=1): return None if x is None or np.isnan(x) else round(float(x),d)
mt=pd.read_csv(f"{D}/mars_terrain.csv", usecols=["latitude_center_deg","longitude_center_deg_east","elevation_mean_m","elevation_min_m","elevation_max_m","elevation_std_m","slope_mean_deg","roughness_mean_m","observed_elevation_pct"])
i=np.clip(((mt.latitude_center_deg+90)//STEP).astype(int),0,nlat-1); j=np.clip(((mt.longitude_center_deg_east%360)//STEP).astype(int),0,nlon-1)
mt["bin"]=i*nlon+j; g=mt.groupby("bin")
out={k:[None]*(nlat*nlon) for k in ["relief","range","elev","slope","rough","ice","rad"]}; obs=[None]*(nlat*nlon)
elev=g.elevation_mean_m.mean(); rel=np.sqrt(g.elevation_std_m.apply(lambda s:(s**2).mean())+g.elevation_mean_m.var(ddof=0))
rng=g.elevation_max_m.max()-g.elevation_min_m.min(); slope=g.slope_mean_deg.mean(); rough=g.roughness_mean_m.mean(); ob=g.observed_elevation_pct.mean()
for b in elev.index:
    b=int(b); out["elev"][b]=r(elev[b],0); out["relief"][b]=r(rel[b]); out["range"][b]=r(rng[b],0)
    out["slope"][b]=r(slope[b],2); out["rough"][b]=r(rough[b],2); obs[b]=r(ob[b],0)
# Radiation proxy: fast-neutron count rate, 5°x5° cells -> every 1° bin inside the cell
rad=pd.read_excel(f"{D}/mars_rad.xlsx", sheet_name="Mars_Data")
for _,row in rad.iterrows():
    la0=row.Latitude-2.5; lo0=(row.Longitude-2.5)%360
    for a in range(5):
        for c in range(5):
            ii=int((la0+a+90)//STEP); jj=int(((lo0+c)%360)//STEP)
            if 0<=ii<nlat: out["rad"][ii*nlon+jj]=r(row["Fast neutron count rate (counts/s)"],4)
s=np.load(f"{D}/ice_sum.npy"); c=np.load(f"{D}/ice_cnt.npy")
with np.errstate(invalid="ignore", divide="ignore"): ice=np.where(c>0, s/c, np.nan)
out["ice"]=[r(x,3) for x in ice]
json.dump({"step":STEP,"nlat":nlat,"nlon":nlon,"lon":"0-360 east-positive, planetocentric (IAU 2000)","vars":out,"radEstimated":[],"observedPct":obs},
          open("/dev-server/public/data/mars-grid.json","w"),separators=(",",":"))
e=mt.pivot_table(index="latitude_center_deg",columns="longitude_center_deg_east",values="elevation_mean_m").values[::-1]
e=np.nan_to_num(e,nan=np.nanmean(e)); n_=(e-e.min())/(e.max()-e.min())
Image.fromarray((n_*255).astype(np.uint8)).save(f"{D}/mars_elev.png")
for k,v in out.items():
    a=np.array([x for x in v if x is not None]); print(k, len(a), np.percentile(a,[5,50,95]) if len(a) else "-")
