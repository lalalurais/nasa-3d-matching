"""Adds local relief (elevation standard deviation over a ~55-60 km footprint) to the app data.
Moon: combined std of 0.5° LOLA cells inside each 2° bin (~60 km). Earth: elevation_std_m of the 0.5° ETOPO cell (~55 km).
Inputs: /tmp/drive/big/moon_terrain.csv, earth_terrain.csv (Drive roughness/ folder)."""
import json, numpy as np, pandas as pd
B="/tmp/drive/big"; G="/dev-server/public/data/moon-grid.json"; S="/dev-server/src/data/earth-sites.json"
grid=json.load(open(G)); step=grid["step"]; nlat, nlon = grid["nlat"], grid["nlon"]
mt=pd.read_csv(f"{B}/moon_terrain.csv")
i=np.clip(((mt.latitude_center_deg.values+90)//step).astype(int),0,nlat-1)
j=np.clip(((mt.longitude_center_deg_east.values%360)//step).astype(int),0,nlon-1)
mt["bin"]=i*nlon+j
mt=mt.dropna(subset=["elevation_mean_m","elevation_std_m"])
g=mt.groupby("bin")
rel=np.sqrt(g.elevation_std_m.apply(lambda s:(s**2).mean()) + g.elevation_mean_m.var(ddof=0))
out=[None]*(nlat*nlon)
for k,v in rel.items(): out[int(k)]=round(float(v),1)
grid["vars"]["relief"]=out
json.dump(grid,open(G,"w"),separators=(",",":"))
et=pd.read_csv(f"{B}/earth_terrain.csv")
data=json.load(open(S))
for s in data["sites"]:
    lo=s["lon"]%360
    dl=np.abs(((et.longitude_center_deg_east.values-lo)+180)%360-180)
    d=(et.latitude_center_deg.values-s["lat"])**2+(dl*np.cos(np.radians(s["lat"])))**2
    r=et.iloc[int(d.argmin())]
    s["values"]["relief"]=None if np.isnan(r.elevation_std_m) else round(float(r.elevation_std_m),1)
json.dump(data,open(S,"w"),indent=1)
print("moon relief p5/p50/p95",np.nanpercentile([x for x in out if x is not None],[5,50,95]))
print([(s["id"],s["values"]["relief"],s["values"]["slope"],s["values"]["rough"]) for s in data["sites"]][:25])

# Elevation range (max − min) over the same ~55–60 km footprint, from native ~1.9 km pixels.
mt2=pd.read_csv(f"{B}/moon_terrain.csv").dropna(subset=["elevation_min_m","elevation_max_m"])
i=np.clip(((mt2.latitude_center_deg.values+90)//step).astype(int),0,nlat-1)
j=np.clip(((mt2.longitude_center_deg_east.values%360)//step).astype(int),0,nlon-1)
mt2["bin"]=i*nlon+j
g2=mt2.groupby("bin"); rng=g2.elevation_max_m.max()-g2.elevation_min_m.min()
out2=[None]*(nlat*nlon)
for k,v in rng.items(): out2[int(k)]=round(float(v),1)
grid["vars"]["range"]=out2
json.dump(grid,open(G,"w"),separators=(",",":"))
for s in data["sites"]:
    lo=s["lon"]%360
    dl=np.abs(((et.longitude_center_deg_east.values-lo)+180)%360-180)
    d=(et.latitude_center_deg.values-s["lat"])**2+(dl*np.cos(np.radians(s["lat"])))**2
    r=et.iloc[int(d.argmin())]
    s["values"]["range"]=None if np.isnan(r.elevation_max_m-r.elevation_min_m) else round(float(r.elevation_max_m-r.elevation_min_m),1)
json.dump(data,open(S,"w"),indent=1)
print("moon range p5/50/95",np.nanpercentile([x for x in out2 if x is not None],[5,50,95]),[s["values"]["range"] for s in data["sites"]])
print("moon slope p50",np.nanpercentile([x for x in grid["vars"]["slope"] if x is not None],[5,50,95]),"rough",np.nanpercentile([x for x in grid["vars"]["rough"] if x is not None],[5,50,95]))
