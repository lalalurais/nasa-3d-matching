"""Adds mean surface temperature (tmean, °C) to the Moon and Mars grids.
Moon: mean_all_local_times_c from Temperature, illumination.../Moon/moon_locations_0_5deg.csv (LRO Diviner), averaged into 2° bins.
Mars: temperature_c from Temperature, illumination.../mars/mars_temperature_0p5deg.csv, averaged into 1° bins.
Inputs: /tmp/drive/big/moon_temp.csv, /tmp/drive/mars/mars_temp.csv."""
import json, numpy as np, pandas as pd
def add(path, df, latc, lonc, valc, extra=None):
    g=json.load(open(path)); st=g["step"]; nl,nn=g["nlat"],g["nlon"]
    i=((df[latc]+90)//st).astype(int).clip(0,nl-1); j=((df[lonc]%360)//st).astype(int).clip(0,nn-1)
    m=df.groupby(i*nn+j)[valc].mean(); out=[None]*(nl*nn)
    for k,v in m.items():
        if not np.isnan(v): out[int(k)]=round(float(v),2)
    g["vars"]["tmean"]=out
    if extra: extra(g, df, i*nn+j)
    json.dump(g,open(path,"w"),separators=(",",":"))
    a=np.array([x for x in out if x is not None]); print(path, len(a), np.percentile(a,[5,50,95]).round(1))
add("/dev-server/public/data/moon-grid.json", pd.read_csv("/tmp/drive/big/moon_temp.csv",encoding="utf-8-sig"), "latitude_center_deg","longitude_center_deg","mean_all_local_times_c")
mt=pd.read_csv("/tmp/drive/mars/mars_temp.csv")
def mars_extra(g, df, b):
    for key,col in [("tmax","surface_max_c"),("tmin","surface_min_c")]:
        m=df.groupby(b)[col].mean(); out=[None]*(g["nlat"]*g["nlon"])
        for k,v in m.items(): out[int(k)]=None if np.isnan(v) else round(float(v),2)
        g["vars"][key]=out
add("/dev-server/public/data/mars-grid.json", mt, "latitude_deg","longitude_east_deg","temperature_c", mars_extra)
print(mt.describe().T)
